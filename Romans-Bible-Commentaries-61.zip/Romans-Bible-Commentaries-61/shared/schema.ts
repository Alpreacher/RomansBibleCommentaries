import { pgTable, text, serial, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const commentaries = pgTable("commentaries", {
  id: serial("id").primaryKey(),
  author: text("author").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  year: text("year").notNull(),
  chapters: jsonb("chapters").notNull(), // Array of chapter content
});

export const bookmarks = pgTable("bookmarks", {
  id: serial("id").primaryKey(),
  commentaryId: integer("commentary_id").notNull(),
  chapter: integer("chapter").notNull(),
  userId: text("user_id").notNull(), // Simple user identification
});

export const insertCommentarySchema = createInsertSchema(commentaries).omit({
  id: true,
});

export const insertBookmarkSchema = createInsertSchema(bookmarks).omit({
  id: true,
});

export type Commentary = typeof commentaries.$inferSelect;
export type InsertCommentary = z.infer<typeof insertCommentarySchema>;
export type Bookmark = typeof bookmarks.$inferSelect;
export type InsertBookmark = z.infer<typeof insertBookmarkSchema>;

// Theological themes in Romans
export interface TheologicalTheme {
  id: string;
  title: string;
  description: string;
  keyVerses: string[];
  relatedChapters: number[];
  category: 'soteriology' | 'theology' | 'anthropology' | 'ecclesiology' | 'eschatology' | 'pneumatology';
}
