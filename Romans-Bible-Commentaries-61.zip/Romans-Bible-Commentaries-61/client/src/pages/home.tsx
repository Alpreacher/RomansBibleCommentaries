import { useState, useEffect } from "react";
import { useParams, useSearch } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Commentary } from "@shared/schema";
import { CommentarySidebar } from "@/components/commentary-sidebar";

import { CommentaryContent } from "@/components/commentary-content";
import { MobileSidebar } from "@/components/mobile-sidebar";
import { KeyThemesDictionary } from "@/components/key-themes-dictionary";
import { Settings } from "@/components/settings";
import { SolidMenu } from "@/components/solid-menu";
import { ChapterDropdown } from "@/components/chapter-dropdown";
import { KJVText } from "@/components/kjv-text";
import { GreekText } from "@/components/greek-text";
import { RussianText } from "@/components/russian-text";
import { ESVText } from "@/components/esv-text";
import { GreekDictionary } from "@/components/greek-dictionary";
import { PreacherExamples } from "@/components/preacher-examples";
import { BiblicalEchoes } from "@/components/biblical-echoes";
import { OtherCommentators } from "@/components/other-commentators";
import { SundaySchoolResources } from "@/components/sunday-school-resources";
import { RomansTimeline } from "@/components/romans-timeline";
import { MapsOfRomans } from "@/components/maps-of-romans";
import { BackgroundRomansPaul } from "@/components/background-romans-paul";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Search, Filter, Menu, Bookmark, BookOpen } from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";

type ViewType = 'commentary' | 'key-themes-dictionary' | 'kjv' | 'greek' | 'russian' | 'esv' | 'dictionary' | 'examples' | 'echoes' | 'other-commentators' | 'sunday-school' | 'romans-timeline' | 'maps-of-romans' | 'background-romans-paul' | 'settings';

export default function Home() {
  const params = useParams();
  const search = useSearch();
  const isMobile = useIsMobile();
  
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCommentaryId, setSelectedCommentaryId] = useState<number>(1);
  const [selectedChapter, setSelectedChapter] = useState<number>(1);
  const [currentView, setCurrentView] = useState<ViewType>('commentary');
  
  // Settings state
  const [fontSize, setFontSize] = useState(16);
  const [lineSpacing, setLineSpacing] = useState(1.6);

  // Parse URL params
  useEffect(() => {
    if (params.id) {
      setSelectedCommentaryId(parseInt(params.id));
    }
    if (params.chapter) {
      setSelectedChapter(parseInt(params.chapter));
    }
  }, [params.id, params.chapter]);

  // Fetch commentaries
  const { data: commentaries, isLoading: commentariesLoading } = useQuery<Commentary[]>({
    queryKey: ["/api/commentaries"],
  });

  // Fetch selected commentary
  const { data: selectedCommentary } = useQuery<Commentary>({
    queryKey: ["/api/commentaries", selectedCommentaryId],
    enabled: !!selectedCommentaryId,
  });

  // Search results
  const { data: searchResults } = useQuery<any[]>({
    queryKey: ["/api/search", { q: searchQuery, commentary: selectedCommentaryId }],
    enabled: searchQuery.length > 2,
  });

  const handleCommentarySelect = (commentaryId: number) => {
    setSelectedCommentaryId(commentaryId);
    if (isMobile) {
      setSidebarOpen(false);
    }
  };

  const handleChapterSelect = (chapter: number) => {
    setSelectedChapter(chapter);
  };

  const clearSearch = () => {
    setSearchQuery("");
  };

  const clearCommentaryFilter = () => {
    setSelectedCommentaryId(1);
  };

  const handleViewChange = (view: ViewType) => {
    setCurrentView(view);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-background shadow-sm border-b border-gray-200 sticky top-0 z-50">
        <div className="px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <SolidMenu 
              onCommentarySelect={handleCommentarySelect}
              onViewChange={handleViewChange}
              selectedCommentaryId={selectedCommentaryId}
            />
            <div className="hidden md:flex items-center gap-2">
              <BookOpen className="h-5 w-5 text-primary" />
              <h1 className="text-lg font-semibold text-foreground">Biblical Commentary Reader</h1>
            </div>
          </div>
          
          {/* Chapter Dropdown */}
          <ChapterDropdown 
            selectedChapter={selectedChapter}
            onChapterSelect={handleChapterSelect}
          />
          
          {/* Search Bar */}
          <div className="flex-1 max-w-md mx-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Search commentaries..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                style={{ backgroundColor: 'white' }}
                className="pl-10 pr-4 border-gray-300"
              />
              {searchQuery && (
                <button
                  onClick={clearSearch}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  ×
                </button>
              )}
            </div>
          </div>
          
          {/* Desktop sidebar toggle */}
          <div className="hidden md:block">
            <Button variant="ghost" size="sm">
              <Settings className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        <div className="px-6 py-8">

          {/* Content Display Based on Current View */}
          {currentView === 'commentary' && (
            <CommentaryContent
              commentaryId={selectedCommentaryId}
              chapter={selectedChapter}
              commentary={selectedCommentary}
              onChapterChange={handleChapterSelect}
              onNavigateToThemes={(theme) => {
                setCurrentView('key-themes-dictionary');
                // Set search term for the themes dictionary
                setTimeout(() => {
                  const searchInput = document.querySelector('input[placeholder*="Search themes"]') as HTMLInputElement;
                  if (searchInput) {
                    searchInput.value = theme;
                    searchInput.dispatchEvent(new Event('input', { bubbles: true }));
                  }
                }, 100);
              }}
            />
          )}

          {currentView === 'key-themes-dictionary' && (
            <KeyThemesDictionary />
          )}

          {currentView === 'dictionary' && (
            <GreekDictionary />
          )}

          {currentView === 'kjv' && (
            <KJVText chapter={selectedChapter} onChapterChange={handleChapterSelect} />
          )}

          {currentView === 'greek' && (
            <GreekText chapter={selectedChapter} onChapterChange={handleChapterSelect} />
          )}

          {currentView === 'russian' && (
            <RussianText chapter={selectedChapter} onChapterChange={handleChapterSelect} />
          )}

          {currentView === 'esv' && (
            <ESVText chapter={selectedChapter} onChapterChange={handleChapterSelect} />
          )}

          {currentView === 'examples' && (
            <PreacherExamples chapter={selectedChapter} />
          )}

          {currentView === 'echoes' && (
            <BiblicalEchoes chapter={selectedChapter} />
          )}

          {currentView === 'other-commentators' && (
            <OtherCommentators />
          )}

          {currentView === 'sunday-school' && (
            <SundaySchoolResources chapter={selectedChapter} onChapterChange={handleChapterSelect} />
          )}

          {currentView === 'romans-timeline' && (
            <RomansTimeline />
          )}

          {currentView === 'maps-of-romans' && (
            <MapsOfRomans />
          )}

          {currentView === 'background-romans-paul' && (
            <BackgroundRomansPaul />
          )}

          {currentView === 'settings' && (
            <Settings 
              fontSize={fontSize}
              lineSpacing={lineSpacing}
              onFontSizeChange={setFontSize}
              onLineSpacingChange={setLineSpacing}
            />
          )}

          {/* Search Results */}
          {searchQuery && searchResults && (
            <div className="mt-8">
              <h3 className="text-lg font-semibold text-foreground mb-4">
                Search Results ({searchResults.length})
              </h3>
              <div className="space-y-4">
                {searchResults.map((result, index) => (
                  <div
                    key={index}
                    className="bg-card border border-border rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer"
                    onClick={() => {
                      setSelectedCommentaryId(result.commentaryId);
                      setSelectedChapter(result.chapter);
                      setSearchQuery("");
                    }}
                  >
                    <h4 className="font-medium text-card-foreground">{result.commentaryAuthor}</h4>
                    <p className="text-sm text-muted-foreground mt-1">{result.chapterTitle}</p>
                    <p className="text-sm text-primary mt-2">
                      Chapter {result.chapter} • Match in {result.matchType}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Mobile Sidebar */}
      <MobileSidebar
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        commentaries={commentaries || []}
        selectedCommentaryId={selectedCommentaryId}
        onCommentarySelect={handleCommentarySelect}
      />
    </div>
  );
}