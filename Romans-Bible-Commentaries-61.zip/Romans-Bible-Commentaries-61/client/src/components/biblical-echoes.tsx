import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { BookOpen, ExternalLink, Quote, Star } from "lucide-react";

interface BiblicalReference {
  verse: string;
  text: string;
  context: string;
  type: 'direct' | 'allusion' | 'thematic';
}

interface OTEcho {
  source: string;
  description: string;
  scholar: string;
  confidence: 'certain' | 'probable' | 'possible';
  explanation: string;
}

// Comprehensive biblical references for each Romans chapter
const biblicalReferences: Record<number, BiblicalReference[]> = {
  1: [
    {
      verse: "Psalm 19:1-4",
      text: "The heavens declare the glory of God...",
      context: "Paul's argument about natural revelation in Romans 1:19-20",
      type: 'thematic'
    },
    {
      verse: "Isaiah 44:9-20",
      text: "Those who make idols are nothing...",
      context: "Condemnation of idolatry in Romans 1:21-23",
      type: 'thematic'
    },
    {
      verse: "Leviticus 18:22; 20:13",
      text: "You shall not lie with a male as with a woman...",
      context: "Sexual immorality described in Romans 1:26-27",
      type: 'direct'
    },
    {
      verse: "Genesis 1:27",
      text: "God created man in his own image...",
      context: "Exchange of God's glory for images in Romans 1:23",
      type: 'allusion'
    },
    {
      verse: "Habakkuk 2:4",
      text: "The righteous shall live by his faith",
      context: "Direct quotation in Romans 1:17",
      type: 'direct'
    }
  ],
  2: [
    {
      verse: "Ecclesiastes 12:14",
      text: "God will bring every deed into judgment...",
      context: "God's righteous judgment in Romans 2:2-3",
      type: 'thematic'
    },
    {
      verse: "Psalm 62:12",
      text: "You will render to a man according to his work",
      context: "Judgment according to works in Romans 2:6",
      type: 'allusion'
    },
    {
      verse: "Deuteronomy 10:17",
      text: "God shows no partiality...",
      context: "No partiality with God in Romans 2:11",
      type: 'thematic'
    },
    {
      verse: "Jeremiah 31:33",
      text: "I will put my law within them, and I will write it on their hearts",
      context: "Law written on hearts in Romans 2:15",
      type: 'allusion'
    },
    {
      verse: "Isaiah 52:5",
      text: "My name is blasphemed continually all the day",
      context: "Name of God blasphemed among Gentiles in Romans 2:24",
      type: 'direct'
    }
  ],
  3: [
    {
      verse: "Psalm 14:1-3",
      text: "There is none who does good, not even one",
      context: "Direct quotation in Romans 3:10-12",
      type: 'direct'
    },
    {
      verse: "Psalm 5:9",
      text: "Their throat is an open grave...",
      context: "Quoted in Romans 3:13",
      type: 'direct'
    },
    {
      verse: "Psalm 140:3",
      text: "The poison of asps is under their lips",
      context: "Quoted in Romans 3:13",
      type: 'direct'
    },
    {
      verse: "Psalm 10:7",
      text: "His mouth is filled with cursing and deceit and oppression",
      context: "Quoted in Romans 3:14",
      type: 'direct'
    },
    {
      verse: "Isaiah 59:7-8",
      text: "Their feet run to evil...",
      context: "Quoted in Romans 3:15-17",
      type: 'direct'
    },
    {
      verse: "Psalm 36:1",
      text: "There is no fear of God before his eyes",
      context: "Quoted in Romans 3:18",
      type: 'direct'
    },
    {
      verse: "Leviticus 16:15-16",
      text: "Atonement for the holy place because of the uncleannesses...",
      context: "Propitiation/mercy seat imagery in Romans 3:25",
      type: 'allusion'
    }
  ],
  4: [
    {
      verse: "Genesis 15:6",
      text: "Abraham believed God, and it was counted to him as righteousness",
      context: "Direct quotation in Romans 4:3",
      type: 'direct'
    },
    {
      verse: "Psalm 32:1-2",
      text: "Blessed is the one whose transgression is forgiven...",
      context: "Quoted in Romans 4:7-8",
      type: 'direct'
    },
    {
      verse: "Genesis 17:5",
      text: "I have made you the father of a multitude of nations",
      context: "Quoted in Romans 4:17",
      type: 'direct'
    },
    {
      verse: "Genesis 22:17",
      text: "I will surely bless you and multiply your offspring as the stars...",
      context: "Abraham's faith against hope in Romans 4:18",
      type: 'allusion'
    },
    {
      verse: "Genesis 18:11",
      text: "Abraham and Sarah were old, advanced in years...",
      context: "His own body as good as dead in Romans 4:19",
      type: 'allusion'
    }
  ],
  5: [
    {
      verse: "Genesis 3:6",
      text: "She took of its fruit and ate, and she also gave some to her husband...",
      context: "Sin entered through one man in Romans 5:12",
      type: 'allusion'
    },
    {
      verse: "Genesis 2:17",
      text: "In the day that you eat of it you shall surely die",
      context: "Death through sin in Romans 5:12",
      type: 'thematic'
    },
    {
      verse: "Hosea 6:7",
      text: "Like Adam they transgressed the covenant",
      context: "Adam's transgression in Romans 5:14",
      type: 'thematic'
    },
    {
      verse: "Isaiah 53:11",
      text: "By his knowledge shall the righteous one, my servant, make many to be accounted righteous",
      context: "One man's righteousness for many in Romans 5:15-19",
      type: 'allusion'
    }
  ],
  6: [
    {
      verse: "Exodus 14:27-28",
      text: "The sea returned to its normal course... and covered the chariots and the horsemen",
      context: "Burial symbolism in baptism, Romans 6:4",
      type: 'thematic'
    },
    {
      verse: "Ezekiel 36:26",
      text: "I will give you a new heart, and a new spirit I will put within you",
      context: "Newness of life in Romans 6:4",
      type: 'thematic'
    },
    {
      verse: "Isaiah 26:19",
      text: "Your dead shall live; their bodies shall rise",
      context: "Raised with Christ in Romans 6:5",
      type: 'thematic'
    }
  ],
  7: [
    {
      verse: "Exodus 20:17",
      text: "You shall not covet...",
      context: "Direct reference in Romans 7:7",
      type: 'direct'
    },
    {
      verse: "Genesis 3:13",
      text: "The serpent deceived me, and I ate",
      context: "Sin deceived me in Romans 7:11",
      type: 'allusion'
    },
    {
      verse: "Leviticus 18:5",
      text: "You shall therefore keep my statutes... if a person does them, he shall live by them",
      context: "The commandment that promised life in Romans 7:10",
      type: 'allusion'
    }
  ],
  8: [
    {
      verse: "Leviticus 26:11-12",
      text: "I will make my dwelling among you... I will walk among you and will be your God",
      context: "God's Spirit dwelling in believers, Romans 8:9-11",
      type: 'thematic'
    },
    {
      verse: "Exodus 4:22",
      text: "Israel is my firstborn son",
      context: "Sonship and inheritance in Romans 8:14-17",
      type: 'thematic'
    },
    {
      verse: "Genesis 8:22",
      text: "While the earth remains... summer and winter... shall not cease",
      context: "Creation's bondage and liberation in Romans 8:20-21",
      type: 'thematic'
    },
    {
      verse: "Psalm 44:22",
      text: "For your sake we are killed all the day long; we are regarded as sheep to be slaughtered",
      context: "Direct quotation in Romans 8:36",
      type: 'direct'
    }
  ],
  9: [
    {
      verse: "Genesis 25:23",
      text: "The older shall serve the younger",
      context: "Direct quotation about Jacob and Esau in Romans 9:12",
      type: 'direct'
    },
    {
      verse: "Malachi 1:2-3",
      text: "Jacob I loved, but Esau I hated",
      context: "Direct quotation in Romans 9:13",
      type: 'direct'
    },
    {
      verse: "Exodus 33:19",
      text: "I will have mercy on whom I have mercy, and I will have compassion on whom I have compassion",
      context: "Direct quotation in Romans 9:15",
      type: 'direct'
    },
    {
      verse: "Exodus 9:16",
      text: "For this very purpose I have raised you up, that I might show my power in you",
      context: "Direct quotation about Pharaoh in Romans 9:17",
      type: 'direct'
    },
    {
      verse: "Isaiah 29:16; 45:9",
      text: "Shall the potter be regarded as the clay?",
      context: "Potter and clay imagery in Romans 9:20-21",
      type: 'allusion'
    },
    {
      verse: "Hosea 2:23",
      text: "I will say to Not My People, 'You are my people'",
      context: "Direct quotation in Romans 9:25",
      type: 'direct'
    },
    {
      verse: "Hosea 1:10",
      text: "In the place where it was said to them, 'You are not my people,' there they will be called 'sons of the living God'",
      context: "Direct quotation in Romans 9:26",
      type: 'direct'
    },
    {
      verse: "Isaiah 10:22-23",
      text: "Though the number of the sons of Israel be as the sand of the sea, only a remnant will be saved",
      context: "Direct quotation in Romans 9:27-28",
      type: 'direct'
    },
    {
      verse: "Isaiah 1:9",
      text: "If the Lord of hosts had not left us offspring, we would have become like Sodom",
      context: "Direct quotation in Romans 9:29",
      type: 'direct'
    },
    {
      verse: "Isaiah 8:14; 28:16",
      text: "Behold, I am laying in Zion a stone of stumbling and a rock of offense",
      context: "Combined quotation in Romans 9:33",
      type: 'direct'
    }
  ],
  10: [
    {
      verse: "Deuteronomy 30:12-14",
      text: "The word is very near you. It is in your mouth and in your heart",
      context: "Adaptation in Romans 10:6-8 about righteousness by faith",
      type: 'allusion'
    },
    {
      verse: "Joel 2:32",
      text: "Everyone who calls on the name of the Lord will be saved",
      context: "Direct quotation in Romans 10:13",
      type: 'direct'
    },
    {
      verse: "Isaiah 52:7",
      text: "How beautiful upon the mountains are the feet of him who brings good news",
      context: "Direct quotation in Romans 10:15",
      type: 'direct'
    },
    {
      verse: "Isaiah 53:1",
      text: "Lord, who has believed what he has heard from us?",
      context: "Direct quotation in Romans 10:16",
      type: 'direct'
    },
    {
      verse: "Psalm 19:4",
      text: "Their voice goes out through all the earth, and their words to the ends of the world",
      context: "Applied to gospel proclamation in Romans 10:18",
      type: 'allusion'
    },
    {
      verse: "Deuteronomy 32:21",
      text: "I will make you jealous of those who are not a nation; with a foolish nation I will make you angry",
      context: "Direct quotation in Romans 10:19",
      type: 'direct'
    },
    {
      verse: "Isaiah 65:1",
      text: "I was found by those who did not seek me; I revealed myself to those who did not ask for me",
      context: "Direct quotation in Romans 10:20",
      type: 'direct'
    },
    {
      verse: "Isaiah 65:2",
      text: "All day long I have held out my hands to a disobedient and contrary people",
      context: "Direct quotation in Romans 10:21",
      type: 'direct'
    }
  ],
  11: [
    {
      verse: "1 Kings 19:10, 14",
      text: "Lord, they have killed your prophets, they have demolished your altars",
      context: "Elijah's complaint quoted in Romans 11:3",
      type: 'direct'
    },
    {
      verse: "1 Kings 19:18",
      text: "I have kept for myself seven thousand men who have not bowed the knee to Baal",
      context: "Direct quotation in Romans 11:4",
      type: 'direct'
    },
    {
      verse: "Deuteronomy 29:4; Isaiah 29:10",
      text: "God gave them a spirit of stupor, eyes that would not see and ears that would not hear",
      context: "Combined quotation in Romans 11:8",
      type: 'direct'
    },
    {
      verse: "Psalm 69:22-23",
      text: "Let their table become a snare and a trap... let their eyes be darkened so that they cannot see",
      context: "Direct quotation in Romans 11:9-10",
      type: 'direct'
    },
    {
      verse: "Isaiah 59:20-21",
      text: "The Deliverer will come from Zion, he will banish ungodliness from Jacob",
      context: "Direct quotation in Romans 11:26-27",
      type: 'direct'
    },
    {
      verse: "Isaiah 27:9; Jeremiah 31:33-34",
      text: "This will be my covenant with them when I take away their sins",
      context: "Combined allusion in Romans 11:27",
      type: 'allusion'
    },
    {
      verse: "Isaiah 40:13",
      text: "Who has known the mind of the Lord, or who has been his counselor?",
      context: "Direct quotation in Romans 11:34",
      type: 'direct'
    },
    {
      verse: "Job 41:11",
      text: "Who has given a gift to him that he might be repaid?",
      context: "Allusion in Romans 11:35",
      type: 'allusion'
    }
  ],
  12: [
    {
      verse: "Psalm 51:17",
      text: "The sacrifices of God are a broken spirit; a broken and contrite heart",
      context: "Living sacrifice concept in Romans 12:1",
      type: 'thematic'
    },
    {
      verse: "Deuteronomy 32:35",
      text: "Vengeance is mine, and recompense",
      context: "Direct quotation in Romans 12:19",
      type: 'direct'
    },
    {
      verse: "Proverbs 25:21-22",
      text: "If your enemy is hungry, feed him; if he is thirsty, give him something to drink; for by so doing you will heap burning coals on his head",
      context: "Direct quotation in Romans 12:20",
      type: 'direct'
    }
  ],
  13: [
    {
      verse: "Exodus 20:13-17",
      text: "You shall not murder, You shall not commit adultery, You shall not steal, You shall not covet",
      context: "Commandments summarized in Romans 13:9",
      type: 'direct'
    },
    {
      verse: "Leviticus 19:18",
      text: "You shall love your neighbor as yourself",
      context: "Direct quotation in Romans 13:9",
      type: 'direct'
    },
    {
      verse: "Isaiah 59:17; Ephesians 6:11-17",
      text: "Armor of light",
      context: "Armor imagery in Romans 13:12",
      type: 'thematic'
    }
  ],
  14: [
    {
      verse: "Isaiah 45:23",
      text: "To me every knee shall bow, every tongue shall swear allegiance",
      context: "Direct quotation in Romans 14:11",
      type: 'direct'
    },
    {
      verse: "Ezekiel 36:20",
      text: "Profaning my holy name",
      context: "Concern for God's name in Romans 14:16",
      type: 'thematic'
    }
  ],
  15: [
    {
      verse: "Psalm 18:49",
      text: "Therefore I will praise you among the nations, O Lord, and sing to your name",
      context: "Direct quotation in Romans 15:9",
      type: 'direct'
    },
    {
      verse: "Deuteronomy 32:43",
      text: "Rejoice, O nations, with his people",
      context: "Direct quotation in Romans 15:10",
      type: 'direct'
    },
    {
      verse: "Psalm 117:1",
      text: "Praise the Lord, all nations! Extol him, all peoples!",
      context: "Direct quotation in Romans 15:11",
      type: 'direct'
    },
    {
      verse: "Isaiah 11:10",
      text: "The root of Jesse will come, even he who arises to rule the Gentiles; in him will the Gentiles hope",
      context: "Direct quotation in Romans 15:12",
      type: 'direct'
    },
    {
      verse: "Isaiah 52:15",
      text: "Those who have never been told of him will see, and those who have never heard will understand",
      context: "Direct quotation in Romans 15:21",
      type: 'direct'
    }
  ],
  16: [
    {
      verse: "Isaiah 11:10",
      text: "The root of Jesse",
      context: "Messianic imagery referenced earlier, thematic connection",
      type: 'thematic'
    },
    {
      verse: "Genesis 3:15",
      text: "He shall bruise your head",
      context: "Satan being crushed under feet in Romans 16:20",
      type: 'allusion'
    }
  ]
};

// Old Testament echoes based on Richard B. Hays and contemporary scholarship
const otEchoes: Record<number, OTEcho[]> = {
  1: [
    {
      source: "Exodus Narrative",
      description: "The revelation of God's glory and human response pattern",
      scholar: "Richard B. Hays",
      confidence: 'probable',
      explanation: "Paul's structure of divine revelation followed by human rebellion mirrors the Exodus pattern where God reveals Himself but Israel turns to idolatry (Golden Calf)."
    },
    {
      source: "Wisdom Literature (Proverbs, Ecclesiastes)",
      description: "The foolishness of idolatry and natural revelation",
      scholar: "N.T. Wright",
      confidence: 'certain',
      explanation: "Paul's argument about natural revelation and the folly of idolatry directly echoes Wisdom literature's critique of pagan religion."
    },
    {
      source: "Isaiah 40-55",
      description: "Monotheism and critique of idol-making",
      scholar: "Richard B. Hays",
      confidence: 'probable',
      explanation: "Paul's condemnation of exchanging God's glory for images reflects Isaiah's sustained polemic against idol manufacturing and worship."
    }
  ],
  2: [
    {
      source: "Deuteronomic Theology",
      description: "Covenant blessings and curses based on obedience",
      scholar: "N.T. Wright",
      confidence: 'certain',
      explanation: "Paul's emphasis on judgment according to deeds reflects Deuteronomy's covenant structure where blessing follows obedience and curse follows disobedience."
    },
    {
      source: "Jeremiah's New Covenant",
      description: "Law written on hearts replacing external law",
      scholar: "Richard B. Hays",
      confidence: 'probable',
      explanation: "The 'law written on hearts' in Romans 2:15 directly alludes to Jeremiah 31:33's promise of internalized covenant relationship."
    }
  ],
  3: [
    {
      source: "Exodus 34:6-7",
      description: "God's character as both merciful and just",
      scholar: "N.T. Wright",
      confidence: 'probable',
      explanation: "Paul's presentation of God's righteousness balancing mercy and justice echoes the fundamental revelation of God's character to Moses."
    },
    {
      source: "Isaiah 53",
      description: "Suffering servant and substitutionary atonement",
      scholar: "Richard B. Hays",
      confidence: 'certain',
      explanation: "The propitiation imagery in Romans 3:25 presupposes Isaiah's suffering servant who bears the sins of many."
    },
    {
      source: "Day of Atonement (Leviticus 16)",
      description: "Mercy seat and blood atonement ritual",
      scholar: "C.H. Dodd",
      confidence: 'certain',
      explanation: "The 'hilasterion' (mercy seat) in Romans 3:25 directly references the Day of Atonement's central ritual of blood sprinkling for sin removal."
    }
  ],
  4: [
    {
      source: "Exodus Narrative",
      description: "God's faithfulness to covenant promises despite human failure",
      scholar: "N.T. Wright",
      confidence: 'certain',
      explanation: "Abraham's story presupposes the Exodus pattern: God calls a people, makes promises, remains faithful despite their failures, and brings about salvation through divine initiative."
    },
    {
      source: "Genesis 12-22",
      description: "Abraham's call, promise, and test of faith",
      scholar: "Richard B. Hays",
      confidence: 'certain',
      explanation: "Paul's entire argument depends on the Abraham narrative as the foundational covenant story, showing faith-righteousness before law-giving."
    }
  ],
  5: [
    {
      source: "Genesis 1-3",
      description: "Creation, fall, and promise of redemption",
      scholar: "N.T. Wright",
      confidence: 'certain',
      explanation: "The Adam-Christ typology presupposes the entire Genesis narrative of creation's goodness, human rebellion, and God's promise to reverse the curse."
    },
    {
      source: "Exodus Redemption Pattern",
      description: "Deliverance from bondage to freedom",
      scholar: "Richard B. Hays",
      confidence: 'probable',
      explanation: "Paul's language of redemption, freedom, and passage from death to life echoes the Exodus deliverance from Egyptian bondage to promised land freedom."
    }
  ],
  6: [
    {
      source: "Exodus Red Sea Crossing",
      description: "Death to old life, passage through water, new life",
      scholar: "N.T. Wright",
      confidence: 'certain',
      explanation: "Baptism imagery directly parallels the Red Sea crossing where Israel 'died' to Egyptian bondage and was 'raised' to new covenant life."
    },
    {
      source: "Ezekiel's Temple Vision",
      description: "Spirit-filled community as God's dwelling place",
      scholar: "Richard B. Hays",
      confidence: 'probable',
      explanation: "The concept of believers as God's dwelling place through the Spirit echoes Ezekiel's vision of God's glory returning to dwell among His people."
    }
  ],
  9: [
    {
      source: "Exodus Narrative",
      description: "God's sovereign choice and hardening of Pharaoh parallel to election",
      scholar: "N.T. Wright",
      confidence: 'certain',
      explanation: "Paul's argument about God's sovereignty in election directly echoes the Exodus narrative where God hardens Pharaoh's heart while demonstrating His power and mercy."
    },
    {
      source: "Genesis Patriarchal Narratives",
      description: "Jacob and Esau as paradigm of divine election",
      scholar: "Richard B. Hays",
      confidence: 'certain',
      explanation: "The entire argument of Romans 9 presupposes the Genesis narratives of divine choice, from Abraham's call through Isaac's selection over Ishmael to Jacob over Esau."
    },
    {
      source: "Isaiah's Remnant Theology",
      description: "The concept of a faithful remnant surviving judgment",
      scholar: "N.T. Wright",
      confidence: 'certain',
      explanation: "Paul's quotations from Isaiah 10 and 1 presuppose the entire prophetic framework of judgment, exile, and restoration through a faithful remnant."
    },
    {
      source: "Hosea's Marriage Metaphor",
      description: "Restoration of rejected people as God's people",
      scholar: "Richard B. Hays",
      confidence: 'certain',
      explanation: "The Hosea quotations in Romans 9:25-26 presuppose the entire narrative of Israel's unfaithfulness, rejection, and ultimate restoration through divine love."
    }
  ],
  10: [
    {
      source: "Deuteronomy's Covenant Structure",
      description: "The accessibility of God's word and covenant requirements",
      scholar: "N.T. Wright",
      confidence: 'certain',
      explanation: "Paul's use of Deuteronomy 30 presupposes the entire Deuteronomic covenant framework where God's word is accessible and obedience is possible through divine enabling."
    },
    {
      source: "Isaiah's Universal Vision",
      description: "Good news proclaimed to all nations",
      scholar: "Richard B. Hays",
      confidence: 'probable',
      explanation: "Paul's quotations from Isaiah 52-53 presuppose the Servant Songs and Isaiah's vision of salvation extending beyond Israel to all nations."
    },
    {
      source: "Moses' Song (Deuteronomy 32)",
      description: "God provoking Israel to jealousy through other nations",
      scholar: "N.T. Wright",
      confidence: 'certain',
      explanation: "The quotation of Deuteronomy 32:21 presupposes Moses' prophetic song that predicts Israel's rebellion and God's use of Gentiles to provoke them to jealousy."
    }
  ],
  11: [
    {
      source: "Elijah Cycle (1 Kings 17-19)",
      description: "Faithful remnant preserved during apostasy",
      scholar: "Richard B. Hays",
      confidence: 'certain',
      explanation: "Paul's reference to Elijah presupposes the entire narrative of the prophet's struggle against Baal worship and God's preservation of a faithful remnant."
    },
    {
      source: "Olive Tree Imagery (Jeremiah, Hosea)",
      description: "Israel as God's planting, broken off and regrafted",
      scholar: "N.T. Wright",
      confidence: 'probable',
      explanation: "The olive tree metaphor echoes prophetic imagery of Israel as God's vine/tree that is cut down in judgment but restored in mercy."
    },
    {
      source: "New Covenant Promises (Jeremiah 31, Ezekiel 36)",
      description: "Final restoration and forgiveness of Israel",
      scholar: "Richard B. Hays",
      confidence: 'certain',
      explanation: "Paul's vision of 'all Israel will be saved' presupposes the prophetic promises of comprehensive restoration and heart transformation in the new covenant."
    },
    {
      source: "Isaiah's Zion Theology",
      description: "Deliverer coming from Zion to restore Israel",
      scholar: "N.T. Wright",
      confidence: 'certain',
      explanation: "The quotation of Isaiah 59:20 presupposes Isaiah's theology of Zion as the center from which God's salvation spreads to the nations."
    }
  ],
  12: [
    {
      source: "Temple Sacrifice System",
      description: "Living sacrifice replacing animal sacrifices",
      scholar: "N.T. Wright",
      confidence: 'probable',
      explanation: "Paul's call to present bodies as living sacrifices presupposes the entire temple worship system while transforming it into spiritual worship."
    },
    {
      source: "Wisdom Literature Ethics",
      description: "Practical wisdom for righteous living",
      scholar: "Richard B. Hays",
      confidence: 'probable',
      explanation: "The ethical instructions in Romans 12 echo the practical wisdom tradition found in Proverbs and other wisdom literature."
    }
  ],
  13: [
    {
      source: "Mosaic Law Structure",
      description: "Summary of law in love command",
      scholar: "N.T. Wright",
      confidence: 'certain',
      explanation: "Paul's summary of the commandments presupposes the entire Mosaic legal framework while showing how love fulfills the law's intent."
    },
    {
      source: "Prophetic Call to Justice",
      description: "Social responsibility and governmental authority",
      scholar: "Richard B. Hays",
      confidence: 'probable',
      explanation: "The teaching on governing authorities echoes prophetic themes about God's sovereignty over nations and call for justice."
    }
  ],
  14: [
    {
      source: "Isaiah's Universal Worship",
      description: "All nations bowing before God",
      scholar: "N.T. Wright",
      confidence: 'certain',
      explanation: "The quotation of Isaiah 45:23 presupposes Isaiah's vision of universal worship where all creation acknowledges God's sovereignty."
    },
    {
      source: "Temple Purity Laws",
      description: "Clean and unclean foods and practices",
      scholar: "Richard B. Hays",
      confidence: 'probable',
      explanation: "The discussion of food and drink regulations presupposes the entire purity system while showing its transformation in Christ."
    }
  ],
  15: [
    {
      source: "Davidic Covenant",
      description: "David's son ruling over nations",
      scholar: "N.T. Wright",
      confidence: 'certain',
      explanation: "The quotations about praising God among nations presuppose the Davidic covenant and its expansion to include Gentile nations under Messiah's rule."
    },
    {
      source: "Isaiah's Servant Mission",
      description: "Light to the nations and Gentile inclusion",
      scholar: "Richard B. Hays",
      confidence: 'certain',
      explanation: "Paul's quotation of Isaiah 52:15 presupposes the Servant Songs and Isaiah's vision of the Servant bringing salvation to the ends of the earth."
    }
  ],
  16: [
    {
      source: "Genesis 3:15 (Protoevangelium)",
      description: "Seed of woman crushing serpent's head",
      scholar: "Richard B. Hays",
      confidence: 'possible',
      explanation: "The promise that God will crush Satan under believers' feet may echo the first gospel promise of ultimate victory over the serpent."
    }
  ],
  7: [
    {
      source: "Genesis 3",
      description: "The original deception and fall into sin",
      scholar: "Richard B. Hays",
      confidence: 'certain',
      explanation: "Paul's description of sin's deception and the commandment bringing death directly echoes the serpent's deception and the forbidden fruit bringing death."
    },
    {
      source: "Jeremiah 31:31-34",
      description: "The inadequacy of external law versus new covenant",
      scholar: "N.T. Wright",
      confidence: 'probable',
      explanation: "Paul's struggle with law's inability to produce righteousness presupposes Jeremiah's prophecy of a new covenant replacing the old, failed covenant."
    }
  ],
  8: [
    {
      source: "Exodus Tabernacle/Temple Theology",
      description: "God dwelling among His people through the Spirit",
      scholar: "N.T. Wright",
      confidence: 'certain',
      explanation: "The Spirit dwelling in believers fulfills the Exodus/Temple theology where God's presence dwelt among Israel, now extended to all who believe."
    },
    {
      source: "Isaiah 11:2",
      description: "The Spirit of the Lord resting upon the Messiah",
      scholar: "Richard B. Hays",
      confidence: 'probable',
      explanation: "The Spirit's role in Romans 8 presupposes Isaiah's vision of the Spirit-anointed Messiah who brings God's kingdom and transforms creation."
    },
    {
      source: "Genesis 8:20-22",
      description: "Creation's renewal and God's covenant faithfulness",
      scholar: "N.T. Wright",
      confidence: 'probable',
      explanation: "Creation's groaning and liberation echoes the post-flood covenant where God promises never again to curse the ground, looking forward to ultimate restoration."
    }
  ]
};

interface BiblicalEchoesProps {
  chapter: number;
}

export function BiblicalEchoes({ chapter }: BiblicalEchoesProps) {
  const [activeTab, setActiveTab] = useState("actual");
  
  const references = biblicalReferences[chapter] || [];
  const echoes = otEchoes[chapter] || [];

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'direct': return 'bg-green-100 text-green-800';
      case 'allusion': return 'bg-blue-100 text-blue-800';
      case 'thematic': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getConfidenceColor = (confidence: string) => {
    switch (confidence) {
      case 'certain': return 'text-green-600';
      case 'probable': return 'text-blue-600';
      case 'possible': return 'text-yellow-600';
      default: return 'text-gray-600';
    }
  };

  const getConfidenceIcon = (confidence: string) => {
    switch (confidence) {
      case 'certain': return '★★★';
      case 'probable': return '★★☆';
      case 'possible': return '★☆☆';
      default: return '☆☆☆';
    }
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">
          Echoes of Scripture - Romans Chapter {chapter}
        </h2>
        <p className="text-gray-600 mb-4">
          Biblical references and Old Testament echoes based on Richard B. Hays and contemporary scholarship
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="actual">Bible References</TabsTrigger>
          <TabsTrigger value="echoes">OT echoes</TabsTrigger>
        </TabsList>

        <TabsContent value="actual" className="space-y-4">
          {references.length === 0 ? (
            <Card className="text-center py-12">
              <CardContent>
                <BookOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  No References Available
                </h3>
                <p className="text-gray-600">
                  Biblical references for Romans chapter {chapter} are being compiled.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {references.map((ref, index) => (
                <Card key={index}>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-lg">{ref.verse}</CardTitle>
                        <Badge className={getTypeColor(ref.type)} variant="secondary">
                          {ref.type === 'direct' ? 'Direct Quote' : 
                           ref.type === 'allusion' ? 'Allusion' : 'Thematic'}
                        </Badge>
                      </div>
                      <ExternalLink className="h-4 w-4 text-gray-400" />
                    </div>
                  </CardHeader>
                  <CardContent>
                    <blockquote className="border-l-4 border-blue-500 pl-4 italic text-gray-700 mb-3">
                      "{ref.text}"
                    </blockquote>
                    <p className="text-sm text-gray-600">
                      <strong>Context:</strong> {ref.context}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="echoes" className="space-y-4">
          {echoes.length === 0 ? (
            <Card className="text-center py-12">
              <CardContent>
                <Quote className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  No Echoes Available
                </h3>
                <p className="text-gray-600">
                  Old Testament echoes for Romans chapter {chapter} are being researched.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {echoes.map((echo, index) => (
                <Card key={index}>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-lg">{echo.source}</CardTitle>
                        <div className="flex items-center gap-2 mt-1">
                          <span className={`text-sm font-medium ${getConfidenceColor(echo.confidence)}`}>
                            {getConfidenceIcon(echo.confidence)} {echo.confidence.charAt(0).toUpperCase() + echo.confidence.slice(1)}
                          </span>
                          <Badge variant="outline" className="text-xs">
                            {echo.scholar}
                          </Badge>
                        </div>
                      </div>
                      <Quote className="h-4 w-4 text-gray-400" />
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-700 mb-3 font-medium">
                      {echo.description}
                    </p>
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <p className="text-sm text-gray-600 leading-relaxed">
                        {echo.explanation}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              ))}
              
              <div className="bg-blue-50 p-4 rounded-lg">
                <h4 className="font-semibold text-blue-900 mb-2">Scholarly Note</h4>
                <p className="text-sm text-blue-800 leading-relaxed">
                  These Old Testament echoes are based on the groundbreaking work of Richard B. Hays in 
                  "Echoes of Scripture in the Letters of Paul" and contemporary scholarship by N.T. Wright, 
                  Michael Bird, and others. The confidence levels reflect scholarly consensus: 
                  ★★★ (widely accepted), ★★☆ (probable based on evidence), ★☆☆ (possible but debated).
                </p>
              </div>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}