import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface ChapterGridProps {
  selectedChapter: number;
  onChapterSelect: (chapter: number) => void;
}

export function ChapterGrid({ selectedChapter, onChapterSelect }: ChapterGridProps) {
  const chapters = Array.from({ length: 16 }, (_, i) => i + 1);

  return (
    <div className="mb-8">
      <h2 className="text-xl font-semibold text-gray-900 dark:text-gray-100 mb-4">Rom. Ch.</h2>
      <div className="grid grid-cols-8 gap-3 max-w-2xl">
        {chapters.map((chapter) => (
          <Button
            key={chapter}
            variant={selectedChapter === chapter ? "default" : "outline"}
            size="sm"
            className={cn(
              "w-12 h-12 rounded-lg font-semibold transition-colors flex items-center justify-center shadow-sm",
              selectedChapter === chapter
                ? "bg-primary text-white hover:bg-primary/90"
                : "bg-white border-2 border-gray-200 text-gray-700 hover:border-primary hover:text-primary"
            )}
            onClick={() => onChapterSelect(chapter)}
          >
            {chapter}
          </Button>
        ))}
      </div>
    </div>
  );
}
