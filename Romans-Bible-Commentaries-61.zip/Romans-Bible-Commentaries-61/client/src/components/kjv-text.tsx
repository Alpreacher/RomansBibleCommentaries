import { useState } from "react";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, ExternalLink, Search } from "lucide-react";
import { CrossReferences } from "@/components/cross-references";
import { TextToSpeech } from "@/components/text-to-speech";

interface KJVTextProps {
  chapter: number;
  onChapterChange?: (chapter: number) => void;
}

// KJV Romans text data
const kjvRomansText: Record<number, { title: string; text: string; references: string[] }> = {
  1: {
    title: "Romans Chapter 1 (KJV)",
    text: `1 Paul, a servant of Jesus Christ, called to be an apostle, separated unto the gospel of God,
2 (Which he had promised afore by his prophets in the holy scriptures,)
3 Concerning his Son Jesus Christ our Lord, which was made of the seed of David according to the flesh;
4 And declared to be the Son of God with power, according to the spirit of holiness, by the resurrection from the dead:
5 By whom we have received grace and apostleship, for obedience to the faith among all nations, for his name:
6 Among whom are ye also the called of Jesus Christ:
7 To all that be in Rome, beloved of God, called to be saints: Grace to you and peace from God our Father, and the Lord Jesus Christ.
8 First, I thank my God through Jesus Christ for you all, that your faith is spoken of throughout the whole world.
9 For God is my witness, whom I serve with my spirit in the gospel of his Son, that without ceasing I make mention of you always in my prayers;
10 Making request, if by any means now at length I might have a prosperous journey by the will of God to come unto you.
11 For I long to see you, that I may impart unto you some spiritual gift, to the end ye may be established;
12 That is, that I may be comforted together with you by the mutual faith both of you and me.
13 Now I would not have you ignorant, brethren, that oftentimes I purposed to come unto you, (but was let hitherto,) that I might have some fruit among you also, even as among other Gentiles.
14 I am debtor both to the Greeks, and to the Barbarians; both to the wise, and to the unwise.
15 So, as much as in me is, I am ready to preach the gospel to you that are at Rome also.
16 For I am not ashamed of the gospel of Christ: for it is the power of God unto salvation to every one that believeth; to the Jew first, and also to the Greek.
17 For therein is the righteousness of God revealed from faith to faith: as it is written, The just shall live by faith.`,
    references: ["Habakkuk 2:4", "Isaiah 52:7", "Psalm 98:2", "Genesis 12:3", "2 Timothy 1:11"]
  }
};

// Add chapters 2-16 with representative text for development
for (let i = 2; i <= 16; i++) {
  kjvRomansText[i] = {
    title: `Romans Chapter ${i} (KJV)`,
    text: `[Chapter ${i} - KJV text would be loaded here]

1 [First verse of Romans ${i}...]
2 [Second verse of Romans ${i}...]
3 [Third verse of Romans ${i}...]

Note: In a production application, this would contain the complete text of Romans chapter ${i} from the King James Version. The text data has been abbreviated here for development purposes.`,
    references: [`Isaiah 1:${i}`, `Psalm ${i}0:1`, `Matthew 5:${i}`]
  };
}

export function KJVText({ chapter, onChapterChange }: KJVTextProps) {
  const [showCrossReferences, setShowCrossReferences] = useState(false);
  const chapterData = kjvRomansText[chapter] || kjvRomansText[1];
  const hasReferences = chapterData.references && chapterData.references.length > 0;

  const handlePrevious = () => {
    if (chapter > 1 && onChapterChange) {
      onChapterChange(chapter - 1);
    }
  };

  const handleNext = () => {
    if (chapter < 16 && onChapterChange) {
      onChapterChange(chapter + 1);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Header Section */}
      <div className="space-y-4">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100">
            {chapterData.title}
          </h1>
        </div>
        <div className="h-px bg-gray-200 dark:border-gray-700"></div>
      </div>

      {/* Text-to-Speech Player */}
      <TextToSpeech 
        text={chapterData.text}
        title={`Romans ${chapter} (KJV)`}
      />

      {/* Bible Text Content */}
      <div className="prose dark:prose-invert max-w-none">
        <div className="whitespace-pre-line leading-relaxed text-base text-gray-800 dark:text-gray-200">
          {chapterData.text}
        </div>
      </div>

      {/* Cross References Section */}
      {hasReferences && (
        <div className="bg-blue-50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
          <h3 className="text-sm font-medium text-blue-800 dark:text-blue-200 mb-3">
            Biblical Cross References
          </h3>
          <div className="flex flex-wrap gap-2">
            {chapterData.references.map((ref, index) => (
              <Button
                key={index}
                variant="outline"
                size="sm"
                className="text-xs bg-white dark:bg-blue-900/50 border-blue-300 dark:border-blue-700 text-blue-700 dark:text-blue-300 hover:bg-blue-100 dark:hover:bg-blue-900/70"
              >
                {ref}
              </Button>
            ))}
          </div>
        </div>
      )}

      {/* Bible Study Tools */}
      <div className="flex justify-center gap-3 pt-6">
        {hasReferences && (
          <Button 
            variant="outline" 
            size="sm" 
            className="text-xs"
            onClick={() => setShowCrossReferences(!showCrossReferences)}
          >
            <ExternalLink className="h-3 w-3 mr-1" />
            Cross References
          </Button>
        )}
        <Button 
          variant="outline" 
          size="sm" 
          className="text-xs"
          onClick={() => setShowCrossReferences(!showCrossReferences)}
        >
          <Search className="h-3 w-3 mr-1" />
          Biblical Connections
        </Button>
      </div>

      {/* Navigation Buttons */}
      <div className="flex justify-between items-center pt-8">
        <Button
          variant="outline"
          size="sm"
          onClick={handlePrevious}
          disabled={chapter <= 1}
          className="flex items-center gap-2"
        >
          <ChevronLeft className="h-4 w-4" />
          Previous
        </Button>

        <div className="text-sm text-gray-500 dark:text-gray-400">
          Chapter {chapter} of 16
        </div>

        <Button
          variant="outline"
          size="sm"
          onClick={handleNext}
          disabled={chapter >= 16}
          className="flex items-center gap-2"
        >
          Next
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>

      {/* Cross References Component */}
      {showCrossReferences && (
        <CrossReferences 
          chapter={chapter} 
          onNavigate={(newChapter) => {
            if (onChapterChange) {
              onChapterChange(newChapter);
            }
          }}
        />
      )}

      <div className="text-xs text-gray-500 dark:text-gray-400 text-center pt-4 border-t border-gray-200 dark:border-gray-700">
        King James Version - Public Domain
      </div>
    </div>
  );
}