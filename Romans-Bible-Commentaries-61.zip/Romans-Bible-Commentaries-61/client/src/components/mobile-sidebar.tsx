import { Commentary } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { X, Calendar } from "lucide-react";
import { cn } from "@/lib/utils";

interface MobileSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  commentaries: Commentary[];
  selectedCommentaryId: number;
  onCommentarySelect: (id: number) => void;
}

export function MobileSidebar({
  isOpen,
  onClose,
  commentaries,
  selectedCommentaryId,
  onCommentarySelect
}: MobileSidebarProps) {
  if (!isOpen) return null;

  return (
    <div className="lg:hidden fixed inset-0 bg-black bg-opacity-50 z-40">
      <div className="fixed inset-y-0 left-0 w-80 bg-white shadow-xl z-50 transform transition-transform">
        <div className="flex items-center justify-between p-4 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900">Commentary Sources</h2>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-5 w-5" />
          </Button>
        </div>
        
        <div className="p-4 overflow-y-auto h-full pb-20">
          <div className="space-y-2">
            {commentaries.map((commentary) => (
              <Card
                key={commentary.id}
                className={cn(
                  "cursor-pointer transition-colors",
                  selectedCommentaryId === commentary.id
                    ? "bg-blue-50 border-l-4 border-l-primary"
                    : "hover:bg-gray-50"
                )}
                onClick={() => onCommentarySelect(commentary.id)}
              >
                <CardContent className="p-4">
                  <h3 className="font-medium text-gray-900">{commentary.author}</h3>
                  <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                    {commentary.description}
                  </p>
                  <div className="flex items-center mt-2 text-xs text-muted-foreground">
                    <Calendar className="h-3 w-3 mr-1" />
                    <span>{commentary.year}</span>
                    <span className="mx-2">•</span>
                    <span>16 chapters</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
