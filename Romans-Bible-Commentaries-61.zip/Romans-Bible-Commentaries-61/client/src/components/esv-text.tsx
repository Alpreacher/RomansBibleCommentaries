import { useState } from "react";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, ExternalLink, Search } from "lucide-react";
import { CrossReferences } from "@/components/cross-references";
import { TextToSpeech } from "@/components/text-to-speech";

interface ESVTextProps {
  chapter: number;
  onChapterChange?: (chapter: number) => void;
}

// ESV Romans text data
const esvRomansText: Record<number, { title: string; text: string; references: string[] }> = {
  1: {
    title: "Romans Chapter 1 (ESV)",
    text: `1 Paul, a servant of Christ Jesus, called to be an apostle, set apart for the gospel of God,
2 which he promised beforehand through his prophets in the holy Scriptures,
3 concerning his Son, who was descended from David according to the flesh
4 and was declared to be the Son of God in power according to the Spirit of holiness by his resurrection from the dead, Jesus Christ our Lord,
5 through whom we have received grace and apostleship to bring about the obedience of faith for the sake of his name among all the nations,
6 including you who are called to belong to Jesus Christ,
7 To all those in Rome who are loved by God and called to be saints: Grace to you and peace from God our Father and the Lord Jesus Christ.
8 First, I thank my God through Jesus Christ for all of you, because your faith is proclaimed in all the world.
9 For God is my witness, whom I serve with my spirit in the gospel of his Son, that without ceasing I mention you
10 always in my prayers, asking that somehow by God's will I may now at last succeed in coming to you.
11 For I long to see you, that I may impart to you some spiritual gift to strengthen you—
12 that is, that we may be mutually encouraged by each other's faith, both yours and mine.
13 I do not want you to be unaware, brothers, that I have often intended to come to you (but thus far have been prevented), in order that I may reap some harvest among you as well as among the rest of the Gentiles.
14 I am under obligation both to Greeks and to barbarians, both to the wise and to the foolish.
15 So I am eager to preach the gospel to you also who are in Rome.
16 For I am not ashamed of the gospel, for it is the power of God for salvation to everyone who believes, to the Jew first and also to the Greek.
17 For in it the righteousness of God is revealed from faith for faith, as it is written, "The righteous shall live by faith."`,
    references: ["Habakkuk 2:4", "Isaiah 52:7", "Psalm 98:2", "Genesis 12:3", "2 Timothy 1:11"]
  }
};

// Add chapters 2-16 with representative text for development
for (let i = 2; i <= 16; i++) {
  esvRomansText[i] = {
    title: `Romans Chapter ${i} (ESV)`,
    text: `[Chapter ${i} - ESV text would be loaded here]

1 [First verse of Romans ${i}...]
2 [Second verse of Romans ${i}...]
3 [Third verse of Romans ${i}...]

Note: In a production application, this would contain the complete text of Romans chapter ${i} from the English Standard Version. The text data has been abbreviated here for development purposes.`,
    references: [`Isaiah 1:${i}`, `Psalm ${i}0:1`, `Matthew 5:${i}`]
  };
}

export function ESVText({ chapter, onChapterChange }: ESVTextProps) {
  const [showCrossReferences, setShowCrossReferences] = useState(false);
  const chapterData = esvRomansText[chapter] || esvRomansText[1];
  const hasReferences = chapterData.references && chapterData.references.length > 0;

  const handlePrevious = () => {
    if (chapter > 1 && onChapterChange) {
      onChapterChange(chapter - 1);
    }
  };

  const handleNext = () => {
    if (chapter < 16 && onChapterChange) {
      onChapterChange(chapter + 1);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Header Section */}
      <div className="space-y-4">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100">
            {chapterData.title}
          </h1>
        </div>
        <div className="h-px bg-gray-200 dark:bg-gray-700"></div>
      </div>

      {/* Text-to-Speech Player */}
      <TextToSpeech 
        text={chapterData.text}
        title={`Romans ${chapter} (ESV)`}
      />

      {/* Bible Text Content */}
      <div className="prose dark:prose-invert max-w-none">
        <div className="whitespace-pre-line leading-relaxed text-base text-gray-800 dark:text-gray-200">
          {chapterData.text}
        </div>
      </div>

      {/* Cross References Section */}
      {hasReferences && (
        <div className="bg-blue-50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
          <h3 className="text-sm font-medium text-blue-800 dark:text-blue-200 mb-3">
            Biblical Cross References
          </h3>
          <div className="flex flex-wrap gap-2">
            {chapterData.references.map((ref, index) => (
              <Button
                key={index}
                variant="outline"
                size="sm"
                className="text-xs bg-white dark:bg-blue-900/50 border-blue-300 dark:border-blue-700 text-blue-700 dark:text-blue-300 hover:bg-blue-100 dark:hover:bg-blue-900/70"
              >
                {ref}
              </Button>
            ))}
          </div>
        </div>
      )}

      {/* Bible Study Tools */}
      <div className="flex justify-center gap-3 pt-6">
        {hasReferences && (
          <Button 
            variant="outline" 
            size="sm" 
            className="text-xs"
            onClick={() => setShowCrossReferences(!showCrossReferences)}
          >
            <ExternalLink className="h-3 w-3 mr-1" />
            Cross References
          </Button>
        )}
        <Button 
          variant="outline" 
          size="sm" 
          className="text-xs"
          onClick={() => setShowCrossReferences(!showCrossReferences)}
        >
          <Search className="h-3 w-3 mr-1" />
          Biblical Connections
        </Button>
      </div>

      {/* Navigation Buttons */}
      <div className="flex justify-between items-center pt-8">
        <Button
          variant="outline"
          size="sm"
          onClick={handlePrevious}
          disabled={chapter <= 1}
          className="flex items-center gap-2"
        >
          <ChevronLeft className="h-4 w-4" />
          Previous
        </Button>

        <div className="text-sm text-gray-500 dark:text-gray-400">
          Chapter {chapter} of 16
        </div>

        <Button
          variant="outline"
          size="sm"
          onClick={handleNext}
          disabled={chapter >= 16}
          className="flex items-center gap-2"
        >
          Next
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>

      {/* Cross References Component */}
      {showCrossReferences && (
        <CrossReferences 
          chapter={chapter} 
          onNavigate={(newChapter) => {
            if (onChapterChange) {
              onChapterChange(newChapter);
            }
          }}
        />
      )}

      <div className="text-xs text-gray-500 dark:text-gray-400 text-center pt-4 border-t border-gray-200 dark:border-gray-700">
        English Standard Version - Used by permission
      </div>
    </div>
  );
}