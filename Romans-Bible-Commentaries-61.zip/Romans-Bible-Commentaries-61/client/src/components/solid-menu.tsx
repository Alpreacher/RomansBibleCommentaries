import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Menu, X, BookOpen, Users, FileText, Languages, Quote, Settings as SettingsIcon, Clock, Map, Globe } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Commentary } from "@shared/schema";

interface SolidMenuProps {
  onCommentarySelect: (commentaryId: number) => void;
  onViewChange: (view: 'commentary' | 'key-themes-dictionary' | 'kjv' | 'greek' | 'russian' | 'esv' | 'dictionary' | 'examples' | 'echoes' | 'other-commentators' | 'sunday-school' | 'romans-timeline' | 'maps-of-romans' | 'background-romans-paul' | 'settings') => void;
  selectedCommentaryId: number;
}

export function SolidMenu({ onCommentarySelect, onViewChange, selectedCommentaryId }: SolidMenuProps) {
  const [isOpen, setIsOpen] = useState(false);

  const { data: commentaries } = useQuery<Commentary[]>({
    queryKey: ["/api/commentaries"],
  });

  const handleMenuItemClick = (action: () => void) => {
    action();
    setIsOpen(false);
  };

  if (!isOpen) {
    return (
      <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setIsOpen(true)}>
        <Menu className="h-5 w-5" />
        <span className="sr-only">Open menu</span>
      </Button>
    );
  }

  return (
    <>
      {/* Fixed overlay */}
      <div 
        className="fixed inset-0 z-50 bg-black/50"
        onClick={() => setIsOpen(false)}
      />
      
      {/* Menu panel */}
      <div className="fixed inset-y-0 left-0 z-50 w-80 bg-white border-r border-gray-200 shadow-xl overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900">Biblical Commentary Reader</h2>
          <Button variant="ghost" size="icon" onClick={() => setIsOpen(false)}>
            <X className="h-5 w-5" />
          </Button>
        </div>
        
        {/* Menu content */}
        <div className="p-4 space-y-6">
          {/* Commentators */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Users className="h-4 w-4 text-gray-600" />
              <h3 className="font-medium text-sm text-gray-900">Commentators</h3>
            </div>
            <div className="space-y-1">
              {commentaries?.map((commentary) => (
                <button
                  key={commentary.id}
                  className={`w-full text-left p-3 rounded-md transition-colors ${
                    selectedCommentaryId === commentary.id
                      ? "bg-blue-50 border border-blue-200"
                      : "hover:bg-gray-50"
                  }`}
                  onClick={() => handleMenuItemClick(() => {
                    onCommentarySelect(commentary.id);
                    onViewChange('commentary');
                  })}
                >
                  <div className="font-medium text-sm text-gray-900">{commentary.author}</div>
                  <div className="text-xs text-gray-500 truncate">
                    {commentary.title}
                  </div>
                </button>
              ))}
            </div>
          </div>

          <hr className="border-gray-200" />

          {/* Other Commentators */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Users className="h-4 w-4 text-gray-600" />
              <h3 className="font-medium text-sm text-gray-900">Other Commentators</h3>
            </div>
            <button
              className="w-full text-left p-3 rounded-md hover:bg-gray-50 transition-colors"
              onClick={() => handleMenuItemClick(() => onViewChange('other-commentators'))}
            >
              <div className="flex items-center gap-2">
                <Users className="h-4 w-4 text-gray-600" />
                <span className="text-sm text-gray-900">Browse All Romans Commentators</span>
              </div>
            </button>
          </div>

          <hr className="border-gray-200" />

          {/* Study Resources */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <BookOpen className="h-4 w-4 text-gray-600" />
              <h3 className="font-medium text-sm text-gray-900">Study Resources</h3>
            </div>
            <div className="space-y-1">
              <button
                className="w-full text-left p-3 rounded-md hover:bg-gray-50 transition-colors"
                onClick={() => handleMenuItemClick(() => onViewChange('key-themes-dictionary'))}
              >
                <div className="flex items-center gap-2">
                  <BookOpen className="h-4 w-4 text-gray-600" />
                  <span className="text-sm text-gray-900">Key Themes of Romans</span>
                </div>
              </button>
              <button
                className="w-full text-left p-3 rounded-md hover:bg-gray-50 transition-colors"
                onClick={() => handleMenuItemClick(() => onViewChange('dictionary'))}
              >
                <div className="flex items-center gap-2">
                  <Languages className="h-4 w-4 text-gray-600" />
                  <span className="text-sm text-gray-900">Greek Terms Dictionary</span>
                </div>
              </button>
              <button
                className="w-full text-left p-3 rounded-md hover:bg-gray-50 transition-colors"
                onClick={() => handleMenuItemClick(() => onViewChange('kjv'))}
              >
                <div className="flex items-center gap-2">
                  <FileText className="h-4 w-4 text-gray-600" />
                  <span className="text-sm text-gray-900">Romans (KJV Translation)</span>
                </div>
              </button>
              <button
                className="w-full text-left p-3 rounded-md hover:bg-gray-50 transition-colors"
                onClick={() => handleMenuItemClick(() => onViewChange('greek'))}
              >
                <div className="flex items-center gap-2">
                  <Languages className="h-4 w-4 text-gray-600" />
                  <span className="text-sm text-gray-900">Romans (Koine Greek)</span>
                </div>
              </button>
              <button
                className="w-full text-left p-3 rounded-md hover:bg-gray-50 transition-colors"
                onClick={() => handleMenuItemClick(() => onViewChange('russian'))}
              >
                <div className="flex items-center gap-2">
                  <FileText className="h-4 w-4 text-gray-600" />
                  <span className="text-sm text-gray-900">Romans (Russian Synodal)</span>
                </div>
              </button>
              <button
                className="w-full text-left p-3 rounded-md hover:bg-gray-50 transition-colors"
                onClick={() => handleMenuItemClick(() => onViewChange('esv'))}
              >
                <div className="flex items-center gap-2">
                  <FileText className="h-4 w-4 text-gray-600" />
                  <span className="text-sm text-gray-900">Romans (ESV Translation)</span>
                </div>
              </button>
              <button
                className="w-full text-left p-3 rounded-md hover:bg-gray-50 transition-colors"
                onClick={() => handleMenuItemClick(() => onViewChange('echoes'))}
              >
                <div className="flex items-center gap-2">
                  <Quote className="h-4 w-4 text-gray-600" />
                  <span className="text-sm text-gray-900">Echoes of Scripture</span>
                </div>
              </button>
              <button
                className="w-full text-left p-3 rounded-md hover:bg-gray-50 transition-colors"
                onClick={() => handleMenuItemClick(() => onViewChange('romans-timeline'))}
              >
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-gray-600" />
                  <span className="text-sm text-gray-900">Romans Timeline</span>
                </div>
              </button>
              <button
                className="w-full text-left p-3 rounded-md hover:bg-gray-50 transition-colors"
                onClick={() => handleMenuItemClick(() => onViewChange('maps-of-romans'))}
              >
                <div className="flex items-center gap-2">
                  <Map className="h-4 w-4 text-gray-600" />
                  <span className="text-sm text-gray-900">Maps of Romans</span>
                </div>
              </button>
              <button
                className="w-full text-left p-3 rounded-md hover:bg-gray-50 transition-colors"
                onClick={() => handleMenuItemClick(() => onViewChange('background-romans-paul'))}
              >
                <div className="flex items-center gap-2">
                  <Globe className="h-4 w-4 text-gray-600" />
                  <span className="text-sm text-gray-900">Background of Romans and Paul</span>
                </div>
              </button>
            </div>
          </div>

          <hr className="border-gray-200" />

          {/* Preaching Resources */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <BookOpen className="h-4 w-4 text-gray-600" />
              <h3 className="font-medium text-sm text-gray-900">Preaching Resources</h3>
            </div>
            <button
              className="w-full text-left p-3 rounded-md hover:bg-gray-50 transition-colors"
              onClick={() => handleMenuItemClick(() => onViewChange('examples'))}
            >
              <div className="flex items-center gap-2">
                <BookOpen className="h-4 w-4 text-gray-600" />
                <span className="text-sm text-gray-900">Examples for Preachers</span>
              </div>
            </button>
          </div>

          <hr className="border-gray-200" />

          {/* Educational Resources */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Users className="h-4 w-4 text-gray-600" />
              <h3 className="font-medium text-sm text-gray-900">Educational Resources</h3>
            </div>
            <button
              className="w-full text-left p-3 rounded-md hover:bg-gray-50 transition-colors"
              onClick={() => handleMenuItemClick(() => onViewChange('sunday-school'))}
            >
              <div className="flex items-center gap-2">
                <Users className="h-4 w-4 text-gray-600" />
                <span className="text-sm text-gray-900">Sunday/Bible School Resources</span>
              </div>
            </button>
          </div>

          <hr className="border-gray-200" />

          {/* Settings */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <SettingsIcon className="h-4 w-4 text-gray-600" />
              <h3 className="font-medium text-sm text-gray-900">Settings</h3>
            </div>
            <button
              className="w-full text-left p-3 rounded-md hover:bg-gray-50 transition-colors"
              onClick={() => handleMenuItemClick(() => onViewChange('settings'))}
            >
              <div className="flex items-center gap-2">
                <SettingsIcon className="h-4 w-4 text-gray-600" />
                <span className="text-sm text-gray-900">App Settings</span>
              </div>
            </button>
          </div>
        </div>
      </div>
    </>
  );
}