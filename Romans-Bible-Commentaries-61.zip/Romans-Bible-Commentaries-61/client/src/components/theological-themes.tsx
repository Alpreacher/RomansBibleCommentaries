import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { TheologicalTheme } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Book, Search, Filter, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";

interface TheologicalThemesProps {
  onThemeSelect?: (theme: TheologicalTheme) => void;
  selectedThemes?: string[];
}

const categoryLabels = {
  soteriology: "Salvation",
  theology: "God & Christ",
  anthropology: "Human Nature",
  ecclesiology: "Church & Community",
  eschatology: "End Times",
  pneumatology: "Holy Spirit"
};

const categoryColors = {
  soteriology: "bg-blue-100 text-blue-800 border-blue-200",
  theology: "bg-purple-100 text-purple-800 border-purple-200",
  anthropology: "bg-green-100 text-green-800 border-green-200",
  ecclesiology: "bg-orange-100 text-orange-800 border-orange-200",
  eschatology: "bg-red-100 text-red-800 border-red-200",
  pneumatology: "bg-indigo-100 text-indigo-800 border-indigo-200"
};

export function TheologicalThemes({ onThemeSelect, selectedThemes = [] }: TheologicalThemesProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");

  // Fetch all themes
  const { data: themes, isLoading } = useQuery<TheologicalTheme[]>({
    queryKey: ["/api/themes"],
  });

  // Search themes
  const { data: searchResults } = useQuery<TheologicalTheme[]>({
    queryKey: ["/api/themes/search", { q: searchQuery }],
    enabled: searchQuery.length > 2,
  });

  // Filter themes by category
  const filteredThemes = themes?.filter(theme => {
    if (selectedCategory !== "all" && theme.category !== selectedCategory) {
      return false;
    }
    if (searchQuery.length > 2) {
      return searchResults?.some(result => result.id === theme.id);
    }
    return true;
  }) || [];

  const categories = Object.keys(categoryLabels) as Array<keyof typeof categoryLabels>;

  const handleThemeClick = (theme: TheologicalTheme) => {
    onThemeSelect?.(theme);
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center space-x-2 mb-4">
            <Book className="h-5 w-5 text-primary" />
            <h3 className="text-lg font-semibold">Theological Themes</h3>
          </div>
          <div className="space-y-3">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="h-16 bg-gray-100 rounded animate-pulse" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border border-gray-200">
      <CardContent className="p-6">
        <div className="flex items-center space-x-2 mb-4">
          <Book className="h-5 w-5 text-primary" />
          <h3 className="text-lg font-semibold text-gray-900">Theological Themes in Romans</h3>
        </div>

        {/* Search Input */}
        <div className="relative mb-4">
          <Input
            type="text"
            placeholder="Search theological topics..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
        </div>

        {/* Category Tabs */}
        <Tabs value={selectedCategory} onValueChange={setSelectedCategory} className="mb-4">
          <TabsList className="grid w-full grid-cols-3 lg:grid-cols-4 mb-4">
            <TabsTrigger value="all" className="text-xs">All Topics</TabsTrigger>
            <TabsTrigger value="soteriology" className="text-xs">Salvation</TabsTrigger>
            <TabsTrigger value="theology" className="text-xs">God & Christ</TabsTrigger>
            <TabsTrigger value="anthropology" className="text-xs">Human Nature</TabsTrigger>
          </TabsList>
          
          <div className="flex flex-wrap gap-1 mb-4">
            {categories.slice(4).map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(selectedCategory === category ? "all" : category)}
                className="text-xs h-7"
              >
                {categoryLabels[category]}
              </Button>
            ))}
          </div>
        </Tabs>

        {/* Results Count */}
        <div className="flex items-center justify-between mb-3">
          <span className="text-sm text-muted-foreground">
            {filteredThemes.length} theme{filteredThemes.length !== 1 ? 's' : ''} found
          </span>
          {searchQuery && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSearchQuery("")}
              className="text-xs"
            >
              Clear search
            </Button>
          )}
        </div>

        {/* Themes List */}
        <ScrollArea className="h-[400px] pr-4">
          <div className="space-y-3">
            {filteredThemes.map((theme) => {
              const isSelected = selectedThemes.includes(theme.id);
              return (
                <Card
                  key={theme.id}
                  className={cn(
                    "cursor-pointer transition-all duration-200 hover:shadow-md border",
                    isSelected ? "border-primary bg-primary/5" : "border-gray-200 hover:border-gray-300"
                  )}
                  onClick={() => handleThemeClick(theme)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-medium text-gray-900 text-sm leading-tight">
                        {theme.title}
                      </h4>
                      <ChevronRight className="h-4 w-4 text-gray-400 flex-shrink-0 ml-2" />
                    </div>
                    
                    <p className="text-xs text-muted-foreground mb-3 line-clamp-2">
                      {theme.description}
                    </p>
                    
                    <div className="flex items-center justify-between">
                      <Badge 
                        variant="outline" 
                        className={cn("text-xs", categoryColors[theme.category])}
                      >
                        {categoryLabels[theme.category]}
                      </Badge>
                      
                      <div className="flex items-center space-x-1">
                        <span className="text-xs text-muted-foreground">
                          Ch. {theme.relatedChapters.join(", ")}
                        </span>
                      </div>
                    </div>
                    
                    {/* Key Verses Preview */}
                    <div className="mt-2 pt-2 border-t border-gray-100">
                      <div className="flex flex-wrap gap-1">
                        {theme.keyVerses.slice(0, 2).map((verse, index) => (
                          <span key={index} className="text-xs text-primary font-mono bg-primary/10 px-1 rounded">
                            {verse}
                          </span>
                        ))}
                        {theme.keyVerses.length > 2 && (
                          <span className="text-xs text-muted-foreground">
                            +{theme.keyVerses.length - 2} more
                          </span>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </ScrollArea>

        {filteredThemes.length === 0 && searchQuery.length > 2 && (
          <div className="text-center py-8">
            <p className="text-muted-foreground">No themes found for "{searchQuery}"</p>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSearchQuery("")}
              className="mt-2"
            >
              Clear search
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}