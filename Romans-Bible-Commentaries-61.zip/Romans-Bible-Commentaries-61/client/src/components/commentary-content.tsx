import { useQuery } from "@tanstack/react-query";
import { Commentary } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { ChevronLeft, ChevronRight, Copy, Share, Type, Bookmark } from "lucide-react";

interface CommentaryContentProps {
  commentaryId: number;
  chapter: number;
  commentary?: Commentary;
  onChapterChange: (chapter: number) => void;
  onNavigateToThemes?: (theme: string) => void;
}

export function CommentaryContent({
  commentaryId,
  chapter,
  commentary,
  onChapterChange,
  onNavigateToThemes
}: CommentaryContentProps) {
  const { data: chapterData, isLoading } = useQuery<any>({
    queryKey: ["/api/commentaries", commentaryId, "chapters", chapter],
    enabled: !!commentaryId && !!chapter,
  });

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto">
        <div className="mb-6">
          <Skeleton className="h-8 w-64 mb-3" />
          <Skeleton className="h-6 w-96" />
        </div>
        <div className="space-y-4">
          <Skeleton className="h-6 w-48" />
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-3/4" />
        </div>
      </div>
    );
  }

  if (!chapterData || !commentary) {
    return (
      <div className="max-w-4xl mx-auto text-center py-12">
        <p className="text-muted-foreground text-lg">Chapter content not available</p>
      </div>
    );
  }

  const canGoPrevious = chapter > 1;
  const canGoNext = chapter < 16;

  return (
    <div className="max-w-4xl mx-auto">
      {/* Commentary Header */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-2">{chapterData.title}</h1>
            <p className="text-base text-gray-600 dark:text-gray-400">
              {commentary.title} ({commentary.year})
            </p>
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm" className="text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-100">
              <Type className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm" className="text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-100">
              <Copy className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="sm" className="text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-100">
              <Share className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Commentary Text */}
      <div className="">
        <div className="prose prose-lg max-w-none">
          {/* Introduction */}
          <div className="mb-8">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-gray-100 mb-4">Introduction</h2>
            <p className="text-gray-700 dark:text-gray-300 leading-relaxed text-lg">
              {chapterData.introduction}
            </p>
          </div>

          {/* Sections */}
          {chapterData.sections?.map((section: any, index: number) => (
            <div
              key={index}
              className="mb-8 py-6 border-l-4 pl-6 border-blue-300 dark:border-blue-600"
            >
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-3">
                {section.verses} - {section.title}
              </h3>
              <p className="text-gray-700 dark:text-gray-300 leading-relaxed text-base">
                {section.content}
              </p>
            </div>
          ))}

          {/* Key Themes */}
          {chapterData.keyThemes && (
            <div className="mt-10 pt-8 border-t border-gray-200 dark:border-gray-700">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-4">Key Themes in Chapter {chapter}:</h3>
              <div className="flex flex-wrap gap-3">
                {chapterData.keyThemes.map((theme: string, index: number) => (
                  <Badge 
                    key={index} 
                    variant="secondary"
                    className="cursor-pointer hover:bg-primary hover:text-white transition-colors py-2 px-3 text-sm"
                    onClick={() => onNavigateToThemes?.(theme)}
                  >
                    {theme}
                  </Badge>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Navigation */}
        <div className="flex items-center justify-between mt-12 pt-8 border-t border-gray-200 dark:border-gray-700">
          <Button
            variant="outline"
            disabled={!canGoPrevious}
            onClick={() => canGoPrevious && onChapterChange(chapter - 1)}
            className="flex items-center space-x-2"
          >
            <ChevronLeft className="h-4 w-4" />
            <span>Back</span>
          </Button>
          
          <div className="flex items-center space-x-4">
            <span className="text-sm text-gray-600 dark:text-gray-400">
              Chapter {chapter} of 16
            </span>
            <Button variant="ghost" size="sm">
              <Bookmark className="h-4 w-4" />
            </Button>
          </div>
          
          <Button
            variant="outline"
            disabled={!canGoNext}
            onClick={() => canGoNext && onChapterChange(chapter + 1)}
            className="flex items-center space-x-2"
          >
            <span>Next</span>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
