import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Search, BookOpen, Calendar, User, Star, ExternalLink } from "lucide-react";

interface Commentator {
  id: string;
  name: string;
  title: string;
  year: number;
  publisher: string;
  pages: string;
  approach: 'exegetical' | 'expository' | 'devotional' | 'critical' | 'theological' | 'pastoral';
  difficulty: 'beginner' | 'intermediate' | 'advanced' | 'scholarly';
  description: string;
  recommendedBy: string[];
  notableFeatures: string[];
  availability: 'print' | 'digital' | 'both' | 'archive';
}

// Comprehensive list based on bibliographies from major Romans scholars
const commentators: Commentator[] = [
  // Classic/Historical Commentators
  {
    id: "barth",
    name: "Karl Barth",
    title: "The Epistle to the Romans",
    year: 1933,
    publisher: "Oxford University Press",
    pages: "547",
    approach: "theological",
    difficulty: "advanced",
    description: "Revolutionary theological commentary that helped launch dialectical theology. Emphasizes God's transcendence and the 'infinite qualitative difference' between God and humanity.",
    recommendedBy: ["Schreiner", "Cranfield", "Gaventa"],
    notableFeatures: ["Theological depth", "Revolutionary interpretation", "Dialectical method"],
    availability: "both"
  },
  {
    id: "calvin",
    name: "John Calvin",
    title: "Commentary on Romans",
    year: 1540,
    publisher: "Various (Calvin Translation Society)",
    pages: "534",
    approach: "exegetical",
    difficulty: "intermediate",
    description: "Classic Reformation commentary emphasizing justification by faith and God's sovereignty. Clear, pastoral exposition with theological precision.",
    recommendedBy: ["Boice", "Moo", "Schreiner"],
    notableFeatures: ["Reformation theology", "Pastoral application", "Clear exposition"],
    availability: "both"
  },
  {
    id: "luther",
    name: "Martin Luther",
    title: "Lectures on Romans (1515-1516)",
    year: 1515,
    publisher: "Luther's Works, Volume 25",
    pages: "542",
    approach: "theological",
    difficulty: "intermediate",
    description: "Historic lectures that sparked the Reformation. Focus on justification by faith alone and the righteousness of God as gift rather than demand.",
    recommendedBy: ["Boice", "Gaventa", "Cranfield"],
    notableFeatures: ["Reformation breakthrough", "Sola fide emphasis", "Historical significance"],
    availability: "both"
  },
  {
    id: "chrysostom",
    name: "John Chrysostom",
    title: "Homilies on Romans",
    year: 391,
    publisher: "NPNF Series 1, Volume 11",
    pages: "Multiple volumes",
    approach: "expository",
    difficulty: "intermediate",
    description: "Earliest complete commentary on Romans. Emphasizes practical Christian living and moral transformation through detailed verse-by-verse exposition.",
    recommendedBy: ["Cranfield", "Moo"],
    notableFeatures: ["Patristic perspective", "Practical application", "Verse-by-verse"],
    availability: "digital"
  },
  
  // Modern Critical Commentators
  {
    id: "kasemann",
    name: "Ernst Käsemann",
    title: "Commentary on Romans",
    year: 1980,
    publisher: "Eerdmans",
    pages: "428",
    approach: "critical",
    difficulty: "scholarly",
    description: "Influential German critical commentary emphasizing apocalyptic theology and justification as God's saving power. Major impact on Pauline studies.",
    recommendedBy: ["Schreiner", "Gaventa", "Cranfield"],
    notableFeatures: ["Apocalyptic framework", "Critical scholarship", "German tradition"],
    availability: "print"
  },
  {
    id: "fitzmyer",
    name: "Joseph A. Fitzmyer",
    title: "Romans (Anchor Bible)",
    year: 1993,
    publisher: "Doubleday",
    pages: "790",
    approach: "critical",
    difficulty: "scholarly",
    description: "Comprehensive critical commentary with extensive interaction with Jewish background and Greco-Roman context. Excellent for historical-critical analysis.",
    recommendedBy: ["Moo", "Schreiner", "Gaventa"],
    notableFeatures: ["Historical context", "Jewish background", "Critical apparatus"],
    availability: "both"
  },
  {
    id: "dunn",
    name: "James D.G. Dunn",
    title: "Romans (Word Biblical Commentary)",
    year: 1988,
    publisher: "Word Books",
    pages: "974 (2 volumes)",
    approach: "critical",
    difficulty: "scholarly",
    description: "Major proponent of the 'New Perspective on Paul.' Emphasizes covenantal context and critique of 'works of the law' as ethnic boundary markers.",
    recommendedBy: ["Gaventa", "Moo", "Schreiner"],
    notableFeatures: ["New Perspective", "Covenantal theology", "Social context"],
    availability: "both"
  },
  {
    id: "wright",
    name: "N.T. Wright",
    title: "Romans (New Interpreters Bible)",
    year: 2002,
    publisher: "Abingdon Press",
    pages: "760",
    approach: "theological",
    difficulty: "advanced",
    description: "Influential 'New Perspective' commentary emphasizing covenant, narrative, and Second Temple Judaism. Focus on God's faithfulness to Israel and inclusion of Gentiles.",
    recommendedBy: ["Gaventa", "Schreiner"],
    notableFeatures: ["Narrative theology", "Second Temple context", "Covenant faithfulness"],
    availability: "both"
  },
  
  // Contemporary Evangelical Commentators
  {
    id: "stott",
    name: "John R.W. Stott",
    title: "Romans: God's Good News for the World",
    year: 1994,
    publisher: "IVP",
    pages: "448",
    approach: "expository",
    difficulty: "intermediate",
    description: "Clear, pastoral exposition combining scholarly insight with practical application. Excellent for preachers and serious Bible students.",
    recommendedBy: ["Boice", "Moo"],
    notableFeatures: ["Pastoral wisdom", "Clear exposition", "Practical application"],
    availability: "both"
  },
  {
    id: "piper",
    name: "John Piper",
    title: "Romans: The Greatest Letter Ever Written",
    year: 2007,
    publisher: "Crossway",
    pages: "928",
    approach: "expository",
    difficulty: "intermediate",
    description: "Passionate expository commentary emphasizing God's glory and the supremacy of Christ. Strong emphasis on Christian hedonism and joy in God.",
    recommendedBy: ["Boice"],
    notableFeatures: ["God's glory emphasis", "Christian hedonism", "Passionate exposition"],
    availability: "both"
  },
  {
    id: "morris",
    name: "Leon Morris",
    title: "The Epistle to the Romans",
    year: 1988,
    publisher: "Eerdmans/IVP",
    pages: "560",
    approach: "exegetical",
    difficulty: "intermediate",
    description: "Solid evangelical commentary with careful attention to Greek text and theological themes. Balanced approach between scholarship and accessibility.",
    recommendedBy: ["Moo", "Boice"],
    notableFeatures: ["Greek text focus", "Theological balance", "Evangelical perspective"],
    availability: "both"
  },
  {
    id: "bruce",
    name: "F.F. Bruce",
    title: "Romans (Tyndale New Testament Commentary)",
    year: 1985,
    publisher: "IVP/Eerdmans",
    pages: "288",
    approach: "exegetical",
    difficulty: "intermediate",
    description: "Concise yet thorough commentary by a master expositor. Excellent introduction to Romans with careful attention to historical context.",
    recommendedBy: ["Moo", "Boice", "Schreiner"],
    notableFeatures: ["Concise treatment", "Historical context", "Master expositor"],
    availability: "both"
  },
  
  // Specialized Approaches
  {
    id: "witherington",
    name: "Ben Witherington III",
    title: "Paul's Letter to the Romans: A Socio-Rhetorical Commentary",
    year: 2004,
    publisher: "Eerdmans",
    pages: "416",
    approach: "critical",
    difficulty: "advanced",
    description: "Innovative commentary using rhetorical criticism and social-scientific analysis. Focus on Paul's persuasive strategy and ancient rhetorical conventions.",
    recommendedBy: ["Gaventa", "Schreiner"],
    notableFeatures: ["Rhetorical analysis", "Social context", "Persuasive strategy"],
    availability: "both"
  },
  {
    id: "jewett",
    name: "Robert Jewett",
    title: "Romans (Hermeneia)",
    year: 2007,
    publisher: "Fortress Press",
    pages: "1136",
    approach: "critical",
    difficulty: "scholarly",
    description: "Massive critical commentary with extensive background material and interaction with ancient sources. Emphasizes honor-shame dynamics and Roman context.",
    recommendedBy: ["Gaventa", "Schreiner"],
    notableFeatures: ["Extensive background", "Honor-shame culture", "Roman context"],
    availability: "both"
  },
  {
    id: "godet",
    name: "Frédéric Godet",
    title: "Commentary on Romans",
    year: 1883,
    publisher: "T&T Clark (reprint)",
    pages: "542",
    approach: "exegetical",
    difficulty: "advanced",
    description: "Classic 19th-century commentary with careful exegetical analysis. Strong on theological argument structure and logical flow of Paul's reasoning.",
    recommendedBy: ["Cranfield", "Moo"],
    notableFeatures: ["Logical analysis", "Theological structure", "Classical approach"],
    availability: "archive"
  },
  {
    id: "nygren",
    name: "Anders Nygren",
    title: "Commentary on Romans",
    year: 1949,
    publisher: "Fortress Press",
    pages: "456",
    approach: "theological",
    difficulty: "advanced",
    description: "Swedish Lutheran commentary emphasizing agape love and the contrast between eros and agape. Influential in 20th-century Pauline studies.",
    recommendedBy: ["Cranfield", "Gaventa"],
    notableFeatures: ["Agape theology", "Lutheran perspective", "Love-centered"],
    availability: "print"
  },
  
  // Devotional and Pastoral Commentaries
  {
    id: "stott-bst",
    name: "John R.W. Stott",
    title: "The Message of Romans: God's Good News for the World (BST)",
    year: 1994,
    publisher: "IVP",
    pages: "448",
    approach: "devotional",
    difficulty: "intermediate",
    description: "Widely regarded as the best first commentary on Romans for devotional and pastoral use. Combines solid scholarship with warm pastoral heart and excellent practical application.",
    recommendedBy: ["Boice", "Moo", "Challies", "Gospel Coalition"],
    notableFeatures: ["Accessible warmth", "Excellent for Bible study", "Contemporary application", "Pastor's heart"],
    availability: "both"
  },
  {
    id: "boice-4vol",
    name: "James Montgomery Boice",
    title: "Romans (4-Volume Expositional Commentary)",
    year: 1991,
    publisher: "Baker Books",
    pages: "1700+ (4 volumes)",
    approach: "devotional",
    difficulty: "intermediate",
    description: "Excellent devotional commentary by seasoned Reformed pastor. Very accessible, not dense, perfect for meditation and deep devotional study with pastoral warmth.",
    recommendedBy: ["Stott", "MacArthur", "Challies"],
    notableFeatures: ["Pastoral warmth", "Reformed perspective", "Meditation-friendly", "Practical application"],
    availability: "both"
  },
  {
    id: "lloyd-jones",
    name: "D. Martyn Lloyd-Jones",
    title: "Romans: An Exposition of Chapters 1-14 (14 volumes)",
    year: 1970,
    publisher: "Banner of Truth",
    pages: "Multiple volumes",
    approach: "expository",
    difficulty: "intermediate",
    description: "Based on Lloyd-Jones' famous Westminster Chapel sermon series. Expositional preaching at its finest, covering Romans 1-14 (incomplete due to health). Reformed expositional approach.",
    recommendedBy: ["Boice", "MacArthur", "Piper"],
    notableFeatures: ["Sermon-based", "Expositional model", "Westminster Chapel series", "Reformed tradition"],
    availability: "both"
  },
  {
    id: "macarthur",
    name: "John MacArthur",
    title: "Romans 1-8 (MacArthur New Testament Commentary)",
    year: 1991,
    publisher: "Moody Publishers",
    pages: "512",
    approach: "expository",
    difficulty: "intermediate",
    description: "Clear, practical verse-by-verse devotional study. Strong evangelical perspective with excellent accessibility for college-level readers and personal study.",
    recommendedBy: ["Boice", "Lloyd-Jones"],
    notableFeatures: ["Verse-by-verse", "Clear exposition", "Personal study", "Evangelical perspective"],
    availability: "both"
  },
  {
    id: "moo-nivac",
    name: "Douglas J. Moo",
    title: "Romans (NIV Application Commentary)",
    year: 2000,
    publisher: "Zondervan",
    pages: "544",
    approach: "pastoral",
    difficulty: "intermediate",
    description: "Bridges the gap from Paul's world to ours with strong focus on practical application. More digestible than Moo's technical NICNT volume, perfect for pastors wanting application focus.",
    recommendedBy: ["Stott", "Carson", "Challies"],
    notableFeatures: ["Application focus", "Contemporary relevance", "Pastoral emphasis", "Practical"],
    availability: "both"
  },
  {
    id: "kruse",
    name: "Colin G. Kruse",
    title: "Romans (Pillar New Testament Commentary)",
    year: 2012,
    publisher: "Eerdmans",
    pages: "608",
    approach: "pastoral",
    difficulty: "intermediate",
    description: "Solid evangelical treatment without exhaustive detail. Sound judgment, doesn't dodge difficult issues. Good for pastors in time crunch with reliable, erudite approach.",
    recommendedBy: ["Carson", "Moo"],
    notableFeatures: ["Reliable scholarship", "Time-efficient", "Sound judgment", "Evangelical"],
    availability: "both"
  },
  {
    id: "mathis",
    name: "David Mathis",
    title: "Romans: The Hope of Glory",
    year: 2022,
    publisher: "Crossway",
    pages: "320",
    approach: "devotional",
    difficulty: "beginner",
    description: "Accessible devotional commentary that brings readers back to salvation in Christ repeatedly. Well-outlined with exposition, key points, and application. Beneficial for Bible teachers.",
    recommendedBy: ["Piper", "Challies"],
    notableFeatures: ["Contemporary", "Accessible", "Bible teacher resource", "Christ-centered"],
    availability: "both"
  },
  {
    id: "hendriksen",
    name: "William Hendriksen",
    title: "Romans (New Testament Commentary)",
    year: 1980,
    publisher: "Baker Academic",
    pages: "464",
    approach: "devotional",
    difficulty: "intermediate",
    description: "Reformed devotional commentary with pastoral warmth and practical application. Excellent for personal study and sermon preparation with clear, accessible style.",
    recommendedBy: ["Boice", "Stott"],
    notableFeatures: ["Reformed perspective", "Pastoral warmth", "Sermon preparation", "Clear style"],
    availability: "both"
  },
  {
    id: "phillips",
    name: "John Phillips",
    title: "Exploring Romans",
    year: 1969,
    publisher: "Kregel Publications",
    pages: "288",
    approach: "devotional",
    difficulty: "beginner",
    description: "Practical, devotional approach emphasizing spiritual application and Christian living. Excellent for lay readers and personal devotional study with warm, accessible style.",
    recommendedBy: ["MacArthur"],
    notableFeatures: ["Devotional focus", "Lay-friendly", "Spiritual application", "Accessible"],
    availability: "both"
  },
  {
    id: "wiersbe",
    name: "Warren W. Wiersbe",
    title: "Be Right: Romans (BE Series)",
    year: 1977,
    publisher: "David C Cook",
    pages: "176",
    approach: "devotional",
    difficulty: "beginner",
    description: "Popular devotional commentary emphasizing practical Christian living and spiritual growth. Part of the beloved BE Series, excellent for Bible study groups and personal devotions.",
    recommendedBy: ["Swindoll", "Stanley"],
    notableFeatures: ["BE Series", "Practical living", "Bible study groups", "Spiritual growth"],
    availability: "both"
  },
  {
    id: "morgan",
    name: "G. Campbell Morgan",
    title: "The Epistle of Paul the Apostle to the Romans",
    year: 1916,
    publisher: "Revell (various reprints)",
    pages: "384",
    approach: "expository",
    difficulty: "intermediate",
    description: "Classic expository commentary from the golden age of preaching. Strong on homiletical structure and practical application with devotional warmth from a master expositor.",
    recommendedBy: ["Lloyd-Jones", "Spurgeon tradition"],
    notableFeatures: ["Classic exposition", "Homiletical structure", "Master expositor", "Devotional warmth"],
    availability: "archive"
  },
  {
    id: "newell",
    name: "William R. Newell",
    title: "Romans Verse by Verse",
    year: 1938,
    publisher: "Moody Press",
    pages: "560",
    approach: "devotional",
    difficulty: "intermediate",
    description: "Verse-by-verse devotional commentary with strong emphasis on grace and dispensational theology. Popular among Bible teachers and students for personal study and teaching preparation.",
    recommendedBy: ["Dispensational tradition"],
    notableFeatures: ["Verse-by-verse", "Grace emphasis", "Dispensational", "Teaching resource"],
    availability: "both"
  },
  
  // Women Scholars
  {
    id: "elliott",
    name: "Susan Elliott",
    title: "Cutting Too Close for Comfort: Paul's Letter to the Romans",
    year: 2010,
    publisher: "T&T Clark",
    pages: "256",
    approach: "critical",
    difficulty: "advanced",
    description: "Feminist and postcolonial reading of Romans emphasizing social justice themes and critique of imperial power structures.",
    recommendedBy: ["Gaventa"],
    notableFeatures: ["Feminist perspective", "Social justice", "Imperial critique"],
    availability: "both"
  },
  {
    id: "keck",
    name: "Leander Keck",
    title: "Romans (Abingdon New Testament Commentary)",
    year: 2005,
    publisher: "Abingdon Press",
    pages: "384",
    approach: "critical",
    difficulty: "intermediate",
    description: "Balanced critical commentary emphasizing theological themes and practical application for contemporary readers.",
    recommendedBy: ["Gaventa", "Schreiner"],
    notableFeatures: ["Theological focus", "Contemporary application", "Balanced approach"],
    availability: "both"
  }
];

export function OtherCommentators() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedApproach, setSelectedApproach] = useState<string>("all");
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>("all");
  const [selectedCommentator, setSelectedCommentator] = useState<Commentator | null>(null);

  const approaches = {
    all: "All Approaches",
    exegetical: "Exegetical",
    expository: "Expository", 
    devotional: "Devotional",
    critical: "Critical",
    theological: "Theological",
    pastoral: "Pastoral"
  };

  const difficulties = {
    all: "All Levels",
    beginner: "Beginner",
    intermediate: "Intermediate",
    advanced: "Advanced",
    scholarly: "Scholarly"
  };

  const filteredCommentators = commentators.filter(commentator => {
    const matchesSearch = searchQuery === "" || 
      commentator.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      commentator.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      commentator.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesApproach = selectedApproach === "all" || commentator.approach === selectedApproach;
    const matchesDifficulty = selectedDifficulty === "all" || commentator.difficulty === selectedDifficulty;
    
    return matchesSearch && matchesApproach && matchesDifficulty;
  });

  const getApproachColor = (approach: string) => {
    switch (approach) {
      case 'exegetical': return 'bg-blue-100 text-blue-800';
      case 'expository': return 'bg-green-100 text-green-800';
      case 'devotional': return 'bg-purple-100 text-purple-800';
      case 'critical': return 'bg-red-100 text-red-800';
      case 'theological': return 'bg-yellow-100 text-yellow-800';
      case 'pastoral': return 'bg-indigo-100 text-indigo-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner': return 'text-green-600';
      case 'intermediate': return 'text-blue-600';
      case 'advanced': return 'text-orange-600';
      case 'scholarly': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  const getAvailabilityIcon = (availability: string) => {
    switch (availability) {
      case 'both': return '📚📱';
      case 'print': return '📚';
      case 'digital': return '📱';
      case 'archive': return '🏛️';
      default: return '❓';
    }
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Other Romans Commentators</h2>
        <p className="text-gray-600 mb-4">
          Comprehensive list from bibliographies of Schreiner, Boice, Cranfield, Moo, and Gaventa, plus top devotional and pastoral commentaries
        </p>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardHeader>
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search commentators, titles, or descriptions..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            
            <div className="flex gap-2">
              <select 
                value={selectedApproach} 
                onChange={(e) => setSelectedApproach(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {Object.entries(approaches).map(([key, label]) => (
                  <option key={key} value={key}>{label}</option>
                ))}
              </select>
              
              <select 
                value={selectedDifficulty} 
                onChange={(e) => setSelectedDifficulty(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {Object.entries(difficulties).map(([key, label]) => (
                  <option key={key} value={key}>{label}</option>
                ))}
              </select>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Results Count */}
      <div className="text-sm text-gray-600">
        Showing {filteredCommentators.length} of {commentators.length} commentators
      </div>

      {/* Commentators Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCommentators.map((commentator) => (
          <Card key={commentator.id} className="cursor-pointer hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex items-start justify-between mb-2">
                <div className="flex-1">
                  <CardTitle className="text-lg leading-tight mb-1">{commentator.name}</CardTitle>
                  <p className="text-sm text-gray-600 mb-2 line-clamp-2">{commentator.title}</p>
                  <div className="flex items-center gap-2 mb-2">
                    <Badge className={getApproachColor(commentator.approach)}>
                      {commentator.approach}
                    </Badge>
                    <span className={`text-xs font-medium ${getDifficultyColor(commentator.difficulty)}`}>
                      {commentator.difficulty}
                    </span>
                  </div>
                </div>
                <div className="text-right text-xs text-gray-500">
                  <div className="flex items-center gap-1 mb-1">
                    <Calendar className="h-3 w-3" />
                    {commentator.year}
                  </div>
                  <div>{getAvailabilityIcon(commentator.availability)}</div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-700 mb-3 line-clamp-3">
                {commentator.description}
              </p>
              
              <div className="space-y-2 mb-3">
                <div className="text-xs text-gray-600">
                  <strong>Publisher:</strong> {commentator.publisher}
                </div>
                <div className="text-xs text-gray-600">
                  <strong>Pages:</strong> {commentator.pages}
                </div>
              </div>

              <div className="flex flex-wrap gap-1 mb-3">
                {commentator.recommendedBy.slice(0, 2).map((scholar) => (
                  <Badge key={scholar} variant="outline" className="text-xs">
                    {scholar}
                  </Badge>
                ))}
                {commentator.recommendedBy.length > 2 && (
                  <Badge variant="outline" className="text-xs">
                    +{commentator.recommendedBy.length - 2} more
                  </Badge>
                )}
              </div>
              
              <Button 
                variant="outline" 
                size="sm" 
                className="w-full"
                onClick={() => setSelectedCommentator(commentator)}
              >
                View Details
                <ExternalLink className="h-3 w-3 ml-1" />
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Detailed View Modal */}
      {selectedCommentator && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="fixed inset-0 bg-black bg-opacity-50" onClick={() => setSelectedCommentator(null)} />
          <Card className="relative max-w-4xl w-full max-h-[90vh] bg-white">
            <CardHeader className="border-b">
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-xl mb-2">{selectedCommentator.name}</CardTitle>
                  <p className="text-lg text-gray-700 mb-2">{selectedCommentator.title}</p>
                  <div className="flex items-center gap-2 mb-2">
                    <Badge className={getApproachColor(selectedCommentator.approach)}>
                      {selectedCommentator.approach}
                    </Badge>
                    <span className={`font-medium ${getDifficultyColor(selectedCommentator.difficulty)}`}>
                      {selectedCommentator.difficulty}
                    </span>
                    <Badge variant="outline">
                      {selectedCommentator.year}
                    </Badge>
                  </div>
                </div>
                <Button variant="ghost" size="sm" onClick={() => setSelectedCommentator(null)}>
                  ✕
                </Button>
              </div>
            </CardHeader>
            <ScrollArea className="h-[60vh]">
              <CardContent className="p-6 space-y-6">
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">Description</h3>
                  <p className="text-gray-700 leading-relaxed">
                    {selectedCommentator.description}
                  </p>
                </div>
                
                <Separator />
                
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">Publication Details</h3>
                    <div className="space-y-1 text-sm text-gray-600">
                      <div><strong>Publisher:</strong> {selectedCommentator.publisher}</div>
                      <div><strong>Year:</strong> {selectedCommentator.year}</div>
                      <div><strong>Pages:</strong> {selectedCommentator.pages}</div>
                      <div><strong>Availability:</strong> {selectedCommentator.availability}</div>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">Recommended By</h3>
                    <div className="flex flex-wrap gap-1">
                      {selectedCommentator.recommendedBy.map((scholar) => (
                        <Badge key={scholar} variant="outline" className="text-xs">
                          {scholar}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">Notable Features</h3>
                  <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                    {selectedCommentator.notableFeatures.map((feature, index) => (
                      <li key={index}>{feature}</li>
                    ))}
                  </ul>
                </div>
                
                <div className="bg-blue-50 p-4 rounded-lg">
                  <p className="text-sm text-blue-800">
                    <strong>Note:</strong> This list is compiled from the bibliographies and recommendations 
                    of leading Romans scholars including Thomas Schreiner, James Montgomery Boice, 
                    C.E.B. Cranfield, Douglas Moo, and Beverly Roberts Gaventa, supplemented with top 
                    devotional and pastoral commentaries from "Best Commentaries on Romans" websites. 
                    Each commentary offers unique insights and approaches to Paul's letter.
                  </p>
                </div>
              </CardContent>
            </ScrollArea>
          </Card>
        </div>
      )}

      {/* No Results */}
      {filteredCommentators.length === 0 && (
        <Card className="text-center py-12">
          <CardContent>
            <User className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              No Commentators Found
            </h3>
            <p className="text-gray-600">
              Try adjusting your search criteria or filters.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}