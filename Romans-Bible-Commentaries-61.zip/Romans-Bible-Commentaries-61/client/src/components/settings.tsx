import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Separator } from "@/components/ui/separator";
import { Moon, Sun, Type, AlignLeft, Palette } from "lucide-react";

interface SettingsProps {
  fontSize: number;
  lineSpacing: number;
  onFontSizeChange: (size: number) => void;
  onLineSpacingChange: (spacing: number) => void;
}

type ThemeOption = 'light' | 'dark';

interface Theme {
  id: ThemeOption;
  name: string;
  description: string;
  preview: {
    bg: string;
    text: string;
    accent: string;
  };
}

const themes: Theme[] = [
  {
    id: 'light',
    name: 'Light',
    description: 'Clean, bright interface',
    preview: { bg: '#ffffff', text: '#1a1a1a', accent: '#3b82f6' }
  },
  {
    id: 'dark',
    name: 'Dark',
    description: 'Easy on the eyes for low-light reading',
    preview: { bg: '#141414', text: '#f2f2f2', accent: '#3b82f6' }
  }
];

export function Settings({ fontSize, lineSpacing, onFontSizeChange, onLineSpacingChange }: SettingsProps) {
  const [theme, setTheme] = useState<ThemeOption>('light');

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme') as ThemeOption | null;
    const systemTheme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    const initialTheme = savedTheme || systemTheme;
    
    setTheme(initialTheme);
    applyTheme(initialTheme);
  }, []);

  const applyTheme = (selectedTheme: ThemeOption) => {
    // Remove all theme classes
    document.documentElement.classList.remove('dark');
    
    // Apply the selected theme
    if (selectedTheme === 'dark') {
      document.documentElement.classList.add('dark');
    }
  };

  const handleThemeChange = (selectedTheme: ThemeOption) => {
    setTheme(selectedTheme);
    localStorage.setItem('theme', selectedTheme);
    applyTheme(selectedTheme);
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-foreground mb-2">Settings</h1>
        <p className="text-base text-muted-foreground">
          Customize your reading experience
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Palette className="h-5 w-5" />
            Color Scheme
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <Label className="text-base font-medium">Choose your preferred theme</Label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {themes.map((themeOption) => (
                <Button
                  key={themeOption.id}
                  variant={theme === themeOption.id ? "default" : "outline"}
                  className="h-auto p-4 flex flex-col items-start gap-3 text-left"
                  onClick={() => handleThemeChange(themeOption.id)}
                >
                  <div className="flex items-center gap-3 w-full">
                    <div 
                      className="w-8 h-8 rounded-lg border-2 border-current flex-shrink-0"
                      style={{ 
                        backgroundColor: themeOption.preview.bg,
                        borderColor: themeOption.preview.accent 
                      }}
                    >
                      <div 
                        className="w-full h-full rounded-md opacity-70"
                        style={{ 
                          background: `linear-gradient(135deg, ${themeOption.preview.text}20, ${themeOption.preview.accent}30)`
                        }}
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-sm">{themeOption.name}</div>
                      <div className="text-xs text-muted-foreground mt-1 line-clamp-2">
                        {themeOption.description}
                      </div>
                    </div>
                  </div>
                </Button>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Type className="h-5 w-5" />
            Text Settings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-8">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label className="text-base font-medium">Font Size</Label>
              <span className="text-sm text-muted-foreground min-w-[3rem]">
                {fontSize}px
              </span>
            </div>
            <Slider
              value={[fontSize]}
              onValueChange={(value) => onFontSizeChange(value[0])}
              min={14}
              max={24}
              step={1}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>Small</span>
              <span>Medium</span>
              <span>Large</span>
            </div>
          </div>

          <Separator />

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label className="text-base font-medium">Line Spacing</Label>
              <span className="text-sm text-muted-foreground min-w-[3rem]">
                {lineSpacing}
              </span>
            </div>
            <Slider
              value={[lineSpacing]}
              onValueChange={(value) => onLineSpacingChange(value[0])}
              min={1.2}
              max={2.0}
              step={0.1}
              className="w-full"
            />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>Tight</span>
              <span>Normal</span>
              <span>Loose</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <AlignLeft className="h-5 w-5" />
            Preview
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div 
            className="p-4 bg-muted rounded-lg border border-border"
            style={{ 
              fontSize: `${fontSize}px`, 
              lineHeight: lineSpacing 
            }}
          >
            <p className="text-foreground">
              For I am not ashamed of the gospel of Christ: for it is the power of God unto salvation 
              to every one that believeth; to the Jew first, and also to the Greek. For therein is 
              the righteousness of God revealed from faith to faith: as it is written, The just shall 
              live by faith.
            </p>
            <p className="text-sm text-muted-foreground mt-2 italic">
              Romans 1:16-17 (Preview with current settings)
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}