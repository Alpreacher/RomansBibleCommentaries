import { useState } from "react";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, ExternalLink, Search } from "lucide-react";
import { CrossReferences } from "@/components/cross-references";
import { TextToSpeech } from "@/components/text-to-speech";

interface RussianTextProps {
  chapter: number;
  onChapterChange?: (chapter: number) => void;
}

// Russian Romans text data (sample)
const russianRomansText: Record<number, { title: string; text: string; references: string[] }> = {
  1: {
    title: "К Римлянам глава 1 (Синодальный перевод)",
    text: `1 Павел, раб Иисуса Христа, призванный Апостол, избранный к благовестию Божию,
2 которое Бог прежде обещал через пророков Своих, в святых писаниях,
3 о Сыне Своем, Который родился от семени Давидова по плоти
4 и открылся Сыном Божиим в силе, по духу святыни, через воскресение из мертвых, о Иисусе Христе Господе нашем,
5 через Которого мы получили благодать и апостольство, чтобы во имя Его покорять вере все народы,
6 между которыми находитесь и вы, призванные Иисусом Христом,
7 всем находящимся в Риме возлюбленным Божиим, призванным святым: благодать вам и мир от Бога Отца нашего и Господа Иисуса Христа.
8 Прежде всего благодарю Бога моего через Иисуса Христа за всех вас, что вера ваша возвещается во всем мире.
9 Свидетель мне Бог, Которому служу духом моим в благовествовании Сына Его, что непрестанно воспоминаю о вас,
10 всегда прося в молитвах моих, чтобы воля Божия когда-нибудь благопоспешила мне придти к вам,
11 ибо я весьма желаю увидеть вас, чтобы преподать вам некое дарование духовное к утверждению вашему,
12 то есть утешиться с вами взаимно верою друг друга, вашею и моею.
13 Не хочу, братия, оставить вас в неведении, что я многократно намеревался придти к вам (но встречал препятствия даже доныне), чтобы иметь некий плод и у вас, как и у прочих народов.
14 Я должник и Еллинам и варварам, мудрецам и невеждам.
15 Итак, что до меня, я готов благовествовать и вам, находящимся в Риме.
16 Ибо я не стыжусь благовествования Христова, потому что оно есть сила Божия ко спасению всякому верующему, во-первых, Иудею, потом и Еллину.
17 В нем открывается правда Божия от веры в веру, как написано: праведный верою жив будет.`,
    references: ["Аввакум 2:4", "Исаия 52:7", "Псалом 97:2", "Бытие 12:3", "2 Тимофею 1:11"]
  }
};

// Add chapters 2-16 with representative text for development
for (let i = 2; i <= 16; i++) {
  russianRomansText[i] = {
    title: `К Римлянам глава ${i} (Синодальный перевод)`,
    text: `[Глава ${i} - Русский синодальный текст будет загружен здесь]

1 [Первый стих Римлянам ${i}...]
2 [Второй стих Римлянам ${i}...]
3 [Третий стих Римлянам ${i}...]

Примечание: В производственном приложении здесь будет содержаться полный текст послания к Римлянам глава ${i} из Русского Синодального перевода. Текст сокращен здесь для целей разработки.`,
    references: [`Исаия 1:${i}`, `Псалом ${i}0:1`, `Матфея 5:${i}`]
  };
}

export function RussianText({ chapter, onChapterChange }: RussianTextProps) {
  const [showCrossReferences, setShowCrossReferences] = useState(false);
  const chapterData = russianRomansText[chapter] || russianRomansText[1];
  const hasReferences = chapterData.references && chapterData.references.length > 0;

  const handlePrevious = () => {
    if (chapter > 1 && onChapterChange) {
      onChapterChange(chapter - 1);
    }
  };

  const handleNext = () => {
    if (chapter < 16 && onChapterChange) {
      onChapterChange(chapter + 1);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Header Section */}
      <div className="space-y-4">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100">
            {chapterData.title}
          </h1>
        </div>
        <div className="h-px bg-gray-200 dark:bg-gray-700"></div>
      </div>

      {/* Text-to-Speech Player */}
      <TextToSpeech 
        text={chapterData.text}
        title={`Romans ${chapter} (Russian Synodal)`}
      />

      {/* Russian Text Content */}
      <div className="prose dark:prose-invert max-w-none">
        <div className="whitespace-pre-line leading-relaxed text-base text-gray-800 dark:text-gray-200">
          {chapterData.text}
        </div>
      </div>

      {/* Cross References Section */}
      {hasReferences && (
        <div className="bg-blue-50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
          <h3 className="text-sm font-medium text-blue-800 dark:text-blue-200 mb-3">
            Библейские ссылки
          </h3>
          <div className="flex flex-wrap gap-2">
            {chapterData.references.map((ref, index) => (
              <Button
                key={index}
                variant="outline"
                size="sm"
                className="text-xs bg-white dark:bg-blue-900/50 border-blue-300 dark:border-blue-700 text-blue-700 dark:text-blue-300 hover:bg-blue-100 dark:hover:bg-blue-900/70"
              >
                {ref}
              </Button>
            ))}
          </div>
        </div>
      )}

      {/* Bible Study Tools */}
      <div className="flex justify-center gap-3 pt-6">
        {hasReferences && (
          <Button 
            variant="outline" 
            size="sm" 
            className="text-xs"
            onClick={() => setShowCrossReferences(!showCrossReferences)}
          >
            <ExternalLink className="h-3 w-3 mr-1" />
            Ссылки
          </Button>
        )}
        <Button 
          variant="outline" 
          size="sm" 
          className="text-xs"
          onClick={() => setShowCrossReferences(!showCrossReferences)}
        >
          <Search className="h-3 w-3 mr-1" />
          Библейские связи
        </Button>
      </div>

      {/* Navigation Buttons */}
      <div className="flex justify-between items-center pt-8">
        <Button
          variant="outline"
          size="sm"
          onClick={handlePrevious}
          disabled={chapter <= 1}
          className="flex items-center gap-2"
        >
          <ChevronLeft className="h-4 w-4" />
          Предыдущая
        </Button>

        <div className="text-sm text-gray-500 dark:text-gray-400">
          Глава {chapter} из 16
        </div>

        <Button
          variant="outline"
          size="sm"
          onClick={handleNext}
          disabled={chapter >= 16}
          className="flex items-center gap-2"
        >
          Следующая
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>

      {/* Cross References Component */}
      {showCrossReferences && (
        <CrossReferences 
          chapter={chapter} 
          onNavigate={(newChapter) => {
            if (onChapterChange) {
              onChapterChange(newChapter);
            }
          }}
        />
      )}

      <div className="text-xs text-gray-500 dark:text-gray-400 text-center pt-4 border-t border-gray-200 dark:border-gray-700">
        Русский Синодальный перевод - Общественное достояние
      </div>
    </div>
  );
}