import { Commentary } from "@shared/schema";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Calendar } from "lucide-react";
import { cn } from "@/lib/utils";

interface CommentarySidebarProps {
  commentaries: Commentary[];
  selectedCommentaryId: number;
  onCommentarySelect: (id: number) => void;
  loading: boolean;
}

export function CommentarySidebar({
  commentaries,
  selectedCommentaryId,
  onCommentarySelect,
  loading
}: CommentarySidebarProps) {
  if (loading) {
    return (
      <div className="p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Commentary Sources</h2>
        <div className="space-y-2">
          {[...Array(5)].map((_, i) => (
            <Card key={i}>
              <CardContent className="p-4">
                <Skeleton className="h-5 w-32 mb-2" />
                <Skeleton className="h-4 w-48 mb-3" />
                <div className="flex items-center space-x-2">
                  <Skeleton className="h-3 w-12" />
                  <Skeleton className="h-3 w-20" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <h2 className="text-lg font-semibold text-gray-900 mb-4">Commentary Sources</h2>
      
      <div className="space-y-2">
        {commentaries.map((commentary) => (
          <Card
            key={commentary.id}
            className={cn(
              "cursor-pointer transition-all duration-200 hover:shadow-md",
              selectedCommentaryId === commentary.id
                ? "bg-blue-50 border-l-4 border-l-primary border-primary/20 shadow-sm"
                : "hover:bg-gray-50"
            )}
            onClick={() => onCommentarySelect(commentary.id)}
          >
            <CardContent className="p-4">
              <h3 className="font-medium text-gray-900">{commentary.author}</h3>
              <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                {commentary.description}
              </p>
              <div className="flex items-center mt-2 text-xs text-muted-foreground">
                <Calendar className="h-3 w-3 mr-1" />
                <span>{commentary.year}</span>
                <span className="mx-2">•</span>
                <span>16 chapters</span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
