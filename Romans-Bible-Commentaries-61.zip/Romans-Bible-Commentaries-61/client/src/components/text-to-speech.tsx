import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Play, Pause, Square, Volume2, Settings } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";

interface TextToSpeechProps {
  text: string;
  title?: string;
  className?: string;
}

interface Voice {
  name: string;
  lang: string;
  gender: 'male' | 'female';
}

export function TextToSpeech({ text, title = "Biblical Passage", className = "" }: TextToSpeechProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [currentPosition, setCurrentPosition] = useState(0);
  const [duration, setDuration] = useState(0);
  const [rate, setRate] = useState([1.0]);
  const [pitch, setPitch] = useState([1.0]);
  const [volume, setVolume] = useState([0.8]);
  const [selectedVoice, setSelectedVoice] = useState<string>("");
  const [availableVoices, setAvailableVoices] = useState<Voice[]>([]);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);
  const timeIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Check if Speech Synthesis is available
  const isSpeechSupported = typeof window !== 'undefined' && 'speechSynthesis' in window;

  // Load available voices
  useEffect(() => {
    if (!isSpeechSupported) return;
    
    const loadVoices = () => {
      const voices = speechSynthesis.getVoices();
      const englishVoices = voices
        .filter(voice => voice.lang.startsWith('en'))
        .map(voice => ({
          name: voice.name,
          lang: voice.lang,
          gender: voice.name.toLowerCase().includes('female') || voice.name.toLowerCase().includes('woman') ? 'female' as const : 'male' as const
        }));
      
      setAvailableVoices(englishVoices);
      
      // Set default voice (prefer high-quality voices)
      if (englishVoices.length > 0 && !selectedVoice) {
        const preferredVoice = englishVoices.find(v => 
          v.name.includes('Enhanced') || 
          v.name.includes('Premium') || 
          v.name.includes('Neural') ||
          v.name.includes('Samantha') ||
          v.name.includes('Daniel')
        ) || englishVoices[0];
        setSelectedVoice(preferredVoice.name);
      }
    };

    loadVoices();
    
    // Some browsers load voices asynchronously
    if (speechSynthesis.onvoiceschanged !== undefined) {
      speechSynthesis.onvoiceschanged = loadVoices;
    }
  }, [selectedVoice, isSpeechSupported]);

  // Clean text for better speech synthesis
  const cleanTextForSpeech = (inputText: string): string => {
    return inputText
      // Remove verse numbers in brackets or parentheses
      .replace(/\[\d+\]/g, '')
      .replace(/\(\d+\)/g, '')
      // Replace verse numbers at beginning of lines
      .replace(/^\d+\s+/gm, '')
      // Replace chapter:verse references
      .replace(/\d+:\d+/g, '')
      // Replace multiple spaces with single space
      .replace(/\s+/g, ' ')
      // Add pauses for better rhythm
      .replace(/\./g, '.')
      .replace(/;/g, ';')
      .replace(/:/g, ':')
      .replace(/,/g, ',')
      .trim();
  };

  const estimateDuration = (text: string, speechRate: number): number => {
    // Estimate ~150 words per minute at normal rate (1.0)
    const wordsPerMinute = 150 * speechRate;
    const wordCount = text.split(' ').length;
    return (wordCount / wordsPerMinute) * 60; // Convert to seconds
  };

  const startSpeech = () => {
    if (!text || !isSpeechSupported) return;

    // Stop any existing speech
    speechSynthesis.cancel();

    const cleanedText = cleanTextForSpeech(text);
    const utterance = new SpeechSynthesisUtterance(cleanedText);
    
    // Find and set the selected voice
    const voices = speechSynthesis.getVoices();
    const voice = voices.find(v => v.name === selectedVoice);
    if (voice) {
      utterance.voice = voice;
    }

    // Set speech parameters
    utterance.rate = rate[0];
    utterance.pitch = pitch[0];
    utterance.volume = volume[0];

    // Set up event handlers
    utterance.onstart = () => {
      setIsPlaying(true);
      setIsPaused(false);
      setCurrentPosition(0);
      const estimatedDuration = estimateDuration(cleanedText, rate[0]);
      setDuration(estimatedDuration);
      
      // Start position tracking
      timeIntervalRef.current = setInterval(() => {
        setCurrentPosition(prev => {
          const newPosition = prev + 0.1;
          return newPosition >= estimatedDuration ? estimatedDuration : newPosition;
        });
      }, 100);
    };

    utterance.onend = () => {
      setIsPlaying(false);
      setIsPaused(false);
      setCurrentPosition(0);
      if (timeIntervalRef.current) {
        clearInterval(timeIntervalRef.current);
      }
    };

    utterance.onerror = () => {
      setIsPlaying(false);
      setIsPaused(false);
      setCurrentPosition(0);
      if (timeIntervalRef.current) {
        clearInterval(timeIntervalRef.current);
      }
    };

    utteranceRef.current = utterance;
    speechSynthesis.speak(utterance);
  };

  const pauseSpeech = () => {
    if (!isSpeechSupported) return;
    if (speechSynthesis.speaking && !speechSynthesis.paused) {
      speechSynthesis.pause();
      setIsPaused(true);
      if (timeIntervalRef.current) {
        clearInterval(timeIntervalRef.current);
      }
    }
  };

  const resumeSpeech = () => {
    if (!isSpeechSupported) return;
    if (speechSynthesis.paused) {
      speechSynthesis.resume();
      setIsPaused(false);
      
      // Resume position tracking
      timeIntervalRef.current = setInterval(() => {
        setCurrentPosition(prev => {
          const newPosition = prev + 0.1;
          return newPosition >= duration ? duration : newPosition;
        });
      }, 100);
    }
  };

  const stopSpeech = () => {
    if (!isSpeechSupported) return;
    speechSynthesis.cancel();
    setIsPlaying(false);
    setIsPaused(false);
    setCurrentPosition(0);
    if (timeIntervalRef.current) {
      clearInterval(timeIntervalRef.current);
    }
  };

  const handlePlayPause = () => {
    if (!isPlaying) {
      startSpeech();
    } else if (isPaused) {
      resumeSpeech();
    } else {
      pauseSpeech();
    }
  };

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const progressPercentage = duration > 0 ? (currentPosition / duration) * 100 : 0;

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (isSpeechSupported) {
        speechSynthesis.cancel();
      }
      if (timeIntervalRef.current) {
        clearInterval(timeIntervalRef.current);
      }
    };
  }, [isSpeechSupported]);

  // Don't render if speech synthesis is not supported
  if (!isSpeechSupported) {
    return (
      <Card className={`w-full ${className}`}>
        <CardContent className="p-4">
          <div className="flex items-center justify-center gap-2 text-gray-500 dark:text-gray-400">
            <Volume2 className="h-4 w-4" />
            <span className="text-sm">
              Text-to-speech is not available in this environment
            </span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={`w-full ${className}`}>
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Volume2 className="h-4 w-4 text-gray-600 dark:text-gray-400" />
            <span className="text-sm font-medium text-gray-900 dark:text-gray-100">
              {title}
            </span>
          </div>
          
          <Popover open={isSettingsOpen} onOpenChange={setIsSettingsOpen}>
            <PopoverTrigger asChild>
              <Button variant="ghost" size="sm">
                <Settings className="h-4 w-4" />
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-80">
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium">Voice</label>
                  <Select value={selectedVoice} onValueChange={setSelectedVoice}>
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Select a voice" />
                    </SelectTrigger>
                    <SelectContent>
                      {availableVoices.map((voice) => (
                        <SelectItem key={voice.name} value={voice.name}>
                          {voice.name} ({voice.gender})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="text-sm font-medium">Speed: {rate[0].toFixed(1)}x</label>
                  <Slider
                    value={rate}
                    onValueChange={setRate}
                    min={0.5}
                    max={2.0}
                    step={0.1}
                    className="mt-1"
                  />
                </div>
                
                <div>
                  <label className="text-sm font-medium">Pitch: {pitch[0].toFixed(1)}</label>
                  <Slider
                    value={pitch}
                    onValueChange={setPitch}
                    min={0.5}
                    max={2.0}
                    step={0.1}
                    className="mt-1"
                  />
                </div>
                
                <div>
                  <label className="text-sm font-medium">Volume: {Math.round(volume[0] * 100)}%</label>
                  <Slider
                    value={volume}
                    onValueChange={setVolume}
                    min={0.1}
                    max={1.0}
                    step={0.1}
                    className="mt-1"
                  />
                </div>
              </div>
            </PopoverContent>
          </Popover>
        </div>

        <div className="space-y-3">
          {/* Progress Bar */}
          <div className="relative">
            <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
              <div 
                className="h-full bg-blue-600 transition-all duration-100 ease-linear"
                style={{ width: `${progressPercentage}%` }}
              />
            </div>
          </div>

          {/* Time Display */}
          <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400">
            <span>{formatTime(currentPosition)}</span>
            <span>{formatTime(duration)}</span>
          </div>

          {/* Control Buttons */}
          <div className="flex items-center justify-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handlePlayPause}
              disabled={!text}
              className="flex items-center gap-2"
            >
              {isPlaying && !isPaused ? (
                <>
                  <Pause className="h-4 w-4" />
                  Pause
                </>
              ) : (
                <>
                  <Play className="h-4 w-4" />
                  {isPaused ? 'Resume' : 'Play'}
                </>
              )}
            </Button>
            
            <Button
              variant="outline"
              size="sm"
              onClick={stopSpeech}
              disabled={!isPlaying && !isPaused}
            >
              <Square className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}