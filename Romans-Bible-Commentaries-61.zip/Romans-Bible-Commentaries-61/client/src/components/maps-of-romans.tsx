import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ExternalLink, Map, MapPin, Globe } from "lucide-react";

interface MapResource {
  title: string;
  description: string;
  url: string;
  type: 'interactive' | 'static' | 'educational';
  focus: string;
}

const romanEmpireMaps: MapResource[] = [
  {
    title: "Roman Empire 57 AD - Digital Atlas of the Roman Empire",
    description: "Interactive map showing the Roman Empire during Paul's time, including provinces, roads, and major cities mentioned in Romans.",
    url: "https://dh.gu.se/dare/",
    type: 'interactive',
    focus: 'Political boundaries and provinces'
  },
  {
    title: "Ancient World Mapping Center - Roman Roads",
    description: "Detailed maps of Roman road networks circa 57 AD, showing Paul's likely travel routes to Rome.",
    url: "https://awmc.unc.edu/wordpress/",
    type: 'educational',
    focus: 'Transportation and travel routes'
  },
  {
    title: "Orbis: The Stanford Geospatial Network Model",
    description: "Interactive tool showing travel times and routes in the Roman world, useful for understanding Paul's journey planning.",
    url: "https://orbis.stanford.edu/",
    type: 'interactive',
    focus: 'Travel times and logistics'
  },
  {
    title: "Imperium Romanum - Map Collection",
    description: "Comprehensive collection of Roman Empire maps with focus on the Neronian period (54-68 AD).",
    url: "https://www.imperiumromanum.edu.pl/en/maps/",
    type: 'static',
    focus: 'Historical accuracy and detail'
  },
  {
    title: "World History Encyclopedia - Roman Empire Maps",
    description: "Educational maps showing the Roman Empire's extent in the 1st century AD with cultural and religious context.",
    url: "https://www.worldhistory.org/image/tag/roman-empire/",
    type: 'educational',
    focus: 'Cultural and religious context'
  }
];

const biblicalLocations = [
  {
    location: "Rome",
    significance: "Destination of Paul's letter and center of the empire",
    details: "Capital city with estimated 1 million inhabitants, including significant Jewish population in Trastevere district"
  },
  {
    location: "Corinth",
    significance: "Where Paul likely wrote Romans (winter 56-57 AD)",
    details: "Major commercial center and capital of Achaia province, Paul's base during third missionary journey"
  },
  {
    location: "Jerusalem",
    significance: "Paul's intended destination before Rome",
    details: "Center of early Christianity, Paul planning to deliver collection for poor saints"
  },
  {
    location: "Spain (Hispania)",
    significance: "Paul's missionary goal beyond Rome (Romans 15:24, 28)",
    details: "Western frontier of the empire, representing Paul's vision for gospel expansion"
  },
  {
    location: "Illyricum",
    significance: "Extent of Paul's ministry (Romans 15:19)",
    details: "Modern-day Balkans, marking the boundaries of Paul's evangelistic work"
  },
  {
    location: "Via Appia",
    significance: "Road Paul would travel to reach Rome",
    details: "Major Roman road connecting southeastern Italy to Rome, mentioned in Acts 28:15"
  }
];

export function MapsOfRomans() {
  const [selectedTab, setSelectedTab] = useState<'maps' | 'locations'>('maps');

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 p-6">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-2">
            Maps of Romans
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mb-6">
            Explore the Roman Empire of 57 AD and the geographical context of Paul's letter to the Romans
          </p>
        </div>

        <Tabs value={selectedTab} onValueChange={(value) => setSelectedTab(value as 'maps' | 'locations')}>
          <TabsList className="grid w-full grid-cols-1 md:grid-cols-2 mb-6 h-auto">
            <TabsTrigger value="maps" className="flex items-center gap-2 py-3 px-4 text-sm">
              <Map className="h-4 w-4 flex-shrink-0" />
              <span className="truncate">Empire Maps & Resources</span>
            </TabsTrigger>
            <TabsTrigger value="locations" className="flex items-center gap-2 py-3 px-4 text-sm">
              <MapPin className="h-4 w-4 flex-shrink-0" />
              <span className="truncate">Biblical Locations</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="maps" className="space-y-6">
            <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-2">
              {romanEmpireMaps.map((map, index) => (
                <Card key={index} className="hover:shadow-lg transition-shadow">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <CardTitle className="text-lg mb-2 leading-tight">{map.title}</CardTitle>
                        <div className="flex flex-wrap gap-2 mb-3">
                          <Badge variant={map.type === 'interactive' ? 'default' : 'secondary'} className="text-xs">
                            {map.type}
                          </Badge>
                          <Badge variant="outline" className="text-xs">
                            {map.focus}
                          </Badge>
                        </div>
                      </div>
                      <div className="flex-shrink-0">
                        <Button variant="ghost" size="sm" asChild>
                          <a href={map.url} target="_blank" rel="noopener noreferrer">
                            <ExternalLink className="h-4 w-4" />
                          </a>
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <p className="text-gray-600 dark:text-gray-400 text-sm mb-4 leading-relaxed">
                      {map.description}
                    </p>
                    <Button asChild className="w-full">
                      <a href={map.url} target="_blank" rel="noopener noreferrer">
                        <Globe className="h-4 w-4 mr-2" />
                        Explore Map
                      </a>
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Card className="mt-8">
              <CardHeader>
                <CardTitle>Historical Context: The Roman Empire in 57 AD</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">
                      Political Situation
                    </h4>
                    <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                      <li>• Emperor Nero (54-68 AD) in power</li>
                      <li>• Peak of Pax Romana (Roman Peace)</li>
                      <li>• Extensive road network facilitating travel</li>
                      <li>• Common Greek language (Koine) in eastern provinces</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">
                      Religious Context
                    </h4>
                    <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                      <li>• Religious tolerance under imperial cult</li>
                      <li>• Jewish diaspora throughout empire</li>
                      <li>• Mystery religions popular</li>
                      <li>• Christianity spreading via synagogue networks</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="locations" className="space-y-6">
            <div className="grid gap-4">
              {biblicalLocations.map((location, index) => (
                <Card key={index}>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{location.location}</CardTitle>
                      <Badge variant="outline">
                        {location.significance.includes('Paul') ? 'Pauline' : 'Biblical'}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="font-medium text-gray-900 dark:text-gray-100 mb-2">
                      {location.significance}
                    </p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {location.details}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Paul's Travel Network in Romans Context</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">
                      When Romans was Written (Winter 56-57 AD)
                    </h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                      Paul was in Corinth during his third missionary journey, having completed work in 
                      the eastern Mediterranean. He planned to visit Jerusalem with the collection, 
                      then travel to Rome and beyond to Spain.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">
                      Geographical Strategy
                    </h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      Rome served as Paul's strategic base for western expansion. The letter demonstrates 
                      his understanding of Rome's central position in the empire and its potential as 
                      a launching point for missions to Spain and beyond.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}