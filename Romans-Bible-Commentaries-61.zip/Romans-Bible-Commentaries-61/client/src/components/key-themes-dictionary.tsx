import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, BookOpen, ExternalLink, Filter } from "lucide-react";
import { cn } from "@/lib/utils";

interface KeyTheme {
  id: string;
  title: string;
  definition: string;
  chapters: number[];
  category: string;
  sources: string[];
  relatedTerms: string[];
  scholarlyNotes: string;
  practicalApplication: string;
}

interface KeyThemesDictionaryProps {
  searchTerm?: string;
}

export function KeyThemesDictionary({ searchTerm }: KeyThemesDictionaryProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState(searchTerm || "");
  const [selectedTheme, setSelectedTheme] = useState<KeyTheme | null>(null);

  // Comprehensive key themes database aggregated from scholarly sources
  const keyThemes: KeyTheme[] = [
    {
      id: "justification-by-faith",
      title: "Justification by Faith",
      definition: "The doctrine that declares sinners righteous before God through faith in Christ alone, apart from works of law.",
      chapters: [3, 4, 5],
      category: "soteriology",
      sources: ["Wright, N.T. 'Paul and the Faithfulness of God'", "Schreiner, T.R. 'Romans'", "Calvin's Institutes III.11"],
      relatedTerms: ["Faith", "Righteousness", "Imputation", "Grace"],
      scholarlyNotes: "Contemporary scholarship debates whether justification is primarily forensic (legal declaration) or transformative (actual righteousness). N.T. Wright emphasizes covenant faithfulness, while traditional Reformed theology stresses imputed righteousness.",
      practicalApplication: "Believers can have assurance of salvation not based on their performance but on Christ's perfect work. This liberates from legalistic approaches to Christian living while motivating obedience from gratitude."
    },
    {
      id: "divine-sovereignty",
      title: "Divine Sovereignty",
      definition: "God's absolute authority and control over all creation, particularly evident in election and salvation.",
      chapters: [9, 10, 11],
      category: "theology",
      sources: ["Piper, J. 'The Justification of God'", "Calvin's Commentary on Romans", "Moo, D.J. 'Romans'"],
      relatedTerms: ["Election", "Predestination", "Potter and Clay", "Remnant"],
      scholarlyNotes: "Romans 9-11 presents the most sustained biblical treatment of divine sovereignty in salvation. Scholars debate whether Paul teaches double predestination or merely God's sovereign choice of means.",
      practicalApplication: "Understanding God's sovereignty brings comfort in suffering and humility in blessing, recognizing that salvation depends entirely on God's mercy rather than human will or effort."
    },
    {
      id: "union-with-christ",
      title: "Union with Christ",
      definition: "The believer's spiritual identification and participation in Christ's death, burial, and resurrection.",
      chapters: [6, 8],
      category: "soteriology",
      sources: ["Campbell, C.L. 'Paul and Union with Christ'", "Murray, J. 'Redemption Accomplished'", "Chrysostom's Homilies"],
      relatedTerms: ["Baptism", "Death to Sin", "New Life", "Sanctification"],
      scholarlyNotes: "Modern scholarship recognizes union with Christ as central to Paul's theology, not merely justification. This mystical yet real participation shapes both identity and ethics.",
      practicalApplication: "Christians can overcome sin by reckoning themselves dead to sin and alive to God. This provides both motivation and power for holy living through identification with Christ."
    },
    {
      id: "law-and-gospel",
      title: "Law and Gospel",
      definition: "The relationship between God's moral demands (law) and His gracious provision of salvation (gospel).",
      chapters: [2, 3, 7, 10],
      category: "theology",
      sources: ["Sanders, E.P. 'Paul and Palestinian Judaism'", "Dunn, J.D.G. 'Romans'", "Luther's Commentary"],
      relatedTerms: ["Works of Law", "Righteousness", "Conscience", "Faith"],
      scholarlyNotes: "The New Perspective on Paul has challenged traditional Lutheran interpretations, suggesting Paul's concern was ethnic boundary markers rather than works-righteousness per se.",
      practicalApplication: "The law reveals human sinfulness and need for grace, while the gospel provides the righteousness that law demands. This prevents both antinomianism and legalism."
    },
    {
      id: "adam-christ-parallel",
      title: "Adam-Christ Parallel",
      definition: "Paul's typological comparison between Adam's bringing sin and death versus Christ's bringing righteousness and life.",
      chapters: [5],
      category: "anthropology",
      sources: ["Cranfield, C.E.B. 'Romans'", "Barrett, C.K. 'From First Adam to Last'", "Irenaeus' Against Heresies"],
      relatedTerms: ["Original Sin", "Federal Headship", "Imputation", "Death"],
      scholarlyNotes: "This passage is foundational for understanding both the universality of sin and the scope of redemption. Scholars debate whether Paul teaches immediate imputation or natural headship.",
      practicalApplication: "Just as humanity inherited sin and death through Adam, believers receive righteousness and life through Christ. This emphasizes both human solidarity in sin and grace."
    },
    {
      id: "spirit-led-life",
      title: "Spirit-Led Life",
      definition: "The Christian life empowered and directed by the Holy Spirit, contrasted with life according to the flesh.",
      chapters: [8],
      category: "pneumatology",
      sources: ["Fee, G.D. 'God's Empowering Presence'", "Dunn, J.D.G. 'Jesus and the Spirit'", "Cyril of Alexandria"],
      relatedTerms: ["Flesh", "Spirit", "Adoption", "Intercession"],
      scholarlyNotes: "Romans 8 presents the most comprehensive New Testament treatment of the Spirit's role in Christian living, emphasizing both empowerment for holiness and assurance of salvation.",
      practicalApplication: "Believers can live victorious Christian lives by walking according to the Spirit rather than the flesh, with confidence that God's Spirit bears witness to their adoption as children."
    },
    {
      id: "israel-gentile-unity",
      title: "Israel-Gentile Unity",
      definition: "God's plan to include both Jews and Gentiles in one people through faith in Christ.",
      chapters: [9, 10, 11, 15],
      category: "ecclesiology",
      sources: ["Wright, N.T. 'Paul and the Faithfulness of God'", "Seifried, M.A. 'Christ, Our Righteousness'", "John Chrysostom"],
      relatedTerms: ["Olive Tree", "Grafting", "Mystery", "Remnant"],
      scholarlyNotes: "This theme addresses the theological problem of how God's promises to Israel relate to the inclusion of Gentiles. Paul maintains both God's faithfulness to Israel and the inclusion of Gentiles.",
      practicalApplication: "The church should embrace unity between Jewish and Gentile believers while respecting God's ongoing purposes for ethnic Israel. This combats both supersessionism and ethnic division."
    },
    {
      id: "christian-ethics",
      title: "Christian Ethics",
      definition: "Practical guidelines for living out faith in community, relationships, and society.",
      chapters: [12, 13, 14, 15],
      category: "ethics",
      sources: ["Hays, R.B. 'The Moral Vision of the New Testament'", "O'Brien, P.T. 'Romans'", "Augustine's City of God"],
      relatedTerms: ["Love", "Government", "Conscience", "Edification"],
      scholarlyNotes: "Paul's ethical teaching flows from theological foundations, emphasizing love as the fulfillment of law and the importance of building up the community of faith.",
      practicalApplication: "Christian ethics involves both personal holiness and social responsibility, including respect for government, love for enemies, and consideration for weaker believers' consciences."
    },
    {
      id: "gods-wrath",
      title: "God's Wrath",
      definition: "God's righteous anger and judgment against sin, revealed both presently and eschatologically.",
      chapters: [1, 2],
      category: "theology",
      sources: ["Travis, S.H. 'Divine Wrath'", "Morris, L. 'The Apostolic Preaching of the Cross'", "Calvin's Commentary"],
      relatedTerms: ["Judgment", "Sin", "Suppression", "Giving Over"],
      scholarlyNotes: "God's wrath is not arbitrary anger but righteous response to sin. Paul describes it as both present reality (giving people over to sin's consequences) and future judgment.",
      practicalApplication: "Understanding God's wrath deepens appreciation for grace and motivates evangelism. It also provides a foundation for understanding the necessity of Christ's atoning death."
    },
    {
      id: "faith-definition",
      title: "Nature of Faith",
      definition: "Trust and confidence in God's promises and character, particularly as revealed in Christ.",
      chapters: [4, 10],
      category: "soteriology",
      sources: ["Barclay, J.M.G. 'Paul and the Gift'", "Campbell, D.A. 'The Deliverance of God'", "Aquinas' Summa"],
      relatedTerms: ["Belief", "Trust", "Confidence", "Assurance"],
      scholarlyNotes: "Recent scholarship has explored whether pistis should be translated as 'faith in Christ' or 'faithfulness of Christ,' with implications for understanding the nature of saving faith.",
      practicalApplication: "True faith involves both intellectual assent and personal trust, leading to transformation. Abraham's example shows faith as confident reliance on God's promises despite circumstances."
    },
    {
      id: "conscience",
      title: "Conscience",
      definition: "The internal moral awareness that bears witness to right and wrong, present in all humans.",
      chapters: [2, 14],
      category: "anthropology",
      sources: ["Pierce, C.A. 'Conscience in the New Testament'", "Matera, F.J. 'Romans'", "Thomas Aquinas"],
      relatedTerms: ["Law Written on Hearts", "Moral Awareness", "Weak/Strong", "Liberty"],
      scholarlyNotes: "Paul presents conscience as evidence of God's moral law written on human hearts, while also addressing how believers should handle differences in conscience regarding disputable matters.",
      practicalApplication: "Believers should maintain good conscience before God while being sensitive to others' consciences in matters of Christian liberty, prioritizing love and edification over personal freedom."
    },
    {
      id: "propitiation",
      title: "Propitiation",
      definition: "Christ's sacrificial death that satisfies God's wrath and makes possible reconciliation between God and humanity.",
      chapters: [3],
      category: "soteriology",
      sources: ["Morris, L. 'The Apostolic Preaching'", "Hill, D. 'Greek Words with Hebrew Meanings'", "Anselm's Cur Deus Homo"],
      relatedTerms: ["Sacrifice", "Blood", "Redemption", "Mercy Seat"],
      scholarlyNotes: "The term hilasterion connects Christ's work to the Old Testament mercy seat, indicating both the turning away of wrath and the provision of mercy through sacrifice.",
      practicalApplication: "Christ's propitiatory work means believers need not fear God's wrath, having been reconciled through Christ's blood. This provides assurance and peace with God."
    },
    {
      id: "perseverance",
      title: "Perseverance of Saints",
      definition: "The doctrine that those truly justified by faith will persevere in faith until glorification.",
      chapters: [8],
      category: "soteriology",
      sources: ["Schreiner, T.R. 'Romans'", "Moo, D.J. 'Romans 8'", "Augustinian tradition"],
      relatedTerms: ["Golden Chain", "Predestination", "Glorification", "Assurance"],
      scholarlyNotes: "Romans 8:29-30 presents the 'golden chain of salvation' showing God's sovereign work from predestination to glorification, providing basis for eternal security.",
      practicalApplication: "Believers can have confidence that God who began the work of salvation will complete it, providing assurance during trials and motivation for continued faithfulness."
    },
    {
      id: "natural-revelation",
      title: "Natural Revelation",
      definition: "God's disclosure of Himself through creation, providing knowledge of His eternal power and divine nature.",
      chapters: [1],
      category: "theology",
      sources: ["Warfield, B.B. 'Biblical Foundations'", "Frame, J.M. 'Apologetics'", "Aquinas' Natural Theology"],
      relatedTerms: ["Creation", "Conscience", "Suppression", "Inexcusable"],
      scholarlyNotes: "Paul argues that natural revelation provides sufficient knowledge of God to render all humanity accountable, though insufficient for salvation apart from special revelation.",
      practicalApplication: "Natural revelation provides a basis for apologetics and evangelism, showing that unbelief involves suppression of truth rather than mere ignorance of God's existence."
    },
    {
      id: "transformation",
      title: "Spiritual Transformation",
      definition: "The progressive change in believers from conformity to the world to conformity to Christ's image.",
      chapters: [12],
      category: "sanctification",
      sources: ["Mounce, R.H. 'Romans'", "Cranfield, C.E.B. 'Romans'", "Eastern Orthodox tradition"],
      relatedTerms: ["Renewal", "Mind", "Conformity", "Non-conformity"],
      scholarlyNotes: "Transformation involves both negative (non-conformity to world) and positive (mind renewal) aspects, resulting in the ability to discern God's will and live accordingly.",
      practicalApplication: "Christians must actively resist worldly thinking patterns while cultivating biblical mindset through Scripture, prayer, and community, resulting in transformed living."
    },
    {
      id: "church-unity",
      title: "Church Unity",
      definition: "The essential oneness of believers in Christ, transcending ethnic, cultural, and social divisions.",
      chapters: [12, 14, 15, 16],
      category: "ecclesiology",
      sources: ["Hays, R.B. 'Moral Vision'", "Dunn, J.D.G. 'Unity and Diversity'", "Ephesians parallels"],
      relatedTerms: ["Body of Christ", "One Spirit", "Peace", "Acceptance"],
      scholarlyNotes: "Paul addresses practical unity issues in Romans 14-15, emphasizing acceptance of believers with different convictions while maintaining doctrinal essentials.",
      practicalApplication: "Churches should prioritize unity in Christ over secondary differences, practicing mutual acceptance and building each other up rather than judging over disputable matters."
    },
    {
      id: "gospel-power",
      title: "Power of the Gospel",
      definition: "The divine power inherent in the gospel message to save all who believe, both Jew and Gentile.",
      chapters: [1, 15, 16],
      category: "soteriology",
      sources: ["Moo, D.J. 'Romans 1'", "Käsemann, E. 'Commentary'", "Barth, K. 'Romans'"],
      relatedTerms: ["Salvation", "Power of God", "Not Ashamed", "Universal"],
      scholarlyNotes: "The gospel's power is not merely informational but transformational, actively working to bring salvation to all who respond in faith.",
      practicalApplication: "Christians should never be ashamed of the gospel but boldly proclaim it, trusting in its inherent power to transform lives rather than relying on human persuasion alone."
    },
    {
      id: "ministry-partnership",
      title: "Ministry Partnership",
      definition: "Collaborative service in advancing the gospel through mutual support, prayer, and resource sharing.",
      chapters: [16],
      category: "ecclesiology",
      sources: ["Fee, G.D. 'Paul's Letter to Romans'", "Jewett, R. 'Romans'", "Ancient letter conventions"],
      relatedTerms: ["Co-workers", "Helpers", "Saints", "Hospitality"],
      scholarlyNotes: "Romans 16 reveals the extensive network of ministry partnerships Paul cultivated, showing the importance of collaborative gospel work.",
      practicalApplication: "Effective ministry requires building strong partnerships with other believers, sharing resources generously, and recognizing the contributions of all members of the body of Christ."
    },
    {
      id: "eschatological-hope",
      title: "Eschatological Hope",
      definition: "The confident expectation of future glory and the renewal of all creation through Christ's return.",
      chapters: [8, 13],
      category: "eschatology",
      sources: ["Moltmann, J. 'Theology of Hope'", "Wright, N.T. 'Resurrection'", "Apocalyptic tradition"],
      relatedTerms: ["Glory", "Redemption", "Day", "Salvation"],
      scholarlyNotes: "Paul's eschatology is both already and not yet, with present suffering balanced by certain future glory that motivates current faithfulness.",
      practicalApplication: "Believers can endure present trials with confidence because of the certain hope of future glory, and this hope should motivate ethical living in anticipation of Christ's return."
    }
  ];

  const categories = [
    { id: "all", label: "All Categories" },
    { id: "soteriology", label: "Salvation" },
    { id: "theology", label: "God & Christ" },
    { id: "anthropology", label: "Human Nature" },
    { id: "pneumatology", label: "Holy Spirit" },
    { id: "ecclesiology", label: "Church" },
    { id: "ethics", label: "Christian Living" },
    { id: "sanctification", label: "Holiness" }
  ];

  const filteredThemes = keyThemes.filter(theme => {
    const matchesCategory = selectedCategory === "all" || theme.category === selectedCategory;
    const matchesSearch = searchQuery === "" || 
      theme.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      theme.definition.toLowerCase().includes(searchQuery.toLowerCase()) ||
      theme.relatedTerms.some(term => term.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  useEffect(() => {
    if (searchTerm) {
      setSearchQuery(searchTerm);
    }
  }, [searchTerm]);

  return (
    <div className="space-y-6">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold text-gray-900">Key Themes Dictionary</h1>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          A comprehensive reference of key theological themes found throughout Romans, 
          compiled from leading biblical scholarship and commentaries.
        </p>
      </div>

      {/* Search and Filters */}
      <div className="space-y-4">
        <div className="relative">
          <Input
            type="text"
            placeholder="Search themes, definitions, or related terms..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
        </div>

        <Tabs value={selectedCategory} onValueChange={setSelectedCategory}>
          <TabsList className="grid w-full grid-cols-4 lg:grid-cols-8">
            {categories.map(category => (
              <TabsTrigger key={category.id} value={category.id} className="text-xs">
                {category.label}
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>
      </div>

      {/* Results */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Themes List */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold">Themes ({filteredThemes.length})</h2>
            <Badge variant="outline">
              <Filter className="h-3 w-3 mr-1" />
              {categories.find(c => c.id === selectedCategory)?.label}
            </Badge>
          </div>
          
          <ScrollArea className="h-[600px]">
            <div className="space-y-3 pr-4">
              {filteredThemes.map((theme) => (
                <Card
                  key={theme.id}
                  className={cn(
                    "cursor-pointer transition-all duration-200 hover:shadow-md",
                    selectedTheme?.id === theme.id ? "border-primary bg-primary/5" : "border-gray-200"
                  )}
                  onClick={() => setSelectedTheme(theme)}
                >
                  <CardContent className="p-4">
                    <div className="space-y-2">
                      <div className="flex items-start justify-between">
                        <h3 className="font-medium text-gray-900 leading-tight">
                          {theme.title}
                        </h3>
                        <Badge variant="outline" className="text-xs ml-2 flex-shrink-0">
                          Ch. {theme.chapters.join(", ")}
                        </Badge>
                      </div>
                      
                      <p className="text-sm text-muted-foreground line-clamp-2">
                        {theme.definition}
                      </p>
                      
                      <div className="flex flex-wrap gap-1">
                        {theme.relatedTerms.slice(0, 3).map((term, index) => (
                          <span key={index} className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded">
                            {term}
                          </span>
                        ))}
                        {theme.relatedTerms.length > 3 && (
                          <span className="text-xs text-muted-foreground">
                            +{theme.relatedTerms.length - 3} more
                          </span>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </ScrollArea>
        </div>

        {/* Theme Detail */}
        <div className="lg:sticky lg:top-6">
          {selectedTheme ? (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  {selectedTheme.title}
                  <Badge variant="outline">
                    {categories.find(c => c.id === selectedTheme.category)?.label}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h4 className="font-semibold mb-2">Definition</h4>
                  <p className="text-sm text-gray-700">{selectedTheme.definition}</p>
                </div>

                <div>
                  <h4 className="font-semibold mb-2">Found in Chapters</h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedTheme.chapters.map(chapter => (
                      <Badge key={chapter} variant="secondary">
                        Romans {chapter}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold mb-2">Related Terms</h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedTheme.relatedTerms.map((term, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {term}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold mb-2">Scholarly Notes</h4>
                  <p className="text-sm text-gray-700">{selectedTheme.scholarlyNotes}</p>
                </div>

                <div>
                  <h4 className="font-semibold mb-2">Practical Application</h4>
                  <p className="text-sm text-gray-700">{selectedTheme.practicalApplication}</p>
                </div>

                <div>
                  <h4 className="font-semibold mb-2">Sources</h4>
                  <ul className="space-y-1">
                    {selectedTheme.sources.map((source, index) => (
                      <li key={index} className="text-sm text-gray-600 flex items-center">
                        <BookOpen className="h-3 w-3 mr-2 flex-shrink-0" />
                        {source}
                      </li>
                    ))}
                  </ul>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="p-8 text-center">
                <BookOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="font-medium text-gray-900 mb-2">Select a Theme</h3>
                <p className="text-sm text-muted-foreground">
                  Choose a theme from the list to see detailed information, 
                  scholarly notes, and practical applications.
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}