import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Download, Palette, BarChart3, Image, BookOpen, Users, Calendar, Clock, Star } from "lucide-react";

interface SundaySchoolResourcesProps {
  chapter: number;
  onChapterChange?: (chapter: number) => void;
}

interface Resource {
  id: string;
  title: string;
  type: 'coloring' | 'chart' | 'drawing' | 'activity' | 'lesson';
  description: string;
  ageGroup: 'preschool' | 'elementary' | 'youth' | 'all';
  difficulty: 'easy' | 'medium' | 'hard';
  timeEstimate: string;
  biblePassages: string[];
  downloadUrl?: string;
  thumbnailUrl?: string;
}

// Sunday School resources for each chapter of Romans
const sundaySchoolResources: Record<number, Resource[]> = {
  1: [
    {
      id: "rom1-coloring1",
      title: "Paul's Letter to Rome Coloring Page",
      type: "coloring",
      description: "Simple coloring page showing Paul writing his letter with Roman architecture in the background. Includes Romans 1:16 memory verse.",
      ageGroup: "elementary",
      difficulty: "easy",
      timeEstimate: "15-20 minutes",
      biblePassages: ["Romans 1:1-7", "Romans 1:16"],
      thumbnailUrl: "/api/placeholder/200/150"
    },
    {
      id: "rom1-chart1",
      title: "Gospel Power Chart",
      type: "chart",
      description: "Visual chart showing 'The Gospel is God's Power' with arrows and symbols. Perfect for explaining Romans 1:16 to children.",
      ageGroup: "all",
      difficulty: "medium",
      timeEstimate: "10 minutes explanation",
      biblePassages: ["Romans 1:16-17", "Psalm 19:1"],
      thumbnailUrl: "/api/placeholder/200/150"
    },
    {
      id: "rom1-drawing1",
      title: "Creation Declares God's Glory",
      type: "drawing",
      description: "Drawing activity based on Romans 1:20 - children draw nature scenes showing God's invisible qualities through creation.",
      ageGroup: "elementary",
      difficulty: "medium",
      timeEstimate: "25-30 minutes",
      biblePassages: ["Romans 1:18-20", "Psalm 19:1-2"],
      thumbnailUrl: "/api/placeholder/200/150"
    },
    {
      id: "rom1-activity1",
      title: "Faith Badge Activity",
      type: "activity",
      description: "Interactive badge-making activity where children create 'The Righteous Live by Faith' badges using Romans 1:17.",
      ageGroup: "elementary",
      difficulty: "easy",
      timeEstimate: "20 minutes",
      biblePassages: ["Romans 1:17", "Habakkuk 2:4"],
      thumbnailUrl: "/api/placeholder/200/150"
    },
    {
      id: "rom1-lesson1",
      title: "Paul's Big Letter - Complete Lesson Plan",
      type: "lesson",
      description: "Full 45-minute lesson plan with games, crafts, and discussion questions about Paul's introduction and the power of the Gospel.",
      ageGroup: "elementary",
      difficulty: "medium",
      timeEstimate: "45 minutes",
      biblePassages: ["Romans 1:1-17"],
      thumbnailUrl: "/api/placeholder/200/150"
    }
  ],
  2: [
    {
      id: "rom2-coloring1",
      title: "God's Kindness Leads to Repentance",
      type: "coloring",
      description: "Coloring page featuring a heart with Romans 2:4 and symbols of God's kindness (sun, rain, flowers).",
      ageGroup: "elementary",
      difficulty: "easy",
      timeEstimate: "15-20 minutes",
      biblePassages: ["Romans 2:4", "Romans 2:11"],
      thumbnailUrl: "/api/placeholder/200/150"
    },
    {
      id: "rom2-chart1",
      title: "God Shows No Favoritism Chart",
      type: "chart",
      description: "Colorful chart showing children from different backgrounds with Romans 2:11 - 'God does not show favoritism.'",
      ageGroup: "all",
      difficulty: "easy",
      timeEstimate: "10 minutes",
      biblePassages: ["Romans 2:11", "Acts 10:34"],
      thumbnailUrl: "/api/placeholder/200/150"
    },
    {
      id: "rom2-activity1",
      title: "Heart Check Activity",
      type: "activity",
      description: "Interactive activity where children examine their hearts and learn about God's judgment being based on truth, not appearance.",
      ageGroup: "elementary",
      difficulty: "medium",
      timeEstimate: "25 minutes",
      biblePassages: ["Romans 2:16", "1 Samuel 16:7"],
      thumbnailUrl: "/api/placeholder/200/150"
    }
  ],
  3: [
    {
      id: "rom3-coloring1",
      title: "All Have Sinned Coloring Page",
      type: "coloring",
      description: "Thoughtful coloring page showing the universal need for salvation with Romans 3:23 prominently displayed.",
      ageGroup: "elementary",
      difficulty: "medium",
      timeEstimate: "20 minutes",
      biblePassages: ["Romans 3:23", "Romans 3:10"],
      thumbnailUrl: "/api/placeholder/200/150"
    },
    {
      id: "rom3-chart1",
      title: "Righteousness Through Faith Chart",
      type: "chart",
      description: "Step-by-step visual chart showing how righteousness comes through faith in Jesus Christ (Romans 3:22).",
      ageGroup: "youth",
      difficulty: "medium",
      timeEstimate: "15 minutes",
      biblePassages: ["Romans 3:21-24", "Ephesians 2:8-9"],
      thumbnailUrl: "/api/placeholder/200/150"
    },
    {
      id: "rom3-drawing1",
      title: "Before and After Faith",
      type: "drawing",
      description: "Drawing activity showing the transformation that happens when we believe in Jesus - before sin, after righteousness.",
      ageGroup: "elementary",
      difficulty: "medium",
      timeEstimate: "30 minutes",
      biblePassages: ["Romans 3:21-26", "2 Corinthians 5:17"],
      thumbnailUrl: "/api/placeholder/200/150"
    }
  ],
  4: [
    {
      id: "rom4-coloring1",
      title: "Abraham's Faith Coloring Page",
      type: "coloring",
      description: "Coloring page showing Abraham looking at the stars with Romans 4:16 about faith and God's promise.",
      ageGroup: "elementary",
      difficulty: "easy",
      timeEstimate: "20 minutes",
      biblePassages: ["Romans 4:16", "Genesis 15:5-6"],
      thumbnailUrl: "/api/placeholder/200/150"
    },
    {
      id: "rom4-activity1",
      title: "Stars of Faith Activity",
      type: "activity",
      description: "Hands-on activity where children create a 'Stars of Faith' poster, learning about Abraham's faith and God's promises.",
      ageGroup: "elementary",
      difficulty: "easy",
      timeEstimate: "25 minutes",
      biblePassages: ["Romans 4:18-21", "Genesis 15:5"],
      thumbnailUrl: "/api/placeholder/200/150"
    }
  ],
  5: [
    {
      id: "rom5-coloring1",
      title: "Peace with God Coloring Page",
      type: "coloring",
      description: "Peaceful scene coloring page with dove and olive branch, featuring Romans 5:1 about peace with God through faith.",
      ageGroup: "all",
      difficulty: "easy",
      timeEstimate: "15 minutes",
      biblePassages: ["Romans 5:1", "Romans 5:8"],
      thumbnailUrl: "/api/placeholder/200/150"
    },
    {
      id: "rom5-chart1",
      title: "God's Love Chart",
      type: "chart",
      description: "Heart-shaped chart showing Romans 5:8 - 'God demonstrates his love for us in this: While we were still sinners, Christ died for us.'",
      ageGroup: "all",
      difficulty: "easy",
      timeEstimate: "10 minutes",
      biblePassages: ["Romans 5:6-8", "John 3:16"],
      thumbnailUrl: "/api/placeholder/200/150"
    }
  ],
  6: [
    {
      id: "rom6-coloring1",
      title: "New Life in Christ Coloring Page",
      type: "coloring",
      description: "Butterfly transformation coloring page illustrating Romans 6:4 about walking in newness of life.",
      ageGroup: "elementary",
      difficulty: "medium",
      timeEstimate: "20 minutes",
      biblePassages: ["Romans 6:4", "Romans 6:11"],
      thumbnailUrl: "/api/placeholder/200/150"
    },
    {
      id: "rom6-activity1",
      title: "Old vs New Life Activity",
      type: "activity",
      description: "Interactive activity using before/after cards to teach about dying to sin and living for God.",
      ageGroup: "youth",
      difficulty: "medium",
      timeEstimate: "30 minutes",
      biblePassages: ["Romans 6:1-14", "Galatians 2:20"],
      thumbnailUrl: "/api/placeholder/200/150"
    }
  ]
};

// Generate placeholder resources for chapters 7-16
for (let i = 7; i <= 16; i++) {
  sundaySchoolResources[i] = [
    {
      id: `rom${i}-coloring1`,
      title: `Romans Chapter ${i} Coloring Page`,
      type: "coloring",
      description: `Educational coloring page for Romans chapter ${i} with key memory verse and biblical imagery.`,
      ageGroup: "elementary",
      difficulty: "easy",
      timeEstimate: "15-20 minutes",
      biblePassages: [`Romans ${i}:1-5`],
      thumbnailUrl: "/api/placeholder/200/150"
    },
    {
      id: `rom${i}-chart1`,
      title: `Romans ${i} Teaching Chart`,
      type: "chart",
      description: `Visual teaching chart for the main themes and lessons from Romans chapter ${i}.`,
      ageGroup: "all",
      difficulty: "medium",
      timeEstimate: "10-15 minutes",
      biblePassages: [`Romans ${i}:1-10`],
      thumbnailUrl: "/api/placeholder/200/150"
    },
    {
      id: `rom${i}-activity1`,
      title: `Chapter ${i} Learning Activity`,
      type: "activity",
      description: `Interactive learning activity designed to help children understand the key concepts from Romans ${i}.`,
      ageGroup: "elementary",
      difficulty: "medium",
      timeEstimate: "20-25 minutes",
      biblePassages: [`Romans ${i}:1-15`],
      thumbnailUrl: "/api/placeholder/200/150"
    }
  ];
}

const getTypeIcon = (type: string) => {
  switch (type) {
    case 'coloring': return <Palette className="h-4 w-4" />;
    case 'chart': return <BarChart3 className="h-4 w-4" />;
    case 'drawing': return <Image className="h-4 w-4" />;
    case 'activity': return <Users className="h-4 w-4" />;
    case 'lesson': return <BookOpen className="h-4 w-4" />;
    default: return <BookOpen className="h-4 w-4" />;
  }
};

const getAgeGroupColor = (ageGroup: string) => {
  switch (ageGroup) {
    case 'preschool': return 'bg-pink-100 text-pink-800 dark:bg-pink-900/20 dark:text-pink-300';
    case 'elementary': return 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300';
    case 'youth': return 'bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-300';
    case 'all': return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300';
    default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300';
  }
};

const getDifficultyColor = (difficulty: string) => {
  switch (difficulty) {
    case 'easy': return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300';
    case 'medium': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300';
    case 'hard': return 'bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300';
    default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300';
  }
};

export function SundaySchoolResources({ chapter, onChapterChange }: SundaySchoolResourcesProps) {
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedAgeGroup, setSelectedAgeGroup] = useState<string>('all');
  
  const chapterResources = sundaySchoolResources[chapter] || [];
  
  const filteredResources = chapterResources.filter(resource => {
    const typeMatch = selectedType === 'all' || resource.type === selectedType;
    const ageMatch = selectedAgeGroup === 'all' || resource.ageGroup === selectedAgeGroup || resource.ageGroup === 'all';
    return typeMatch && ageMatch;
  });

  const resourceTypes = ['all', 'coloring', 'chart', 'drawing', 'activity', 'lesson'];
  const ageGroups = ['all', 'preschool', 'elementary', 'youth'];

  const handleDownload = (resource: Resource) => {
    // In a real application, this would trigger an actual download
    console.log(`Downloading resource: ${resource.title}`);
    // You would implement actual file download here
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-2">
          Sunday School Resources
        </h1>
        <p className="text-lg text-gray-600 dark:text-gray-400 mb-4">
          Free educational materials for Romans Chapter {chapter}
        </p>
        <div className="flex justify-center">
          <Badge variant="outline" className="text-sm">
            {filteredResources.length} resources available
          </Badge>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Filter Resources</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 block">
                Resource Type
              </label>
              <div className="flex flex-wrap gap-2">
                {resourceTypes.map(type => (
                  <Button
                    key={type}
                    variant={selectedType === type ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedType(type)}
                    className="capitalize"
                  >
                    {type === 'all' ? 'All Types' : type}
                  </Button>
                ))}
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 block">
                Age Group
              </label>
              <div className="flex flex-wrap gap-2">
                {ageGroups.map(age => (
                  <Button
                    key={age}
                    variant={selectedAgeGroup === age ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedAgeGroup(age)}
                    className="capitalize"
                  >
                    {age === 'all' ? 'All Ages' : age}
                  </Button>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Chapter Navigation */}
      <Card>
        <CardContent className="p-4">
          <div className="flex justify-between items-center">
            <Button
              variant="outline"
              size="sm"
              onClick={() => onChapterChange && onChapterChange(Math.max(1, chapter - 1))}
              disabled={chapter <= 1}
            >
              ← Chapter {chapter - 1}
            </Button>
            
            <div className="text-center">
              <h3 className="font-semibold">Romans Chapter {chapter}</h3>
              <p className="text-sm text-gray-500">Select a different chapter for more resources</p>
            </div>
            
            <Button
              variant="outline"
              size="sm"
              onClick={() => onChapterChange && onChapterChange(Math.min(16, chapter + 1))}
              disabled={chapter >= 16}
            >
              Chapter {chapter + 1} →
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Resources Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredResources.map((resource) => (
          <Card key={resource.id} className="hover:shadow-lg transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2">
                  {getTypeIcon(resource.type)}
                  <h3 className="font-semibold text-sm line-clamp-2">{resource.title}</h3>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleDownload(resource)}
                  className="shrink-0"
                >
                  <Download className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {/* Thumbnail placeholder */}
              <div className="aspect-[4/3] bg-gray-100 dark:bg-gray-800 rounded-lg flex items-center justify-center">
                <div className="text-center text-gray-400">
                  {getTypeIcon(resource.type)}
                  <p className="text-xs mt-1">Preview</p>
                </div>
              </div>
              
              {/* Description */}
              <p className="text-sm text-gray-600 dark:text-gray-400 line-clamp-3">
                {resource.description}
              </p>
              
              {/* Badges */}
              <div className="flex flex-wrap gap-2">
                <Badge className={getAgeGroupColor(resource.ageGroup)}>
                  {resource.ageGroup}
                </Badge>
                <Badge className={getDifficultyColor(resource.difficulty)}>
                  {resource.difficulty}
                </Badge>
              </div>
              
              {/* Time and Bible passages */}
              <div className="space-y-2">
                <div className="flex items-center gap-1 text-xs text-gray-500">
                  <Clock className="h-3 w-3" />
                  {resource.timeEstimate}
                </div>
                <div className="flex flex-wrap gap-1">
                  {resource.biblePassages.map((passage, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {passage}
                    </Badge>
                  ))}
                </div>
              </div>
              
              {/* Download button */}
              <Button 
                onClick={() => handleDownload(resource)}
                className="w-full"
                size="sm"
              >
                <Download className="h-4 w-4 mr-2" />
                Download Free
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* No results message */}
      {filteredResources.length === 0 && (
        <Card>
          <CardContent className="text-center py-8">
            <BookOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">
              No resources found
            </h3>
            <p className="text-gray-500 dark:text-gray-400">
              Try adjusting your filters or check back later for more resources.
            </p>
          </CardContent>
        </Card>
      )}
      
      {/* Footer info */}
      <Card className="bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-800">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <Star className="h-5 w-5 text-blue-600 dark:text-blue-400 mt-0.5" />
            <div>
              <h4 className="font-medium text-blue-900 dark:text-blue-100 mb-2">
                Free Sunday School Resources
              </h4>
              <p className="text-sm text-blue-700 dark:text-blue-300">
                All resources are provided free of charge for educational and ministry use. 
                These materials are designed to help teachers, parents, and ministry leaders 
                share the truths of Romans with children and youth in engaging, age-appropriate ways.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}