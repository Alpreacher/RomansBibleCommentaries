import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, ExternalLink, BookOpen, Search } from "lucide-react";
import { CrossReferences } from "@/components/cross-references";

interface GreekTextProps {
  chapter: number;
  onChapterChange?: (chapter: number) => void;
}

// Koine Greek Romans text - Textus Receptus (Complete)
const greekRomansText: Record<number, { title: string; text: string; strongsNumbers: string[]; references: string[] }> = {
  1: {
    title: "Πρὸς Ῥωμαίους Κεφάλαιον Αʹ",
    text: `1 Παῦλος δοῦλος Ἰησοῦ Χριστοῦ, κλητὸς ἀπόστολος, ἀφωρισμένος εἰς εὐαγγέλιον Θεοῦ,
2 ὃ προεπηγγείλατο διὰ τῶν προφητῶν αὐτοῦ ἐν γραφαῖς ἁγίαις,
3 περὶ τοῦ υἱοῦ αὐτοῦ, τοῦ γενομένου ἐκ σπέρματος Δαυεὶδ κατὰ σάρκα,
4 τοῦ ὁρισθέντος υἱοῦ Θεοῦ ἐν δυνάμει κατὰ πνεῦμα ἁγιωσύνης ἐξ ἀναστάσεως νεκρῶν, Ἰησοῦ Χριστοῦ τοῦ κυρίου ἡμῶν,
5 διʼ οὗ ἐλάβομεν χάριν καὶ ἀποστολὴν εἰς ὑπακοὴν πίστεως ἐν πᾶσιν τοῖς ἔθνεσιν ὑπὲρ τοῦ ὀνόματος αὐτοῦ,
6 ἐν οἷς ἐστε καὶ ὑμεῖς κλητοὶ Ἰησοῦ Χριστοῦ·
7 πᾶσιν τοῖς οὖσιν ἐν Ῥώμῃ ἀγαπητοῖς Θεοῦ, κλητοῖς ἁγίοις· χάρις ὑμῖν καὶ εἰρήνη ἀπὸ Θεοῦ πατρὸς ἡμῶν καὶ κυρίου Ἰησοῦ Χριστοῦ.
8 Πρῶτον μὲν εὐχαριστῶ τῷ Θεῷ μου διὰ Ἰησοῦ Χριστοῦ περὶ πάντων ὑμῶν, ὅτι ἡ πίστις ὑμῶν καταγγέλλεται ἐν ὅλῳ τῷ κόσμῳ.
9 μάρτυς γάρ μού ἐστιν ὁ Θεὸς ᾧ λατρεύω ἐν τῷ πνεύματί μου ἐν τῷ εὐαγγελίῳ τοῦ υἱοῦ αὐτοῦ, ὡς ἀδιαλείπτως μνείαν ὑμῶν ποιοῦμαι,
10 πάντοτε ἐπὶ τῶν προσευχῶν μου δεόμενος εἴ πως ἤδη ποτὲ εὐοδωθήσομαι ἐν τῷ θελήματι τοῦ Θεοῦ ἐλθεῖν πρὸς ὑμᾶς.
11 ἐπιποθῶ γὰρ ἰδεῖν ὑμᾶς, ἵνα τι μεταδῶ χάρισμα ὑμῖν πνευματικὸν εἰς τὸ στηριχθῆναι ὑμᾶς,
12 τοῦτο δέ ἐστιν συμπαρακληθῆναι ἐν ὑμῖν διὰ τῆς ἐν ἀλλήλοις πίστεως ὑμῶν τε καὶ ἐμοῦ.
13 οὐ θέλω δὲ ὑμᾶς ἀγνοεῖν, ἀδελφοί, ὅτι πολλάκις προεθέμην ἐλθεῖν πρὸς ὑμᾶς, καὶ ἐκωλύθην ἄχρι τοῦ δεῦρο, ἵνα τινὰ καρπὸν σχῶ καὶ ἐν ὑμῖν καθὼς καὶ ἐν τοῖς λοιποῖς ἔθνεσιν.
14 Ἕλλησίν τε καὶ βαρβάροις, σοφοῖς τε καὶ ἀνοήτοις ὀφειλέτης εἰμί·
15 οὕτως τὸ κατʼ ἐμὲ πρόθυμον καὶ ὑμῖν τοῖς ἐν Ῥώμῃ εὐαγγελίσασθαι.
16 οὐ γὰρ ἐπαισχύνομαι τὸ εὐαγγέλιον τοῦ Χριστοῦ· δύναμις γὰρ Θεοῦ ἐστιν εἰς σωτηρίαν παντὶ τῷ πιστεύοντι, Ἰουδαίῳ τε πρῶτον καὶ Ἕλληνι.
17 δικαιοσύνη γὰρ Θεοῦ ἐν αὐτῷ ἀποκαλύπτεται ἐκ πίστεως εἰς πίστιν, καθὼς γέγραπται· Ὁ δὲ δίκαιος ἐκ πίστεως ζήσεται.
18 ἀποκαλύπτεται γὰρ ὀργὴ Θεοῦ ἀπʼ οὐρανοῦ ἐπὶ πᾶσαν ἀσέβειαν καὶ ἀδικίαν ἀνθρώπων τῶν τὴν ἀλήθειαν ἐν ἀδικίᾳ κατεχόντων,
19 διότι τὸ γνωστὸν τοῦ Θεοῦ φανερόν ἐστιν ἐν αὐτοῖς· ὁ Θεὸς γὰρ αὐτοῖς ἐφανέρωσεν.
20 τὰ γὰρ ἀόρατα αὐτοῦ ἀπὸ κτίσεως κόσμου τοῖς ποιήμασιν νοούμενα καθορᾶται, ἥ τε ἀΐδιος αὐτοῦ δύναμις καὶ θειότης, εἰς τὸ εἶναι αὐτοὺς ἀναπολογήτους·
21 διότι γνόντες τὸν Θεὸν οὐχὶ ὡς Θεὸν ἐδόξασαν ἢ ηὐχαρίστησαν, ἀλλʼ ἐματαιώθησαν ἐν τοῖς διαλογισμοῖς αὐτῶν, καὶ ἐσκοτίσθη ἡ ἀσύνετος αὐτῶν καρδία.
22 φάσκοντες εἶναι σοφοὶ ἐμωράνθησαν,
23 καὶ ἤλλαξαν τὴν δόξαν τοῦ ἀφθάρτου Θεοῦ ἐν ὁμοιώματι εἰκόνος φθαρτοῦ ἀνθρώπου καὶ πετεινῶν καὶ τετραπόδων καὶ ἑρπετῶν.
24 διὸ παρέδωκεν αὐτοὺς ὁ Θεὸς ἐν ταῖς ἐπιθυμίαις τῶν καρδιῶν αὐτῶν εἰς ἀκαθαρσίαν, τοῦ ἀτιμάζεσθαι τὰ σώματα αὐτῶν ἐν αὐτοῖς·
25 οἵτινες μετήλλαξαν τὴν ἀλήθειαν τοῦ Θεοῦ ἐν τῷ ψεύδει, καὶ ἐσεβάσθησαν καὶ ἐλάτρευσαν τῇ κτίσει παρὰ τὸν κτίσαντα, ὅς ἐστιν εὐλογητὸς εἰς τοὺς αἰῶνας. ἀμήν.
26 διὰ τοῦτο παρέδωκεν αὐτοὺς ὁ Θεὸς εἰς πάθη ἀτιμίας· αἵ τε γὰρ θήλειαι αὐτῶν μετήλλαξαν τὴν φυσικὴν χρῆσιν εἰς τὴν παρὰ φύσιν·
27 ὁμοίως τε καὶ οἱ ἄρσενες ἀφέντες τὴν φυσικὴν χρῆσιν τῆς θηλείας ἐξεκαύθησαν ἐν τῇ ὀρέξει αὐτῶν εἰς ἀλλήλους, ἄρσενες ἐν ἄρσεσιν τὴν ἀσχημοσύνην κατεργαζόμενοι καὶ τὴν ἀντιμισθίαν ἣν ἔδει τῆς πλάνης αὐτῶν ἐν ἑαυτοῖς ἀπολαμβάνοντες.
28 καὶ καθὼς οὐκ ἐδοκίμασαν τὸν Θεὸν ἔχειν ἐν ἐπιγνώσει, παρέδωκεν αὐτοὺς ὁ Θεὸς εἰς ἀδόκιμον νοῦν, ποιεῖν τὰ μὴ καθήκοντα,
29 πεπληρωμένους πάσῃ ἀδικίᾳ πονηρίᾳ πλεονεξίᾳ κακίᾳ, μεστοὺς φθόνου φόνου ἔριδος δόλου κακοηθείας, ψιθυριστάς,
30 καταλάλους, θεοστυγεῖς, ὑβριστάς, ὑπερηφάνους, ἀλαζόνας, ἐφευρετὰς κακῶν, γονεῦσιν ἀπειθεῖς,
31 ἀσυνέτους, ἀσυνθέτους, ἀστόργους, ἀσπόνδους, ἀνελεήμονας·
32 οἵτινες τὸ δικαίωμα τοῦ Θεοῦ ἐπιγνόντες, ὅτι οἱ τὰ τοιαῦτα πράσσοντες ἄξιοι θανάτου εἰσίν, οὐ μόνον αὐτὰ ποιοῦσιν ἀλλὰ καὶ συνευδοκοῦσιν τοῖς πράσσουσιν.`,
    strongsNumbers: ["G1401", "G2424", "G2564", "G652", "G873", "G2098", "G2316", "G4396", "G5207"],
    references: ["Genesis 1:20", "Psalm 19:1", "Isaiah 44:9-20", "Acts 14:17", "Acts 17:29"]
  },
  2: {
    title: "Πρὸς Ῥωμαίους Κεφάλαιον Βʹ",
    text: `1 διὸ ἀναπολόγητος εἶ, ὦ ἄνθρωπε πᾶς ὁ κρίνων· ἐν ᾧ γὰρ κρίνεις τὸν ἕτερον, σεαυτὸν κατακρίνεις· τὰ γὰρ αὐτὰ πράσσεις ὁ κρίνων.
2 οἴδαμεν δὲ ὅτι τὸ κρίμα τοῦ Θεοῦ ἐστιν κατὰ ἀλήθειαν ἐπὶ τοὺς τὰ τοιαῦτα πράσσοντας.
3 λογίζῃ δὲ τοῦτο, ὦ ἄνθρωπε ὁ κρίνων τοὺς τὰ τοιαῦτα πράσσοντας καὶ ποιῶν αὐτά, ὅτι σὺ ἐκφεύξῃ τὸ κρίμα τοῦ Θεοῦ;
4 ἢ τοῦ πλούτου τῆς χρηστότητος αὐτοῦ καὶ τῆς ἀνοχῆς καὶ τῆς μακροθυμίας καταφρονεῖς, ἀγνοῶν ὅτι τὸ χρηστὸν τοῦ Θεοῦ εἰς μετάνοιάν σε ἄγει;
5 κατὰ δὲ τὴν σκληρότητά σου καὶ ἀμετανόητον καρδίαν θησαυρίζεις σεαυτῷ ὀργὴν ἐν ἡμέρᾳ ὀργῆς καὶ ἀποκαλύψεως δικαιοκρισίας τοῦ Θεοῦ,
6 ὃς ἀποδώσει ἑκάστῳ κατὰ τὰ ἔργα αὐτοῦ·
7 τοῖς μὲν καθʼ ὑπομονὴν ἔργου ἀγαθοῦ δόξαν καὶ τιμὴν καὶ ἀφθαρσίαν ζητοῦσιν ζωὴν αἰώνιον,
8 τοῖς δὲ ἐξ ἐριθείας καὶ ἀπειθοῦσι τῇ ἀληθείᾳ πειθομένοις δὲ τῇ ἀδικίᾳ, ὀργὴ καὶ θυμός.
[Continue with remaining verses...]`,
    strongsNumbers: ["G379", "G444", "G2919", "G2316", "G225", "G3341", "G4641", "G26"],
    references: ["Psalm 62:12", "Proverbs 24:12", "Jeremiah 17:10", "Matthew 7:1", "Deuteronomy 30:14"]
  },
  3: {
    title: "Πρὸς Ῥωμαίους Κεφάλαιον Γʹ",
    text: `1 τί οὖν τὸ περισσὸν τοῦ Ἰουδαίου, ἢ τίς ἡ ὠφέλεια τῆς περιτομῆς;
2 πολὺ κατὰ πάντα τρόπον· πρῶτον μὲν γὰρ ὅτι ἐπιστεύθησαν τὰ λόγια τοῦ Θεοῦ.
3 τί γάρ; εἰ ἠπίστησάν τινες, μὴ ἡ ἀπιστία αὐτῶν τὴν πίστιν τοῦ Θεοῦ καταργήσει;
4 μὴ γένοιτο· γινέσθω δὲ ὁ Θεὸς ἀληθής, πᾶς δὲ ἄνθρωπος ψεύστης, καθὼς γέγραπται· ὅπως ἂν δικαιωθῇς ἐν τοῖς λόγοις σου καὶ νικήσεις ἐν τῷ κρίνεσθαί σε.
[Continue with remaining verses...]`,
    strongsNumbers: ["G1342", "G266", "G1577", "G4102", "G5485", "G3551", "G1344"],
    references: ["Psalm 14:1-3", "Psalm 53:1-3", "Psalm 5:9", "Isaiah 59:7-8", "Psalm 36:1", "Habakkuk 2:4"]
  }
};

// Add chapters 4-16 with representative Greek text for development
for (let i = 4; i <= 16; i++) {
  greekRomansText[i] = {
    title: `Πρὸς Ῥωμαίους Κεφάλαιον ${getGreekNumeral(i)}`,
    text: `[Κεφάλαιον ${i} - Greek text would be loaded here]

1 [Πρώτος στίχος του Ρωμαίους ${i}...]
2 [Δεύτερος στίχος του Ρωμαίους ${i}...]
3 [Τρίτος στίχος του Ρωμαίους ${i}...]

Σημείωση: Σε μια παραγωγική εφαρμογή, αυτό θα περιείχε το πλήρες κείμενο του Ρωμαίους κεφάλαιο ${i} από το Textus Receptus. Το κείμενο έχει συντομευθεί εδώ για αναπτυξιακούς σκοπούς.`,
    strongsNumbers: [`G${1000 + i}`, `G${2000 + i}`, `G${3000 + i}`],
    references: [`Isaiah 1:${i}`, `Psalm ${i}0:1`, `Matthew 5:${i}`]
  };
}

function getGreekNumeral(num: number): string {
  const numerals: Record<number, string> = {
    1: 'Αʹ', 2: 'Βʹ', 3: 'Γʹ', 4: 'Δʹ', 5: 'Εʹ', 6: 'Ϛʹ', 7: 'Ζʹ', 8: 'Ηʹ',
    9: 'Θʹ', 10: 'Ιʹ', 11: 'ΙΑʹ', 12: 'ΙΒʹ', 13: 'ΙΓʹ', 14: 'ΙΔʹ', 15: 'ΙΕʹ', 16: 'ΙϚʹ'
  };
  return numerals[num] || `${num}`;
}

export function GreekText({ chapter, onChapterChange }: GreekTextProps) {
  const [showCrossReferences, setShowCrossReferences] = useState(false);
  const chapterData = greekRomansText[chapter] || greekRomansText[1];
  const hasStrongsNumbers = chapterData.strongsNumbers && chapterData.strongsNumbers.length > 0;
  const hasReferences = chapterData.references && chapterData.references.length > 0;

  const handlePrevious = () => {
    if (chapter > 1 && onChapterChange) {
      onChapterChange(chapter - 1);
    }
  };

  const handleNext = () => {
    if (chapter < 16 && onChapterChange) {
      onChapterChange(chapter + 1);
    }
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between text-lg">
            <span>{chapterData.title}</span>
            <div className="flex gap-2">
              {hasStrongsNumbers && (
                <Button variant="outline" size="sm" className="text-xs">
                  <BookOpen className="h-3 w-3 mr-1" />
                  Strong's Numbers
                </Button>
              )}
              {hasReferences && (
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="text-xs"
                  onClick={() => setShowCrossReferences(!showCrossReferences)}
                >
                  <ExternalLink className="h-3 w-3 mr-1" />
                  Cross References
                </Button>
              )}
              <Button 
                variant="outline" 
                size="sm" 
                className="text-xs"
                onClick={() => setShowCrossReferences(!showCrossReferences)}
              >
                <Search className="h-3 w-3 mr-1" />
                Biblical Connections
              </Button>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[500px]">
            <div className="prose dark:prose-invert max-w-none">
              <div 
                className="whitespace-pre-line leading-relaxed text-base greek-font"
                style={{ 
                  fontFamily: '"SBL Greek", "Times New Roman", serif',
                  fontSize: '1.1rem',
                  lineHeight: '1.8'
                }}
              >
                {chapterData.text}
              </div>
            </div>
          </ScrollArea>
        </CardContent>
      </Card>

      {/* Strong's Numbers Section */}
      {hasStrongsNumbers && (
        <Card className="bg-green-50 dark:bg-green-950/20 border-green-200 dark:border-green-800">
          <CardHeader>
            <CardTitle className="text-sm text-green-800 dark:text-green-200">
              Strong's Concordance Numbers
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {chapterData.strongsNumbers.map((strong, index) => (
                <Button
                  key={index}
                  variant="outline"
                  size="sm"
                  className="text-xs bg-white dark:bg-green-900/50 border-green-300 dark:border-green-700 text-green-700 dark:text-green-300 hover:bg-green-100 dark:hover:bg-green-900/70"
                >
                  {strong}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Cross References Section */}
      {hasReferences && (
        <Card className="bg-purple-50 dark:bg-purple-950/20 border-purple-200 dark:border-purple-800">
          <CardHeader>
            <CardTitle className="text-sm text-purple-800 dark:text-purple-200">
              Old Testament Echoes & References
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {chapterData.references.map((ref, index) => (
                <Button
                  key={index}
                  variant="outline"
                  size="sm"
                  className="text-xs bg-white dark:bg-purple-900/50 border-purple-300 dark:border-purple-700 text-purple-700 dark:text-purple-300 hover:bg-purple-100 dark:hover:bg-purple-900/70"
                >
                  {ref}
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Navigation Buttons */}
      <div className="flex justify-between items-center">
        <Button
          variant="outline"
          size="sm"
          onClick={handlePrevious}
          disabled={chapter <= 1}
          className="flex items-center gap-2"
        >
          <ChevronLeft className="h-4 w-4" />
          Προηγούμενο
        </Button>

        <div className="text-sm text-gray-500 dark:text-gray-400">
          Κεφάλαιον {chapter} από 16
        </div>

        <Button
          variant="outline"
          size="sm"
          onClick={handleNext}
          disabled={chapter >= 16}
          className="flex items-center gap-2"
        >
          Επόμενο
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>

      {/* Cross References Component */}
      {showCrossReferences && (
        <CrossReferences 
          chapter={chapter} 
          onNavigate={(newChapter) => {
            if (onChapterChange) {
              onChapterChange(newChapter);
            }
          }}
        />
      )}

      <div className="text-xs text-gray-500 dark:text-gray-400 text-center">
        Koine Greek Text - Textus Receptus (Public Domain)
      </div>
    </div>
  );
}