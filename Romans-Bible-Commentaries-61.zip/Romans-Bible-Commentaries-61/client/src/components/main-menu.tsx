import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Menu, X, BookOpen, Users, FileText, Languages, Quote, Settings, Clock, Map, Globe } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger, SheetDescription } from "@/components/ui/sheet";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Commentary } from "@shared/schema";

interface MainMenuProps {
  onCommentarySelect: (commentaryId: number) => void;
  onViewChange: (view: 'commentary' | 'key-themes-dictionary' | 'kjv' | 'greek' | 'russian' | 'esv' | 'dictionary' | 'examples' | 'echoes' | 'other-commentators' | 'sunday-school' | 'romans-timeline' | 'maps-of-romans' | 'background-romans-paul' | 'settings') => void;
  selectedCommentaryId: number;
}

export function MainMenu({ onCommentarySelect, onViewChange, selectedCommentaryId }: MainMenuProps) {
  const [isOpen, setIsOpen] = useState(false);

  const { data: commentaries } = useQuery<Commentary[]>({
    queryKey: ["/api/commentaries"],
  });

  const handleMenuItemClick = (action: () => void) => {
    action();
    setIsOpen(false);
  };

  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" className="md:hidden">
          <Menu className="h-5 w-5" />
          <span className="sr-only">Open menu</span>
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="w-80 sm:w-96">
        <SheetHeader className="pb-4">
          <SheetTitle className="text-left">Biblical Commentary Reader</SheetTitle>
          <SheetDescription className="text-left">
            Access commentaries, study resources, and biblical texts
          </SheetDescription>
        </SheetHeader>
        <ScrollArea className="h-[calc(100vh-8rem)]">
          <div className="space-y-6 px-1">
            {/* Commentators */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Users className="h-4 w-4" />
                <h3 className="font-medium text-sm text-foreground">Commentators</h3>
              </div>
              <div className="space-y-1">
                {commentaries?.map((commentary) => (
                  <Button
                    key={commentary.id}
                    variant={selectedCommentaryId === commentary.id ? "secondary" : "ghost"}
                    className="w-full justify-start text-left h-auto py-2 px-3"
                    onClick={() => handleMenuItemClick(() => {
                      onCommentarySelect(commentary.id);
                      onViewChange('commentary');
                    })}
                  >
                    <div className="text-left">
                      <div className="font-medium text-sm">{commentary.author}</div>
                      <div className="text-xs text-muted-foreground truncate">
                        {commentary.title}
                      </div>
                    </div>
                  </Button>
                ))}
              </div>
            </div>

            <Separator />

            {/* Other Commentators */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Users className="h-4 w-4" />
                <h3 className="font-medium text-sm text-foreground">Other Commentators</h3>
              </div>
              <div className="space-y-1">
                <Button
                  variant="ghost"
                  className="w-full justify-start h-auto py-2 px-3"
                  onClick={() => handleMenuItemClick(() => onViewChange('other-commentators'))}
                >
                  <Users className="h-4 w-4 mr-2 flex-shrink-0" />
                  <span className="text-sm">Browse All Romans Commentators</span>
                </Button>
              </div>
            </div>

            <Separator />

            {/* Main Themes */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <BookOpen className="h-4 w-4" />
                <h3 className="font-medium text-sm text-foreground">Study Resources</h3>
              </div>
              <div className="space-y-1">
                <Button
                  variant="ghost"
                  className="w-full justify-start h-auto py-2 px-3"
                  onClick={() => handleMenuItemClick(() => onViewChange('key-themes-dictionary'))}
                >
                  <BookOpen className="h-4 w-4 mr-2 flex-shrink-0" />
                  <span className="text-sm">Key Themes of Romans</span>
                </Button>
                <Button
                  variant="ghost"
                  className="w-full justify-start h-auto py-2 px-3"
                  onClick={() => handleMenuItemClick(() => onViewChange('dictionary'))}
                >
                  <Languages className="h-4 w-4 mr-2 flex-shrink-0" />
                  <span className="text-sm">Greek Terms Dictionary</span>
                </Button>
                <Button
                  variant="ghost"
                  className="w-full justify-start h-auto py-2 px-3"
                  onClick={() => handleMenuItemClick(() => onViewChange('kjv'))}
                >
                  <FileText className="h-4 w-4 mr-2 flex-shrink-0" />
                  <span className="text-sm">Romans (KJV Translation)</span>
                </Button>
                <Button
                  variant="ghost"
                  className="w-full justify-start h-auto py-2 px-3"
                  onClick={() => handleMenuItemClick(() => onViewChange('greek'))}
                >
                  <Languages className="h-4 w-4 mr-2 flex-shrink-0" />
                  <span className="text-sm">Romans (Koine Greek)</span>
                </Button>
                <Button
                  variant="ghost"
                  className="w-full justify-start h-auto py-2 px-3"
                  onClick={() => handleMenuItemClick(() => onViewChange('russian'))}
                >
                  <FileText className="h-4 w-4 mr-2 flex-shrink-0" />
                  <span className="text-sm">Romans (Russian Synodal)</span>
                </Button>
                <Button
                  variant="ghost"
                  className="w-full justify-start h-auto py-2 px-3"
                  onClick={() => handleMenuItemClick(() => onViewChange('esv'))}
                >
                  <FileText className="h-4 w-4 mr-2 flex-shrink-0" />
                  <span className="text-sm">Romans (ESV Translation)</span>
                </Button>
                <Button
                  variant="ghost"
                  className="w-full justify-start h-auto py-2 px-3"
                  onClick={() => handleMenuItemClick(() => onViewChange('echoes'))}
                >
                  <Quote className="h-4 w-4 mr-2 flex-shrink-0" />
                  <span className="text-sm">Echoes of Scripture</span>
                </Button>
                <Button
                  variant="ghost"
                  className="w-full justify-start h-auto py-2 px-3"
                  onClick={() => handleMenuItemClick(() => onViewChange('romans-timeline'))}
                >
                  <Clock className="h-4 w-4 mr-2 flex-shrink-0" />
                  <span className="text-sm">Romans Timeline</span>
                </Button>
                <Button
                  variant="ghost"
                  className="w-full justify-start h-auto py-2 px-3"
                  onClick={() => handleMenuItemClick(() => onViewChange('maps-of-romans'))}
                >
                  <Map className="h-4 w-4 mr-2 flex-shrink-0" />
                  <span className="text-sm">Maps of Romans</span>
                </Button>
                <Button
                  variant="ghost"
                  className="w-full justify-start h-auto py-2 px-3"
                  onClick={() => handleMenuItemClick(() => onViewChange('background-romans-paul'))}
                >
                  <Globe className="h-4 w-4 mr-2 flex-shrink-0" />
                  <span className="text-sm">Background of Romans and Paul</span>
                </Button>
              </div>
            </div>

            <Separator />

            {/* Preaching Resources */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <BookOpen className="h-4 w-4" />
                <h3 className="font-medium text-sm text-foreground">Preaching Resources</h3>
              </div>
              <div className="space-y-1">
                <Button
                  variant="ghost"
                  className="w-full justify-start h-auto py-2 px-3"
                  onClick={() => handleMenuItemClick(() => onViewChange('examples'))}
                >
                  <BookOpen className="h-4 w-4 mr-2 flex-shrink-0" />
                  <span className="text-sm">Examples for Preachers</span>
                </Button>
              </div>
            </div>

            <Separator />

            {/* Educational Resources */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Users className="h-4 w-4" />
                <h3 className="font-medium text-sm text-foreground">Educational Resources</h3>
              </div>
              <div className="space-y-1">
                <Button
                  variant="ghost"
                  className="w-full justify-start h-auto py-2 px-3"
                  onClick={() => handleMenuItemClick(() => onViewChange('sunday-school'))}
                >
                  <Users className="h-4 w-4 mr-2 flex-shrink-0" />
                  <span className="text-sm">Sunday/Bible School Resources</span>
                </Button>
              </div>
            </div>

            <Separator />

            {/* Settings */}
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Settings className="h-4 w-4" />
                <h3 className="font-medium text-sm text-foreground">Settings</h3>
              </div>
              <div className="space-y-1">
                <Button
                  variant="ghost"
                  className="w-full justify-start h-auto py-2 px-3"
                  onClick={() => handleMenuItemClick(() => onViewChange('settings'))}
                >
                  <Settings className="h-4 w-4 mr-2 flex-shrink-0" />
                  <span className="text-sm">App Settings</span>
                </Button>
              </div>
            </div>
          </div>
        </ScrollArea>
      </SheetContent>
    </Sheet>
  );
}