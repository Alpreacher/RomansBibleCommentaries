import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, BookOpen, ExternalLink, Star, ChevronLeft, ChevronRight } from "lucide-react";

interface KeyThemesRomansProps {
  chapter?: number;
  onChapterChange?: (chapter: number) => void;
}

interface ThemeDefinition {
  id: string;
  term: string;
  greek?: string;
  strongsNumber?: string;
  definition: string;
  verseReferences: string[];
  chapters: number[];
  category: 'justification' | 'sanctification' | 'righteousness' | 'faith' | 'law' | 'sin' | 'grace' | 'salvation' | 'spirit' | 'flesh';
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  relatedTerms: string[];
}

// Chapter-specific key themes for Romans
const chapterSpecificThemes: Record<number, string[]> = {
  1: ['gospel-power', 'gods-wrath', 'natural-revelation', 'human-depravity'],
  2: ['gods-judgment', 'impartiality', 'conscience', 'circumcision-heart'],
  3: ['universal-sinfulness', 'justification-faith', 'righteousness-god', 'propitiation'],
  4: ['faith-abraham', 'righteousness-credited', 'promise-fulfillment', 'circumcision-uncircumcision'],
  5: ['peace-god', 'reconciliation', 'adams-sin', 'grace-abounds'],
  6: ['death-sin', 'new-life', 'baptism-union', 'slavery-righteousness'],
  7: ['law-sin', 'flesh-spirit', 'inner-conflict', 'death-deliverance'],
  8: ['no-condemnation', 'spirit-life', 'adoption-sonship', 'creation-groaning', 'intercession', 'inseparable-love'],
  9: ['gods-sovereignty', 'election', 'israels-rejection', 'vessels-mercy'],
  10: ['israels-zeal', 'righteousness-law-faith', 'universal-salvation', 'beautiful-feet'],
  11: ['israel-remnant', 'gentile-inclusion', 'olive-tree', 'gods-mercy'],
  12: ['living-sacrifice', 'body-christ', 'spiritual-gifts', 'practical-love'],
  13: ['government-authority', 'love-fulfills-law', 'eschatological-urgency'],
  14: ['weak-strong', 'conscience-matters', 'judgment-liberty', 'peace-edification'],
  15: ['unity-diversity', 'hope-scriptures', 'gentile-mission', 'apostolic-ministry'],
  16: ['fellow-workers', 'church-unity', 'final-warnings', 'gods-wisdom']
};

// Comprehensive key themes dictionary for Romans
const themesDatabase: Record<string, ThemeDefinition> = {
  'gospel-power': {
    id: 'gospel-power',
    term: 'Gospel Power',
    greek: 'δύναμις θεοῦ (dynamis theou)',
    strongsNumber: 'G1411',
    definition: 'The dynamic, life-transforming power of God revealed in the gospel message. Paul declares the gospel as God\'s power for salvation to everyone who believes, demonstrating its universal relevance and supernatural effectiveness.',
    verseReferences: ['Romans 1:16', 'Romans 1:17', '1 Corinthians 1:18', '1 Corinthians 1:24'],
    chapters: [1],
    category: 'salvation',
    difficulty: 'beginner',
    relatedTerms: ['salvation', 'faith', 'righteousness-god']
  },
  'gods-wrath': {
    id: 'gods-wrath',
    term: 'God\'s Wrath',
    greek: 'ὀργὴ θεοῦ (orge theou)',
    strongsNumber: 'G3709',
    definition: 'God\'s righteous anger and judgment against sin and unrighteousness. This is not arbitrary emotion but holy justice responding to moral rebellion against God\'s character and commands.',
    verseReferences: ['Romans 1:18', 'Romans 1:24', 'Romans 1:26', 'Romans 1:28', 'Romans 2:5'],
    chapters: [1, 2],
    category: 'sin',
    difficulty: 'intermediate',
    relatedTerms: ['judgment', 'sin', 'righteousness-god']
  },
  'natural-revelation': {
    id: 'natural-revelation',
    term: 'Natural Revelation',
    greek: 'φανερόω (phaneroo)',
    strongsNumber: 'G5319',
    definition: 'God\'s self-disclosure through creation and general revelation. Paul argues that God\'s invisible attributes are clearly seen through what has been made, leaving humanity without excuse.',
    verseReferences: ['Romans 1:19-20', 'Psalm 19:1', 'Acts 14:17'],
    chapters: [1],
    category: 'righteousness',
    difficulty: 'intermediate',
    relatedTerms: ['creation', 'gods-attributes', 'human-responsibility']
  },
  'human-depravity': {
    id: 'human-depravity',
    term: 'Human Depravity',
    greek: 'ἁμαρτία (hamartia)',
    strongsNumber: 'G266',
    definition: 'The universal corruption of human nature due to sin. Paul systematically demonstrates that all humanity, both Jew and Gentile, stands under the power and guilt of sin.',
    verseReferences: ['Romans 1:21-32', 'Romans 3:9-18', 'Romans 3:23'],
    chapters: [1, 2, 3],
    category: 'sin',
    difficulty: 'beginner',
    relatedTerms: ['sin', 'gods-wrath', 'universal-sinfulness']
  },
  'gods-judgment': {
    id: 'gods-judgment',
    term: 'God\'s Judgment',
    greek: 'κρίμα θεοῦ (krima theou)',
    strongsNumber: 'G2917',
    definition: 'God\'s righteous evaluation and sentencing of human actions. Paul emphasizes that God\'s judgment is according to truth, impartial, and based on deeds rather than appearances.',
    verseReferences: ['Romans 2:2-3', 'Romans 2:5', 'Romans 2:16', 'Romans 14:10'],
    chapters: [2, 14],
    category: 'righteousness',
    difficulty: 'intermediate',
    relatedTerms: ['impartiality', 'works', 'truth']
  },
  'impartiality': {
    id: 'impartiality',
    term: 'Divine Impartiality',
    greek: 'προσωπολημψία (prosopolempsia)',
    strongsNumber: 'G4382',
    definition: 'God shows no favoritism or partiality in His dealings with humanity. Both Jews and Gentiles are judged by the same standard and offered the same salvation.',
    verseReferences: ['Romans 2:11', 'Acts 10:34', 'Galatians 2:6'],
    chapters: [2, 3],
    category: 'righteousness',
    difficulty: 'beginner',
    relatedTerms: ['jew-gentile', 'gods-judgment', 'universal-salvation']
  },
  'universal-sinfulness': {
    id: 'universal-sinfulness',
    term: 'Universal Sinfulness',
    greek: 'πάντες ἥμαρτον (pantes hemarton)',
    strongsNumber: 'G264',
    definition: 'Paul\'s declaration that all have sinned and fall short of God\'s glory. This establishes the universal need for salvation and the impossibility of self-righteousness.',
    verseReferences: ['Romans 3:23', 'Romans 3:9-12', 'Romans 5:12'],
    chapters: [3, 5],
    category: 'sin',
    difficulty: 'beginner',
    relatedTerms: ['human-depravity', 'gods-glory', 'need-salvation']
  },
  'justification-faith': {
    id: 'justification-faith',
    term: 'Justification by Faith',
    greek: 'δικαιόω (dikaioo)',
    strongsNumber: 'G1344',
    definition: 'God\'s act of declaring sinners righteous through faith in Christ. This is the central theme of Romans - how God can be just and the justifier of those who believe.',
    verseReferences: ['Romans 3:24', 'Romans 3:28', 'Romans 4:5', 'Romans 5:1'],
    chapters: [3, 4, 5],
    category: 'justification',
    difficulty: 'beginner',
    relatedTerms: ['faith', 'righteousness-god', 'grace', 'works']
  },
  'righteousness-god': {
    id: 'righteousness-god',
    term: 'Righteousness of God',
    greek: 'δικαιοσύνη θεοῦ (dikaiosyne theou)',
    strongsNumber: 'G1343',
    definition: 'God\'s perfect moral character and His provision of righteousness for believers. This can refer both to God\'s attribute and to the righteousness He provides through Christ.',
    verseReferences: ['Romans 1:17', 'Romans 3:21-22', 'Romans 10:3'],
    chapters: [1, 3, 10],
    category: 'righteousness',
    difficulty: 'intermediate',
    relatedTerms: ['justification-faith', 'imputation', 'gods-character']
  },
  'faith-abraham': {
    id: 'faith-abraham',
    term: 'Abraham\'s Faith',
    greek: 'πίστις Ἀβραάμ (pistis Abraam)',
    strongsNumber: 'G4102',
    definition: 'Abraham as the exemplar of justifying faith. Paul uses Abraham to demonstrate that righteousness comes through faith apart from works, both for Jews and Gentiles.',
    verseReferences: ['Romans 4:16-22', 'Genesis 15:6', 'Galatians 3:6'],
    chapters: [4],
    category: 'faith',
    difficulty: 'intermediate',
    relatedTerms: ['righteousness-credited', 'promise', 'circumcision-uncircumcision']
  },
  'peace-god': {
    id: 'peace-god',
    term: 'Peace with God',
    greek: 'εἰρήνη πρὸς θεόν (eirene pros theon)',
    strongsNumber: 'G1515',
    definition: 'The reconciled relationship between God and believers through justification. This peace represents the end of hostility and the beginning of fellowship.',
    verseReferences: ['Romans 5:1', 'Romans 5:10', 'Ephesians 2:14'],
    chapters: [5],
    category: 'salvation',
    difficulty: 'beginner',
    relatedTerms: ['reconciliation', 'justification-faith', 'access-god']
  },
  'death-sin': {
    id: 'death-sin',
    term: 'Death to Sin',
    greek: 'νεκρὸς τῇ ἁμαρτίᾳ (nekros te hamartia)',
    strongsNumber: 'G3498',
    definition: 'The believer\'s spiritual death to sin\'s power and dominion through union with Christ\'s death. This enables freedom from sin\'s controlling influence.',
    verseReferences: ['Romans 6:2', 'Romans 6:6', 'Romans 6:11', 'Galatians 2:20'],
    chapters: [6],
    category: 'sanctification',
    difficulty: 'intermediate',
    relatedTerms: ['new-life', 'baptism-union', 'crucifixion-self']
  },
  'no-condemnation': {
    id: 'no-condemnation',
    term: 'No Condemnation',
    greek: 'οὐδὲν κατάκριμα (ouden katakrima)',
    strongsNumber: 'G2631',
    definition: 'The glorious reality that those in Christ Jesus face no condemnation. This represents complete freedom from guilt and punishment for sin.',
    verseReferences: ['Romans 8:1', 'Romans 8:33-34', 'John 5:24'],
    chapters: [8],
    category: 'salvation',
    difficulty: 'beginner',
    relatedTerms: ['christ-jesus', 'spirit-life', 'freedom-guilt']
  },
  'spirit-life': {
    id: 'spirit-life',
    term: 'Life in the Spirit',
    greek: 'ζωὴ πνεύματος (zoe pneumatos)',
    strongsNumber: 'G2222',
    definition: 'The new quality of life enabled by the Holy Spirit. This contrasts with life according to the flesh and represents the Spirit\'s transforming power.',
    verseReferences: ['Romans 8:2', 'Romans 8:6', 'Romans 8:10-11', 'Galatians 5:16'],
    chapters: [8],
    category: 'spirit',
    difficulty: 'intermediate',
    relatedTerms: ['holy-spirit', 'flesh-spirit', 'transformation']
  },
  'gods-sovereignty': {
    id: 'gods-sovereignty',
    term: 'God\'s Sovereignty',
    greek: 'προορίζω (proorizo)',
    strongsNumber: 'G4309',
    definition: 'God\'s absolute authority and control over salvation and history. Paul addresses the difficult question of Israel\'s rejection while affirming God\'s sovereign purposes.',
    verseReferences: ['Romans 9:11', 'Romans 9:15-16', 'Romans 9:21'],
    chapters: [9],
    category: 'righteousness',
    difficulty: 'advanced',
    relatedTerms: ['election', 'predestination', 'gods-mercy']
  },
  'living-sacrifice': {
    id: 'living-sacrifice',
    term: 'Living Sacrifice',
    greek: 'θυσία ζῶσα (thysia zosa)',
    strongsNumber: 'G2378',
    definition: 'The believer\'s response to God\'s mercy - offering their bodies as living sacrifices, holy and pleasing to God. This represents worship through dedicated living.',
    verseReferences: ['Romans 12:1', '1 Peter 2:5', 'Hebrews 13:15-16'],
    chapters: [12],
    category: 'sanctification',
    difficulty: 'beginner',
    relatedTerms: ['worship', 'dedication', 'transformation']
  }
};

// Add more themes for chapters 13-16
Object.assign(themesDatabase, {
  'government-authority': {
    id: 'government-authority',
    term: 'Government Authority',
    greek: 'ἐξουσία (exousia)',
    strongsNumber: 'G1849',
    definition: 'God\'s ordination of governing authorities for maintaining order and justice. Christians are called to submit to legitimate authority as part of their Christian duty.',
    verseReferences: ['Romans 13:1-7', '1 Peter 2:13-17', 'Titus 3:1'],
    chapters: [13],
    category: 'sanctification',
    difficulty: 'intermediate',
    relatedTerms: ['submission', 'civic-duty', 'gods-order']
  },
  'weak-strong': {
    id: 'weak-strong',
    term: 'Weak and Strong Believers',
    greek: 'ἀσθενής (asthenes)',
    strongsNumber: 'G772',
    definition: 'Paul\'s teaching on how believers with different levels of maturity should relate to each other, particularly regarding disputable matters of conscience.',
    verseReferences: ['Romans 14:1-23', '1 Corinthians 8:9', '1 Corinthians 10:23-24'],
    chapters: [14, 15],
    category: 'sanctification',
    difficulty: 'intermediate',
    relatedTerms: ['conscience', 'liberty', 'love', 'edification']
  },
  'unity-diversity': {
    id: 'unity-diversity',
    term: 'Unity in Diversity',
    greek: 'ἑνότης (henotes)',
    strongsNumber: 'G1775',
    definition: 'The harmony between Jewish and Gentile believers despite their different backgrounds. Paul envisions a united church that celebrates diversity while maintaining gospel unity.',
    verseReferences: ['Romans 15:5-7', 'Ephesians 4:3', 'Galatians 3:28'],
    chapters: [15],
    category: 'righteousness',
    difficulty: 'intermediate',
    relatedTerms: ['jew-gentile', 'acceptance', 'gods-glory']
  }
});

export function KeyThemesRomans({ chapter, onChapterChange }: KeyThemesRomansProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedTheme, setSelectedTheme] = useState<string | null>(null);

  // Get themes for specific chapter or all themes
  const relevantThemeIds = chapter 
    ? chapterSpecificThemes[chapter] || []
    : Object.keys(themesDatabase);

  const filteredThemes = relevantThemeIds
    .map(id => themesDatabase[id])
    .filter(theme => {
      if (!theme) return false;
      const matchesSearch = theme.term.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           theme.definition.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           (theme.greek && theme.greek.toLowerCase().includes(searchTerm.toLowerCase()));
      const matchesCategory = selectedCategory === 'all' || theme.category === selectedCategory;
      return matchesSearch && matchesCategory;
    });

  const categories = ['all', 'justification', 'sanctification', 'righteousness', 'faith', 'law', 'sin', 'grace', 'salvation', 'spirit'];

  const handlePrevious = () => {
    if (chapter && chapter > 1 && onChapterChange) {
      onChapterChange(chapter - 1);
    }
  };

  const handleNext = () => {
    if (chapter && chapter < 16 && onChapterChange) {
      onChapterChange(chapter + 1);
    }
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-2">
          Key Themes in Romans
        </h1>
        {chapter && (
          <p className="text-lg text-gray-600 dark:text-gray-400 mb-4">
            Chapter {chapter} Themes
          </p>
        )}
        <p className="text-gray-600 dark:text-gray-400">
          Comprehensive dictionary of theological themes and concepts in Paul's letter to the Romans
        </p>
      </div>

      {/* Chapter Navigation */}
      {chapter && onChapterChange && (
        <Card>
          <CardContent className="p-4">
            <div className="flex justify-between items-center">
              <Button
                variant="outline"
                size="sm"
                onClick={handlePrevious}
                disabled={chapter <= 1}
                className="flex items-center gap-2"
              >
                <ChevronLeft className="h-4 w-4" />
                Previous
              </Button>
              
              <div className="text-center">
                <h3 className="font-semibold">Romans Chapter {chapter}</h3>
                <p className="text-sm text-gray-500">{filteredThemes.length} key themes</p>
              </div>
              
              <Button
                variant="outline"
                size="sm"
                onClick={handleNext}
                disabled={chapter >= 16}
                className="flex items-center gap-2"
              >
                Next
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Search and Filters */}
      <Card>
        <CardHeader>
          <CardTitle>Search Themes</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search themes, definitions, or Greek terms..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <div>
            <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 block">
              Category
            </label>
            <div className="flex flex-wrap gap-2">
              {categories.map(category => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(category)}
                  className="capitalize"
                >
                  {category === 'all' ? 'All Categories' : category.replace('-', ' ')}
                </Button>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Themes Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredThemes.map((theme) => (
          <Card key={theme.id} className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-lg">{theme.term}</CardTitle>
                  {theme.greek && (
                    <p className="text-sm text-blue-600 dark:text-blue-400 mt-1">
                      {theme.greek}
                    </p>
                  )}
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSelectedTheme(theme.id)}
                >
                  <ExternalLink className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-sm text-gray-600 dark:text-gray-400 line-clamp-3">
                {theme.definition}
              </p>
              
              <div className="flex flex-wrap gap-2">
                <Badge variant="outline" className="capitalize">
                  {theme.category.replace('-', ' ')}
                </Badge>
                <Badge variant="outline" className="capitalize">
                  {theme.difficulty}
                </Badge>
                {theme.strongsNumber && (
                  <Badge variant="outline">
                    {theme.strongsNumber}
                  </Badge>
                )}
              </div>
              
              <div className="space-y-2">
                <h4 className="text-sm font-medium">Key Verses:</h4>
                <div className="flex flex-wrap gap-1">
                  {theme.verseReferences.slice(0, 3).map((ref, index) => (
                    <Badge key={index} variant="secondary" className="text-xs">
                      {ref}
                    </Badge>
                  ))}
                  {theme.verseReferences.length > 3 && (
                    <Badge variant="secondary" className="text-xs">
                      +{theme.verseReferences.length - 3} more
                    </Badge>
                  )}
                </div>
              </div>
              
              <div className="space-y-2">
                <h4 className="text-sm font-medium">Chapters:</h4>
                <div className="flex flex-wrap gap-1">
                  {theme.chapters.map(ch => (
                    <Badge 
                      key={ch} 
                      variant={ch === chapter ? "default" : "outline"} 
                      className="text-xs cursor-pointer"
                      onClick={() => onChapterChange && onChapterChange(ch)}
                    >
                      {ch}
                    </Badge>
                  ))}
                </div>
              </div>
              
              <Button className="w-full" size="sm" variant="outline">
                <BookOpen className="h-4 w-4 mr-2" />
                View Full Definition
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredThemes.length === 0 && (
        <Card>
          <CardContent className="text-center py-8">
            <BookOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">
              No themes found
            </h3>
            <p className="text-gray-500 dark:text-gray-400">
              Try adjusting your search terms or category filter.
            </p>
          </CardContent>
        </Card>
      )}

      {/* Footer Info */}
      <Card className="bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-800">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <Star className="h-5 w-5 text-blue-600 dark:text-blue-400 mt-0.5" />
            <div>
              <h4 className="font-medium text-blue-900 dark:text-blue-100 mb-2">
                Free Theological Dictionary
              </h4>
              <p className="text-sm text-blue-700 dark:text-blue-300">
                This comprehensive dictionary draws from scholarly sources including BDAG, 
                Theological Dictionary of the New Testament, and contemporary Romans scholarship. 
                All content is provided free for educational and ministry use.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}