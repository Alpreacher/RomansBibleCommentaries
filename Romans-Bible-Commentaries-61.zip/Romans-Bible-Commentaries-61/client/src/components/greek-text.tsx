import { useState } from "react";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, ExternalLink, Search, BookOpen } from "lucide-react";
import { CrossReferences } from "@/components/cross-references";
import { TextToSpeech } from "@/components/text-to-speech";

interface GreekTextProps {
  chapter: number;
  onChapterChange?: (chapter: number) => void;
}

// Greek Romans text data (sample)
const greekRomansText: Record<number, { title: string; text: string; strongsNumbers?: string[]; references: string[] }> = {
  1: {
    title: "Πρὸς Ῥωμαίους Κεφάλαιον Αʹ",
    text: `1 Παῦλος δοῦλος Χριστοῦ Ἰησοῦ, κλητὸς ἀπόστολος ἀφωρισμένος εἰς εὐαγγέλιον θεοῦ,
2 ὃ προεπηγγείλατο διὰ τῶν προφητῶν αὐτοῦ ἐν γραφαῖς ἁγίαις,
3 περὶ τοῦ υἱοῦ αὐτοῦ τοῦ γενομένου ἐκ σπέρματος Δαυὶδ κατὰ σάρκα,
4 τοῦ ὁρισθέντος υἱοῦ θεοῦ ἐν δυνάμει κατὰ πνεῦμα ἁγιωσύνης ἐξ ἀναστάσεως νεκρῶν, Ἰησοῦ Χριστοῦ τοῦ κυρίου ἡμῶν,
5 δι᾽ οὗ ἐλάβομεν χάριν καὶ ἀποστολὴν εἰς ὑπακοὴν πίστεως ἐν πᾶσιν τοῖς ἔθνεσιν ὑπὲρ τοῦ ὀνόματος αὐτοῦ,
6 ἐν οἷς ἐστε καὶ ὑμεῖς κλητοὶ Ἰησοῦ Χριστοῦ·
7 πᾶσιν τοῖς οὖσιν ἐν Ῥώμῃ ἀγαπητοῖς θεοῦ, κλητοῖς ἁγίοις· χάρις ὑμῖν καὶ εἰρήνη ἀπὸ θεοῦ πατρὸς ἡμῶν καὶ κυρίου Ἰησοῦ Χριστοῦ.
8 Πρῶτον μὲν εὐχαριστῶ τῷ θεῷ μου διὰ Ἰησοῦ Χριστοῦ περὶ πάντων ὑμῶν, ὅτι ἡ πίστις ὑμῶν καταγγέλλεται ἐν ὅλῳ τῷ κόσμῳ.
9 μάρτυς γάρ μού ἐστιν ὁ θεός, ᾧ λατρεύω ἐν τῷ πνεύματί μου ἐν τῷ εὐαγγελίῳ τοῦ υἱοῦ αὐτοῦ, ὡς ἀδιαλείπτως μνείαν ὑμῶν ποιοῦμαι
10 πάντοτε ἐπὶ τῶν προσευχῶν μου δεόμενος εἴ πως ἤδη ποτὲ εὐοδωθήσομαι ἐν τῷ θελήματι τοῦ θεοῦ ἐλθεῖν πρὸς ὑμᾶς.
11 ἐπιποθῶ γὰρ ἰδεῖν ὑμᾶς, ἵνα τι μεταδῶ χάρισμα ὑμῖν πνευματικὸν εἰς τὸ στηριχθῆναι ὑμᾶς,
12 τοῦτο δέ ἐστιν συμπαρακληθῆναι ἐν ὑμῖν διὰ τῆς ἐν ἀλλήλοις πίστεως ὑμῶν τε καὶ ἐμοῦ.
13 οὐ θέλω δὲ ὑμᾶς ἀγνοεῖν, ἀδελφοί, ὅτι πολλάκις προεθέμην ἐλθεῖν πρὸς ὑμᾶς, καὶ ἐκωλύθην ἄχρι τοῦ δεῦρο, ἵνα τινὰ καρπὸν σχῶ καὶ ἐν ὑμῖν καθὼς καὶ ἐν τοῖς λοιποῖς ἔθνεσιν.
14 Ἕλλησίν τε καὶ βαρβάροις, σοφοῖς τε καὶ ἀνοήτοις ὀφειλέτης εἰμί·
15 οὕτως τὸ κατ᾽ ἐμὲ πρόθυμον καὶ ὑμῖν τοῖς ἐν Ῥώμῃ εὐαγγελίσασθαι.
16 οὐ γὰρ ἐπαισχύνομαι τὸ εὐαγγέλιον· δύναμις γὰρ θεοῦ ἐστιν εἰς σωτηρίαν παντὶ τῷ πιστεύοντι, Ἰουδαίῳ τε πρῶτον καὶ Ἕλληνι.
17 δικαιοσύνη γὰρ θεοῦ ἐν αὐτῷ ἀποκαλύπτεται ἐκ πίστεως εἰς πίστιν, καθὼς γέγραπται· ὁ δὲ δίκαιος ἐκ πίστεως ζήσεται.`,
    strongsNumbers: ["G1401", "G5547", "G2424", "G2822", "G652", "G873", "G2098", "G2316"],
    references: ["Habakkuk 2:4", "Isaiah 52:7", "Psalm 98:2", "Genesis 12:3", "2 Timothy 1:11"]
  }
};

// Add chapters 2-16 with representative text for development
for (let i = 2; i <= 16; i++) {
  greekRomansText[i] = {
    title: `Πρὸς Ῥωμαίους Κεφάλαιον ${getGreekNumeral(i)}`,
    text: `[Κεφάλαιον ${i} - Greek text would be loaded here]

1 [Πρώτος στίχος του Ρωμαίους ${i}...]
2 [Δεύτερος στίχος του Ρωμαίους ${i}...]
3 [Τρίτος στίχος του Ρωμαίους ${i}...]

Σημείωση: Σε μια παραγωγική εφαρμογή, αυτό θα περιείχε το πλήρες κείμενο του Ρωμαίους κεφάλαιο ${i} από το Textus Receptus. Το κείμενο έχει συντομευθεί εδώ για αναπτυξιακούς σκοπούς.`,
    strongsNumbers: [`G${1000 + i}`, `G${2000 + i}`, `G${3000 + i}`],
    references: [`Isaiah 1:${i}`, `Psalm ${i}0:1`, `Matthew 5:${i}`]
  };
}

function getGreekNumeral(num: number): string {
  const numerals: Record<number, string> = {
    1: 'Αʹ', 2: 'Βʹ', 3: 'Γʹ', 4: 'Δʹ', 5: 'Εʹ', 6: 'Ϛʹ', 7: 'Ζʹ', 8: 'Ηʹ',
    9: 'Θʹ', 10: 'Ιʹ', 11: 'ΙΑʹ', 12: 'ΙΒʹ', 13: 'ΙΓʹ', 14: 'ΙΔʹ', 15: 'ΙΕʹ', 16: 'ΙϚʹ'
  };
  return numerals[num] || `${num}`;
}

export function GreekText({ chapter, onChapterChange }: GreekTextProps) {
  const [showCrossReferences, setShowCrossReferences] = useState(false);
  const chapterData = greekRomansText[chapter] || greekRomansText[1];
  const hasStrongsNumbers = chapterData.strongsNumbers && chapterData.strongsNumbers.length > 0;
  const hasReferences = chapterData.references && chapterData.references.length > 0;

  const handlePrevious = () => {
    if (chapter > 1 && onChapterChange) {
      onChapterChange(chapter - 1);
    }
  };

  const handleNext = () => {
    if (chapter < 16 && onChapterChange) {
      onChapterChange(chapter + 1);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Header Section */}
      <div className="space-y-4">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100">
            {chapterData.title}
          </h1>
        </div>
        <div className="h-px bg-gray-200 dark:bg-gray-700"></div>
      </div>

      {/* Text-to-Speech Player */}
      <TextToSpeech 
        text={chapterData.text}
        title={`Romans ${chapter} (Koine Greek)`}
      />

      {/* Greek Text Content */}
      <div className="prose dark:prose-invert max-w-none">
        <div 
          className="whitespace-pre-line leading-relaxed text-base text-gray-800 dark:text-gray-200 greek-font"
          style={{ 
            fontFamily: '"SBL Greek", "Times New Roman", serif',
            fontSize: '1.1rem',
            lineHeight: '1.8'
          }}
        >
          {chapterData.text}
        </div>
      </div>

      {/* Strong's Numbers Section */}
      {hasStrongsNumbers && (
        <div className="bg-green-50 dark:bg-green-950/20 border border-green-200 dark:border-green-800 rounded-lg p-4">
          <h3 className="text-sm font-medium text-green-800 dark:text-green-200 mb-3">
            Strong's Concordance Numbers
          </h3>
          <div className="flex flex-wrap gap-2">
            {chapterData.strongsNumbers.map((strong, index) => (
              <Button
                key={index}
                variant="outline"
                size="sm"
                className="text-xs bg-white dark:bg-green-900/50 border-green-300 dark:border-green-700 text-green-700 dark:text-green-300 hover:bg-green-100 dark:hover:bg-green-900/70"
              >
                {strong}
              </Button>
            ))}
          </div>
        </div>
      )}

      {/* Cross References Section */}
      {hasReferences && (
        <div className="bg-purple-50 dark:bg-purple-950/20 border border-purple-200 dark:border-purple-800 rounded-lg p-4">
          <h3 className="text-sm font-medium text-purple-800 dark:text-purple-200 mb-3">
            Old Testament Echoes & References
          </h3>
          <div className="flex flex-wrap gap-2">
            {chapterData.references.map((ref, index) => (
              <Button
                key={index}
                variant="outline"
                size="sm"
                className="text-xs bg-white dark:bg-purple-900/50 border-purple-300 dark:border-purple-700 text-purple-700 dark:text-purple-300 hover:bg-purple-100 dark:hover:bg-purple-900/70"
              >
                {ref}
              </Button>
            ))}
          </div>
        </div>
      )}

      {/* Bible Study Tools */}
      <div className="flex justify-center gap-3 pt-6 flex-wrap">
        {hasStrongsNumbers && (
          <Button variant="outline" size="sm" className="text-xs">
            <BookOpen className="h-3 w-3 mr-1" />
            Strong's Numbers
          </Button>
        )}
        {hasReferences && (
          <Button 
            variant="outline" 
            size="sm" 
            className="text-xs"
            onClick={() => setShowCrossReferences(!showCrossReferences)}
          >
            <ExternalLink className="h-3 w-3 mr-1" />
            Cross References
          </Button>
        )}
        <Button 
          variant="outline" 
          size="sm" 
          className="text-xs"
          onClick={() => setShowCrossReferences(!showCrossReferences)}
        >
          <Search className="h-3 w-3 mr-1" />
          Biblical Connections
        </Button>
      </div>

      {/* Navigation Buttons */}
      <div className="flex justify-between items-center pt-8">
        <Button
          variant="outline"
          size="sm"
          onClick={handlePrevious}
          disabled={chapter <= 1}
          className="flex items-center gap-2"
        >
          <ChevronLeft className="h-4 w-4" />
          Προηγούμενο
        </Button>

        <div className="text-sm text-gray-500 dark:text-gray-400">
          Κεφάλαιον {chapter} από 16
        </div>

        <Button
          variant="outline"
          size="sm"
          onClick={handleNext}
          disabled={chapter >= 16}
          className="flex items-center gap-2"
        >
          Επόμενο
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>

      {/* Cross References Component */}
      {showCrossReferences && (
        <CrossReferences 
          chapter={chapter} 
          onNavigate={(newChapter) => {
            if (onChapterChange) {
              onChapterChange(newChapter);
            }
          }}
        />
      )}

      <div className="text-xs text-gray-500 dark:text-gray-400 text-center pt-4 border-t border-gray-200 dark:border-gray-700">
        Koine Greek Text - Textus Receptus (Public Domain)
      </div>
    </div>
  );
}