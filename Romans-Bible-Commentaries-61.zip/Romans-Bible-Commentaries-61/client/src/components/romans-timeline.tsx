import { useState } from "react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ExternalLink, Calendar, Book, User, Scroll } from "lucide-react";

interface TimelineEvent {
  date: number;
  title: string;
  type: 'biblical' | 'commentator' | 'historical' | 'biblical-echo';
  description?: string;
  ideas?: string[];
  link?: string;
  period?: 'pre-christ' | 'post-christ';
  thumbnail?: string;
}

// Biblical timeline events from Abraham to destruction of temple
const biblicalEvents: TimelineEvent[] = [
  { date: -2000, title: "Abraham Called", type: 'biblical', description: "God calls Abraham and establishes covenant", period: 'pre-christ' },
  { date: -1500, title: "Exodus", type: 'biblical', description: "Moses leads Israel out of Egypt", period: 'pre-christ' },
  { date: -1445, title: "Hab. 2:4", type: 'biblical-echo', description: "The righteous shall live by faith (quoted in Rom 1:17)", period: 'pre-christ' },
  { date: -1000, title: "King David", type: 'biblical', description: "David becomes king, Psalms written", period: 'pre-christ' },
  { date: -950, title: "Ps. 14:1-3", type: 'biblical-echo', description: "None righteous, not even one (quoted in Rom 3:10-12)", period: 'pre-christ' },
  { date: -740, title: "Is. 52:5", type: 'biblical-echo', description: "God's name blasphemed among nations (quoted in Rom 2:24)", period: 'pre-christ' },
  { date: -620, title: "Jer. 31:33", type: 'biblical-echo', description: "Law written on hearts (alluded to in Rom 2:15)", period: 'pre-christ' },
  { date: -586, title: "Babylonian Exile", type: 'biblical', description: "Jerusalem destroyed, exile begins", period: 'pre-christ' },
  { date: -538, title: "Return from Exile", type: 'biblical', description: "Jews return from Babylonian captivity", period: 'pre-christ' },
  { date: -5, title: "Birth of Jesus", type: 'biblical', description: "The Messiah is born", period: 'pre-christ' },
  { date: 30, title: "Crucifixion & Resurrection", type: 'biblical', description: "Jesus' death and resurrection", period: 'post-christ' },
  { date: 33, title: "Paul's Conversion", type: 'biblical', description: "Saul becomes Paul on Damascus road", period: 'post-christ' },
  { date: 57, title: "Romans Written", type: 'biblical', description: "Paul writes the Epistle to the Romans", period: 'post-christ' },
  { date: 70, title: "Temple Destroyed", type: 'biblical', description: "Jerusalem temple destroyed by Romans", period: 'post-christ' },
];

// Romans commentators with their dates and key contributions
const commentatorEvents: TimelineEvent[] = [
  { 
    date: 180, 
    title: "Irenaeus", 
    type: 'commentator', 
    description: "Against Heresies (references to Romans)",
    ideas: ["Early trinitarian theology", "Romans as foundation against Gnosticism"],
    link: "https://en.wikipedia.org/wiki/Irenaeus",
    period: 'post-christ',
    thumbnail: "https://upload.wikimedia.org/wikipedia/commons/thumb/3/32/Saint_Irenaeus_icon.jpg/160px-Saint_Irenaeus_icon.jpg"
  },
  { 
    date: 254, 
    title: "Origen", 
    type: 'commentator', 
    description: "Commentary on Romans (fragments survive)",
    ideas: ["Allegorical interpretation", "Universal restoration themes"],
    link: "https://en.wikipedia.org/wiki/Origen",
    period: 'post-christ'
  },
  { 
    date: 377, 
    title: "Ambrosiaster", 
    type: 'commentator', 
    description: "Commentary on Paul's Epistles",
    ideas: ["Western interpretation of justification", "Original sin theology"],
    link: "https://en.wikipedia.org/wiki/Ambrosiaster",
    period: 'post-christ'
  },
  { 
    date: 391, 
    title: "John Chrysostom", 
    type: 'commentator', 
    description: "Homilies on Romans",
    ideas: ["Practical Christian living", "Moral transformation through grace"],
    link: "https://en.wikipedia.org/wiki/John_Chrysostom",
    period: 'post-christ',
    thumbnail: "https://upload.wikimedia.org/wikipedia/commons/thumb/c/cf/Johnchrysostom.jpg/160px-Johnchrysostom.jpg"
  },
  { 
    date: 396, 
    title: "Augustine", 
    type: 'commentator', 
    description: "Propositions from the Epistle to the Romans",
    ideas: ["Predestination doctrine", "Grace vs. works emphasis"],
    link: "https://en.wikipedia.org/wiki/Augustine_of_Hippo",
    period: 'post-christ'
  },
  { 
    date: 1270, 
    title: "Thomas Aquinas", 
    type: 'commentator', 
    description: "Commentary on Romans (Lectura super Epistolam)",
    ideas: ["Scholastic synthesis", "Faith and reason integration"],
    link: "https://en.wikipedia.org/wiki/Thomas_Aquinas",
    period: 'post-christ'
  },
  { 
    date: 1515, 
    title: "Martin Luther", 
    type: 'commentator', 
    description: "Lectures on Romans (1515-1516)",
    ideas: ["Justification by faith alone (sola fide)", "Righteousness of God as gift, not demand"],
    link: "https://en.wikipedia.org/wiki/Martin_Luther",
    period: 'post-christ',
    thumbnail: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d8/Lucas_Cranach_d.%C3%84._-_Portr%C3%A4t_des_Martin_Luther%2C_1525_%28Bristol%29.jpg/160px-Lucas_Cranach_d.%C3%84._-_Portr%C3%A4t_des_Martin_Luther%2C_1525_%28Bristol%29.jpg"
  },
  { 
    date: 1540, 
    title: "John Calvin", 
    type: 'commentator', 
    description: "Commentary on Romans",
    ideas: ["God's sovereignty in salvation", "Clear exposition of justification"],
    link: "https://en.wikipedia.org/wiki/John_Calvin",
    period: 'post-christ'
  },
  { 
    date: 1933, 
    title: "Karl Barth", 
    type: 'commentator', 
    description: "The Epistle to the Romans",
    ideas: ["God's transcendence", "Infinite qualitative difference between God and humanity"],
    link: "https://en.wikipedia.org/wiki/Karl_Barth",
    period: 'post-christ',
    thumbnail: "https://upload.wikimedia.org/wikipedia/commons/thumb/b/bf/Karl_Barth_Bundesarchiv_Bild.png/160px-Karl_Barth_Bundesarchiv_Bild.png"
  },
  { 
    date: 1977, 
    title: "E.P. Sanders", 
    type: 'commentator', 
    description: "Paul and Palestinian Judaism",
    ideas: ["New Perspective on Paul", "Covenantal nomism in Second Temple Judaism"],
    link: "https://en.wikipedia.org/wiki/E.P._Sanders",
    period: 'post-christ',
    thumbnail: "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYwIiBoZWlnaHQ9IjE2MCIgdmlld0JveD0iMCAwIDE2MCAxNjAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSIxNjAiIGhlaWdodD0iMTYwIiBmaWxsPSIjZjNmNGY2Ii8+CjxjaXJjbGUgY3g9IjgwIiBjeT0iNjUiIHI9IjI1IiBmaWxsPSIjNjM2NmYxIi8+CjxwYXRoIGQ9Ik00MCAx MzBjMC0yMi4wOTEgMTcuOTA5LTQwIDQwLTQwczQwIDE3LjkwOSA0MCA0MHYzMEg0MHYtMzB6IiBmaWxsPSIjNjM2NmYxIi8+Cjx0ZXh0IHg9IjgwIiB5PSIxNDUiIHRleHQtYW5jaG9yPSJtaWRkbGUiIGZvbnQtZmFtaWx5PSJBcmlhbCIgZm9udC1zaXplPSIxMiIgZmlsbD0iIzM3NDE1MSI+RS5QLiBTYW5kZXJzPC90ZXh0Pgo8L3N2Zz4="
  },
  { 
    date: 1980, 
    title: "Ernst Käsemann", 
    type: 'commentator', 
    description: "Commentary on Romans",
    ideas: ["Apocalyptic theology", "Justification as God's saving power"],
    link: "https://en.wikipedia.org/wiki/Ernst_K%C3%A4semann",
    period: 'post-christ'
  },
  { 
    date: 1988, 
    title: "James D.G. Dunn", 
    type: 'commentator', 
    description: "Romans (Word Biblical Commentary)",
    ideas: ["New Perspective on Paul", "Works of the law as boundary markers"],
    link: "https://en.wikipedia.org/wiki/James_Dunn_(theologian)",
    period: 'post-christ'
  },
  { 
    date: 1991, 
    title: "Joseph A. Fitzmyer", 
    type: 'commentator', 
    description: "Romans (Anchor Bible)",
    ideas: ["Historical-critical method", "Jewish context of Paul's theology"],
    link: "https://en.wikipedia.org/wiki/Joseph_Fitzmyer",
    period: 'post-christ'
  },
  { 
    date: 2002, 
    title: "N.T. Wright", 
    type: 'commentator', 
    description: "Romans (New Interpreter's Bible)",
    ideas: ["Dikaiosune theou (righteousness of God)", "Faith/faithfulness of Jesus Christ"],
    link: "https://en.wikipedia.org/wiki/N._T._Wright",
    period: 'post-christ',
    thumbnail: "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3d/NTWright071220.jpg/160px-NTWright071220.jpg"
  },
  { 
    date: 2004, 
    title: "Robert Jewett", 
    type: 'commentator', 
    description: "Romans (Hermeneia)",
    ideas: ["Social context of Romans", "Honor-shame dynamics"],
    link: "https://en.wikipedia.org/wiki/Robert_Jewett",
    period: 'post-christ'
  },
  { 
    date: 1865, 
    title: "Theophan the Recluse", 
    type: 'commentator', 
    description: "Commentary on Romans (Orthodox perspective)",
    ideas: ["Eastern Orthodox spirituality", "Theosis and spiritual transformation"],
    link: "https://en.wikipedia.org/wiki/Theophan_the_Recluse",
    period: 'post-christ'
  },
  { 
    date: 1886, 
    title: "Charles Hodge", 
    type: 'commentator', 
    description: "Commentary on the Epistle to the Romans",
    ideas: ["Reformed orthodoxy", "Systematic approach to Paul's theology"],
    link: "https://en.wikipedia.org/wiki/Charles_Hodge",
    period: 'post-christ'
  },
  { 
    date: 1890, 
    title: "Frédéric Godet", 
    type: 'commentator', 
    description: "Commentary on Romans",
    ideas: ["Evangelical scholarship", "Detailed exegetical analysis"],
    link: "https://en.wikipedia.org/wiki/Fr%C3%A9d%C3%A9ric_Godet",
    period: 'post-christ'
  },
  { 
    date: 1996, 
    title: "Douglas Moo", 
    type: 'commentator', 
    description: "The Epistle to the Romans (NICNT)",
    ideas: ["Evangelical critical scholarship", "Balance of exegesis and theology"],
    link: "https://en.wikipedia.org/wiki/Douglas_J._Moo",
    period: 'post-christ'
  },
  { 
    date: 1998, 
    title: "Thomas Schreiner", 
    type: 'commentator', 
    description: "Romans (Baker Exegetical Commentary)",
    ideas: ["Reformed Baptist perspective", "Paul's theology of salvation"],
    link: "https://en.wikipedia.org/wiki/Thomas_Schreiner",
    period: 'post-christ'
  },
  { 
    date: 2007, 
    title: "Ben Witherington III", 
    type: 'commentator', 
    description: "Paul's Letter to the Romans",
    ideas: ["Socio-rhetorical analysis", "Paul's rhetoric and argumentation"],
    link: "https://en.wikipedia.org/wiki/Ben_Witherington_III",
    period: 'post-christ'
  },
  { 
    date: 2009, 
    title: "Beverly Roberts Gaventa", 
    type: 'commentator', 
    description: "Romans (Interpretation Commentary)",
    ideas: ["Apocalyptic reading of Paul", "God's righteousness as cosmic transformation"],
    link: "https://en.wikipedia.org/wiki/Beverly_Roberts_Gaventa",
    period: 'post-christ'
  },
  { 
    date: 2013, 
    title: "Sarah Coakley", 
    type: 'commentator', 
    description: "God, Sexuality and the Self (Romans 8)",
    ideas: ["Trinitarian theology", "Spiritual desire and Romans 8 groaning"],
    link: "https://en.wikipedia.org/wiki/Sarah_Coakley",
    period: 'post-christ'
  },
  { 
    date: 2016, 
    title: "Michael Bird", 
    type: 'commentator', 
    description: "Romans (The Story of God Bible Commentary)",
    ideas: ["Narrative approach to Paul", "Gospel as God's saving story"],
    link: "https://en.wikipedia.org/wiki/Michael_F._Bird",
    period: 'post-christ'
  },
  { 
    date: 2015, 
    title: "John Barclay", 
    type: 'commentator', 
    description: "Paul and the Gift",
    ideas: ["Gift theory and grace", "Reciprocity in ancient Mediterranean culture"],
    link: "https://en.wikipedia.org/wiki/John_M._G._Barclay",
    period: 'post-christ',
    thumbnail: "https://apps.dur.ac.uk/biography/image/4430"
  },
  { 
    date: 2019, 
    title: "Scot McKnight", 
    type: 'commentator', 
    description: "Reading Romans Backwards",
    ideas: ["Ecclesiological reading", "Romans as church unity manifesto"],
    link: "https://en.wikipedia.org/wiki/Scot_McKnight",
    period: 'post-christ'
  }
];

// Historical marker events
const historicalEvents: TimelineEvent[] = [
  { date: 476, title: "Fall of Western Roman Empire", type: 'historical', period: 'post-christ' },
  { date: 1054, title: "Great Schism", type: 'historical', period: 'post-christ' },
  { date: 1517, title: "Protestant Reformation", type: 'historical', period: 'post-christ' },
  { date: 1859, title: "Darwin's Origin of Species", type: 'historical', period: 'post-christ' },
  { date: 1945, title: "End of World War II", type: 'historical', period: 'post-christ' },
  { date: 2025, title: "Present Day", type: 'historical', period: 'post-christ' }
];

// Combine and sort all events
const allEvents = [...biblicalEvents, ...commentatorEvents, ...historicalEvents].sort((a, b) => a.date - b.date);

export function RomansTimeline() {
  const [selectedPeriod, setSelectedPeriod] = useState<'all' | 'pre-christ' | 'post-christ'>('all');
  const [selectedType, setSelectedType] = useState<'all' | 'biblical' | 'commentator' | 'historical' | 'biblical-echo'>('all');

  const filteredEvents = allEvents.filter(event => {
    const periodMatch = selectedPeriod === 'all' || event.period === selectedPeriod;
    const typeMatch = selectedType === 'all' || event.type === selectedType;
    return periodMatch && typeMatch;
  });

  const formatDate = (date: number) => {
    if (date < 0) {
      return `${Math.abs(date)} BC`;
    }
    return `${date} AD`;
  };



  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-2">
            Romans Timeline
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mb-4 text-sm">
            From Abraham to Present: Biblical Events, Echoes of Scripture, and Romans Commentators
          </p>

          {/* Filters */}
          <div className="space-y-3 mb-4">
            <div className="flex flex-wrap gap-2">
              <Button
                variant={selectedPeriod === 'all' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedPeriod('all')}
                className="h-8 px-3 text-xs"
              >
                All Periods
              </Button>
              <Button
                variant={selectedPeriod === 'pre-christ' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedPeriod('pre-christ')}
                className="h-8 px-3 text-xs"
              >
                Before Christ
              </Button>
              <Button
                variant={selectedPeriod === 'post-christ' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedPeriod('post-christ')}
                className="h-8 px-3 text-xs"
              >
                After Christ
              </Button>
            </div>

            <div className="flex flex-wrap gap-2">
              <Button
                variant={selectedType === 'all' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedType('all')}
                className="h-8 px-3 text-xs"
              >
                All Types
              </Button>
              <Button
                variant={selectedType === 'biblical' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedType('biblical')}
                className="h-8 px-3 text-xs"
              >
                <Book className="h-3 w-3 mr-1 flex-shrink-0" />
                Biblical
              </Button>
              <Button
                variant={selectedType === 'biblical-echo' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedType('biblical-echo')}
                className="h-8 px-3 text-xs"
              >
                <Scroll className="h-3 w-3 mr-1 flex-shrink-0" />
                Echoes
              </Button>
              <Button
                variant={selectedType === 'commentator' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedType('commentator')}
                className="h-8 px-3 text-xs"
              >
                <User className="h-3 w-3 mr-1 flex-shrink-0" />
                Scholars
              </Button>
              <Button
                variant={selectedType === 'historical' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedType('historical')}
                className="h-8 px-3 text-xs"
              >
                <Calendar className="h-3 w-3 mr-1 flex-shrink-0" />
                History
              </Button>
            </div>
          </div>

          {/* Legend */}
          <div className="flex flex-wrap gap-4 text-xs text-gray-500 dark:text-gray-400 mb-4">
            <div className="flex items-center gap-1">
              <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
              <span>Biblical Events</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-2 h-2 bg-purple-400 rounded-full"></div>
              <span>Scripture Echoes</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-2 h-2 bg-green-400 rounded-full"></div>
              <span>Commentators</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
              <span>Historical Context</span>
            </div>
          </div>
        </div>

        {/* Timeline */}
        <ScrollArea className="h-[calc(100vh-200px)]">
          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-6 top-0 bottom-0 w-px bg-gray-300 dark:bg-gray-600"></div>

            {/* Events */}
            <div className="space-y-4">
              {filteredEvents.map((event, index) => (
                <div key={index} className="relative flex items-start gap-4">
                  {/* Timeline dot */}
                  <div className="relative z-10 flex items-center justify-center">
                    <div className={`w-3 h-3 rounded-full border-2 border-white dark:border-gray-900 ${
                      event.type === 'biblical' ? 'bg-blue-400' :
                      event.type === 'biblical-echo' ? 'bg-purple-400' :
                      event.type === 'commentator' ? 'bg-green-400' : 'bg-gray-400'
                    }`}>
                    </div>
                  </div>

                  {/* Event content */}
                  <div className="flex-1 min-w-0 pb-2">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-semibold text-gray-900 dark:text-gray-100 text-sm">
                            {event.title}
                          </h3>
                          <span className="text-xs text-gray-500 dark:text-gray-400 font-medium">
                            {formatDate(event.date)}
                          </span>
                          {event.link && (
                            <a href={event.link} target="_blank" rel="noopener noreferrer" 
                               className="text-blue-500 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300">
                              <ExternalLink className="h-3 w-3" />
                            </a>
                          )}
                        </div>
                        
                        {event.description && (
                          <p className="text-gray-600 dark:text-gray-400 text-xs mb-1">
                            {event.description}
                          </p>
                        )}
                        
                        {event.ideas && event.ideas.length > 0 && (
                          <div className="text-xs">
                            <span className="text-gray-700 dark:text-gray-300 font-medium">Key ideas: </span>
                            <span className="text-gray-600 dark:text-gray-400">
                              {event.ideas.join(' • ')}
                            </span>
                          </div>
                        )}
                      </div>
                      
                      {/* Thumbnail for commentators */}
                      {event.type === 'commentator' && event.thumbnail && (
                        <div className="flex-shrink-0">
                          <img 
                            src={event.thumbnail} 
                            alt={`${event.title} portrait`}
                            className="w-16 h-16 rounded-lg object-cover border border-gray-200 dark:border-gray-600"
                          />
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </ScrollArea>
      </div>
    </div>
  );
}