import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Search, BookOpen, Hash, ExternalLink } from "lucide-react";

interface GreekTerm {
  id: string;
  greek: string;
  transliteration: string;
  strongsNumber: string;
  definition: string;
  etymology: string;
  usage: string;
  romansVerses: string[];
  category: 'theological' | 'soteriological' | 'anthropological' | 'christological' | 'pneumatological' | 'eschatological';
  relatedTerms: string[];
  scholar: string;
}

// Comprehensive Greek dictionary data based on BDAG, TDNT, and contemporary research
const greekTerms: GreekTerm[] = [
  {
    id: "dikaiosyne",
    greek: "δικαιοσύνη",
    transliteration: "dikaiosynē",
    strongsNumber: "G1343",
    definition: "BDAG: 'The quality or state of judicial correctness with focus on redemptive action, righteousness.' In Romans, primarily refers to God's covenant-fulfilling activity that puts things right rather than mere forensic declaration.",
    etymology: "From δίκαιος (dikaios, righteous) + σύνη (-synē, quality suffix). Root δικ- relates to custom, right order, justice in Greek legal and philosophical contexts.",
    usage: "Paul's revolutionary usage moves beyond Aristotelian distributive justice to covenantal faithfulness. God's righteousness is both His character and His saving activity (Rom 1:17, 3:21-22).",
    romansVerses: ["1:17", "3:5", "3:21-22", "3:25-26", "4:3", "4:5", "4:9", "4:11", "4:13", "6:13", "6:16", "6:18", "6:20", "8:10", "9:28", "9:30", "10:3-6", "10:10", "14:17"],
    category: 'theological',
    relatedTerms: ["dikaiosis", "dikaioma", "dikaios"],
    scholar: "Contemporary research (Wright, Bird, Gathercole) emphasizes covenantal over purely forensic meaning"
  },
  {
    id: "pistis",
    greek: "πίστις",
    transliteration: "pistis",
    strongsNumber: "G4102",
    definition: "BDAG: 'State of believing on the basis of reliability of the one trusted, faith, trust, confidence.' In Romans frequently denotes both human faith-response and divine faithfulness/reliability.",
    etymology: "From πείθω (peitho, to persuade, convince). Core meaning involves trust based on evidence of reliability rather than blind faith.",
    usage: "Paul employs pistis with remarkable flexibility: human faith (Rom 1:8), Christ's faithfulness (Rom 3:22, 26), and God's faithfulness (Rom 3:3). Contemporary debate centers on 'faith in Christ' vs 'faithfulness of Christ.'",
    romansVerses: ["1:5", "1:8", "1:12", "1:17", "3:3", "3:22", "3:25-28", "3:30-31", "4:5", "4:9", "4:11-16", "4:19-20", "5:1-2", "9:30", "9:32", "10:6", "10:8", "10:17", "11:20", "12:3", "12:6", "14:1", "14:22-23", "16:26"],
    category: 'soteriological',
    relatedTerms: ["pisteuo", "pistos"],
    scholar: "Richard Hays and others argue for 'faithfulness of Christ' reading in key passages"
  },
  {
    id: "hamartia",
    greek: "ἁμαρτία",
    transliteration: "hamartia",
    strongsNumber: "G266",
    definition: "BDAG: 'A departure from either human or divine standards of uprightness, sin.' In Romans, Paul personifies sin as a cosmic power/tyrant ruling over humanity until Christ's liberation.",
    etymology: "From ἁμαρτάνω (hamartano, to miss the mark). Originally an archery term meaning to miss the target, expanded to moral failure.",
    usage: "Paul's distinctive contribution is viewing sin not merely as individual acts but as a ruling power (Rom 6:12-14). Sin 'reigns' (βασιλεύω), 'dwells' (οἰκέω), and 'deceives' (ἐξαπατάω).",
    romansVerses: ["3:9", "3:20", "3:23", "4:7-8", "5:12-13", "5:20-21", "6:1-2", "6:6-7", "6:10-18", "6:20", "6:22-23", "7:7-25", "8:2-3", "8:10", "11:27", "14:23"],
    category: 'anthropological',
    relatedTerms: ["hamartano", "hamartema", "parabasis"],
    scholar: "Modern scholarship (Käsemann, Dunn) emphasizes sin as enslaving power rather than legal transgression"
  },
  {
    id: "nomos",
    greek: "νόμος",
    transliteration: "nomos",
    strongsNumber: "G3551",
    definition: "BDAG: 'A procedure or practice in conformity with formal or informal regulations, law, rule.' In Romans refers to Mosaic Law, natural law, and the 'law of faith' (Rom 3:27).",
    etymology: "From νέμω (nemo, to distribute, assign). Originally meant 'that which is assigned' or 'custom,' later specialized to written law.",
    usage: "Paul's complex treatment includes Torah's positive role (Rom 7:12), its inability to justify (Rom 3:20), and its role in revealing sin (Rom 7:7). Distinguished from 'law of faith' (Rom 3:27) and 'law of the Spirit' (Rom 8:2).",
    romansVerses: ["2:12-27", "3:19-21", "3:27-28", "3:31", "4:13-16", "5:13", "5:20", "6:14-15", "7:1-25", "8:2-4", "8:7", "9:31-32", "10:4-5", "13:8", "13:10"],
    category: 'theological',
    relatedTerms: ["paranomia", "anomia"],
    scholar: "E.P. Sanders' 'New Perspective' reframes Paul's view of law within Second Temple Judaism"
  },
  {
    id: "sarx",
    greek: "σάρξ",
    transliteration: "sarx",
    strongsNumber: "G4561",
    definition: "BDAG: 'The physical substance of animal bodies, flesh.' In Paul's anthropology, often denotes human nature in its weakness and opposition to God, not inherently evil but corrupted by sin.",
    etymology: "Basic meaning 'flesh' or 'meat.' Paul extends this to describe human nature under sin's dominion.",
    usage: "Not Greek dualism (flesh = evil), but Hebrew wholistic anthropology. Flesh represents humanity in its frailty and rebellion against God (Rom 7:18, 8:3-8). Contrasted with πνεῦμα (spirit).",
    romansVerses: ["1:3", "2:28", "3:20", "4:1", "6:19", "7:5", "7:18", "7:25", "8:3-9", "8:12-13", "9:3", "9:5", "9:8", "11:14", "13:14"],
    category: 'anthropological',
    relatedTerms: ["soma", "psyche", "pneuma"],
    scholar: "Rudolf Bultmann distinguished between σάρξ as substance and as sphere of existence"
  },
  {
    id: "pneuma",
    greek: "πνεῦμα",
    transliteration: "pneuma",
    strongsNumber: "G4151",
    definition: "BDAG: 'Air in movement, breath, wind' and by extension 'Spirit' as divine presence and power. In Romans, primarily the Holy Spirit who enables Christian living and assures believers of their status as God's children.",
    etymology: "From πνέω (pneo, to breathe, blow). Fundamental meaning is 'wind' or 'breath,' extended to invisible spiritual power.",
    usage: "Paul's pneumatology centers on the Spirit's role in justification, sanctification, and glorification. The Spirit bears witness (Rom 8:16), intercedes (Rom 8:26-27), and gives life (Rom 8:2, 8:11).",
    romansVerses: ["1:4", "2:29", "5:5", "7:6", "8:1-27", "8:2", "8:4-16", "8:23", "8:26-27", "9:1", "11:8", "12:11", "14:17", "15:13", "15:16", "15:19", "15:30"],
    category: 'pneumatological',
    relatedTerms: ["sarx", "psyche", "kardia"],
    scholar: "Gordon Fee's work emphasizes the Spirit as the 'already' of future resurrection life"
  },
  {
    id: "charis",
    greek: "χάρις",
    transliteration: "charis",
    strongsNumber: "G5485",
    definition: "BDAG: 'A beneficent disposition toward someone, favor, grace, gracious care/help.' In Romans, God's unmerited favor that justifies sinners and empowers Christian living.",
    etymology: "From χαίρω (chairo, to rejoice). Root meaning involves joy, delight, and favor freely given.",
    usage: "Paul's grace theology revolutionizes Greco-Roman reciprocity systems. Grace is not earned but freely given (Rom 11:6), abundant (Rom 5:20), and reigns through righteousness (Rom 5:21).",
    romansVerses: ["1:5", "1:7", "3:24", "4:4", "4:16", "5:2", "5:15", "5:17", "5:20-21", "6:1", "6:14-15", "11:5-6", "12:3", "12:6", "15:15", "16:20", "16:24"],
    category: 'soteriological',
    relatedTerms: ["charisma", "eucharistia"],
    scholar: "John Barclay's 'Paul and the Gift' reframes grace within ancient gift-exchange systems"
  },
  {
    id: "dikaiosis",
    greek: "δικαίωσις",
    transliteration: "dikaiosis",
    strongsNumber: "G1347",
    definition: "BDAG: 'The act of pronouncing righteous, justification, acquittal.' Technical legal term for the judicial verdict that declares one righteous. Appears only twice in Romans (4:25; 5:18).",
    etymology: "From δικαιόω (dikaioo, to justify) + σις (-sis, action suffix). Denotes the action or process of justification.",
    usage: "Distinguished from δικαίωμα (dikaioma) as the act versus the result. Contemporary debate focuses on whether this is forensic declaration or effective transformation.",
    romansVerses: ["4:25", "5:18"],
    category: 'soteriological',
    relatedTerms: ["dikaiosyne", "dikaioma", "dikaioo"],
    scholar: "Sebastian Schmidt distinguished dikaiosis (the act) from dikaioma (the result) in justification"
  },
  {
    id: "dikaioma",
    greek: "δικαίωμα",
    transliteration: "dikaioma",
    strongsNumber: "G1345",
    definition: "BDAG: 'Regulation, requirement, commandment' or 'righteous deed, act of righteousness.' Multivalent term requiring contextual interpretation in each occurrence.",
    etymology: "From δικαιόω (dikaioo, to justify). Can mean both the standard of righteousness and the act that meets that standard.",
    usage: "Paul uses dikaioma for divine requirements (Rom 1:32), righteous acts (Rom 5:18), and possibly justification itself (Rom 5:16). Context determines specific meaning.",
    romansVerses: ["1:32", "2:26", "5:16", "5:18", "8:4"],
    category: 'soteriological',
    relatedTerms: ["dikaiosyne", "dikaiosis", "entole"],
    scholar: "Contemporary exegesis emphasizes contextual flexibility of dikaioma terminology"
  },
  {
    id: "soteria",
    greek: "σωτηρία",
    transliteration: "soteria",
    strongsNumber: "G4991",
    definition: "BDAG: 'Deliverance, preservation, salvation.' In Romans encompasses past justification, present sanctification, and future glorification - the comprehensive restoration of God-human relationship.",
    etymology: "From σῶς (sos, safe, sound) + τηρία (-teria, state suffix). Originally meant physical safety, expanded to spiritual deliverance.",
    usage: "Paul's salvation is both 'already' (Rom 8:24, aorist) and 'not yet' (Rom 13:11, future). Includes deliverance from wrath (Rom 5:9), sin's power (Rom 6:22), and final glorification (Rom 8:30).",
    romansVerses: ["1:16", "5:9-10", "8:24", "10:1", "10:10", "11:11", "13:11"],
    category: 'soteriological',
    relatedTerms: ["soter", "sozo"],
    scholar: "Oscar Cullmann's 'already/not yet' framework clarifies Paul's salvation timeline"
  },
  {
    id: "katakrima",
    greek: "κατάκριμα",
    transliteration: "katakrima",
    strongsNumber: "G2631",
    definition: "BDAG: 'The punishment that follows condemnation, condemnation.' Legal term for the verdict and sentence of guilt. Contrasted with dikaiosis (justification) in Romans 5:16,18.",
    etymology: "From κατακρίνω (katakrino, to condemn) + μα (-ma, result suffix). Denotes both the verdict and its consequences.",
    usage: "Paul employs forensic imagery to contrast human condemnation under sin with divine justification through Christ. Key to understanding Romans 5:12-21 Adam-Christ parallel.",
    romansVerses: ["5:16", "5:18", "8:1"],
    category: 'anthropological',
    relatedTerms: ["krima", "katakrino", "krisis"],
    scholar: "Legal background illuminated by Greco-Roman judicial terminology studies"
  },
  {
    id: "hilasterion",
    greek: "ἱλαστήριον",
    transliteration: "hilasterion",
    strongsNumber: "G2435",
    definition: "BDAG: 'Means of expiation' or 'mercy seat.' Debated term in Rom 3:25 referring either to the ark's mercy seat or a general means of propitiation/expiation.",
    etymology: "From ἱλάσκομαι (hilaskomai, to propitiate, expiate). LXX uses for the golden cover of the ark of the covenant.",
    usage: "Critical for understanding Christ's atoning work. Scholarly debate between propitiation (turning away God's wrath) versus expiation (removing sin's effects).",
    romansVerses: ["3:25"],
    category: 'christological',
    relatedTerms: ["hilasmos", "katallage"],
    scholar: "C.H. Dodd argued for expiation; Leon Morris defended propitiation interpretation"
  },
  {
    id: "katallage",
    greek: "καταλλαγή",
    transliteration: "katallage",
    strongsNumber: "G2643",
    definition: "BDAG: 'Reconciliation' - the restoration of normal relations after estrangement. God's initiative in restoring the broken divine-human relationship through Christ.",
    etymology: "From καταλλάσσω (katallasso, to reconcile). Commercial background of settling accounts or restoring friendship.",
    usage: "Paul emphasizes God as the reconciling agent (Rom 5:10-11), not humanity initiating peace with God. Reconciliation precedes and enables human response.",
    romansVerses: ["5:11", "11:15"],
    category: 'christological',
    relatedTerms: ["katallasso", "diallasso"],
    scholar: "Ralph Martin's work established reconciliation as central Pauline metaphor alongside justification"
  },
  {
    id: "koinonia",
    greek: "κοινωνία",
    transliteration: "koinonia",
    strongsNumber: "G2842",
    definition: "BDAG: 'Close association involving mutual interests and sharing, participation, sharing, fellowship.' Christian community characterized by shared life in Christ.",
    etymology: "From κοινός (koinos, common, shared). Root meaning involves having things in common.",
    usage: "While less frequent in Romans than other Pauline letters, koinonia underlies Paul's corporate understanding of salvation and Christian identity.",
    romansVerses: ["15:26"],
    category: 'anthropological',
    relatedTerms: ["koinonos", "metecho"],
    scholar: "Heinrich Seesemann's TDNT article established koinonia's theological significance"
  },
  {
    id: "doxa",
    greek: "δόξα",
    transliteration: "doxa",
    strongsNumber: "G1391",
    definition: "BDAG: 'The condition of being bright or shining, brightness, splendor, radiance' and 'honor as enhancement or recognition of status, honor, esteem, glory.'",
    etymology: "From δοκέω (dokeo, to think, seem). Originally 'opinion' or 'reputation,' developed into 'glory' in religious contexts.",
    usage: "Paul uses doxa for human loss of God's glory (Rom 3:23), Christ's glory (Rom 6:4), and the believer's future glorification (Rom 8:18, 8:30). Central to his eschatological hope.",
    romansVerses: ["1:23", "2:7", "2:10", "3:7", "3:23", "4:20", "5:2", "6:4", "8:18", "8:21", "8:30", "9:4", "9:21", "9:23", "11:36", "15:7", "16:27"],
    category: 'eschatological',
    relatedTerms: ["doxazo", "endoxos"],
    scholar: "Gerhard Kittel's TDNT entry traces doxa from Greek philosophy to Christian theology"
  }
];

export function GreekDictionary() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [selectedTerm, setSelectedTerm] = useState<GreekTerm | null>(null);

  const categories = {
    all: "All Terms",
    theological: "Theological",
    soteriological: "Salvation",
    anthropological: "Human Nature", 
    christological: "Christ",
    pneumatological: "Holy Spirit",
    eschatological: "End Times"
  };

  const filteredTerms = greekTerms.filter(term => {
    const matchesCategory = selectedCategory === "all" || term.category === selectedCategory;
    const matchesSearch = searchQuery === "" || 
      term.greek.toLowerCase().includes(searchQuery.toLowerCase()) ||
      term.transliteration.toLowerCase().includes(searchQuery.toLowerCase()) ||
      term.strongsNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      term.definition.toLowerCase().includes(searchQuery.toLowerCase());
    
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Greek Terms Dictionary</h2>
        <p className="text-gray-600 mb-4">
          Comprehensive dictionary of key Greek terms in Romans with Strong's numbers, 
          BDAG definitions, and contemporary scholarship
        </p>
      </div>

      {/* Search and Filter */}
      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
            <div className="flex-1 max-w-md">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search Greek terms, Strong's numbers..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            
            <Tabs value={selectedCategory} onValueChange={setSelectedCategory} className="w-full sm:w-auto">
              <TabsList className="grid grid-cols-3 sm:grid-cols-7 w-full">
                {Object.entries(categories).map(([key, label]) => (
                  <TabsTrigger key={key} value={key} className="text-xs">
                    {label}
                  </TabsTrigger>
                ))}
              </TabsList>
            </Tabs>
          </div>
        </CardHeader>
      </Card>

      {/* Terms Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredTerms.map((term) => (
          <Card key={term.id} className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setSelectedTerm(term)}>
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div>
                  <div className="text-2xl font-bold text-blue-600 mb-1">{term.greek}</div>
                  <div className="text-sm text-gray-600 mb-1">{term.transliteration}</div>
                  <Badge variant="outline" className="text-xs">
                    <Hash className="h-3 w-3 mr-1" />
                    {term.strongsNumber}
                  </Badge>
                </div>
                <Badge variant="secondary" className="text-xs">
                  {categories[term.category as keyof typeof categories]}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <p className="text-sm text-gray-700 line-clamp-3 mb-3">
                {term.definition.split('.')[0]}...
              </p>
              <div className="flex flex-wrap gap-1 mb-2">
                {term.romansVerses.slice(0, 4).map((verse) => (
                  <Badge key={verse} variant="outline" className="text-xs">
                    Rom {verse}
                  </Badge>
                ))}
                {term.romansVerses.length > 4 && (
                  <Badge variant="outline" className="text-xs">
                    +{term.romansVerses.length - 4} more
                  </Badge>
                )}
              </div>
              <Button variant="ghost" size="sm" className="w-full text-blue-600 hover:text-blue-700">
                View Full Entry <ExternalLink className="h-3 w-3 ml-1" />
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Detailed View Modal */}
      {selectedTerm && (
        <Card className="fixed inset-4 z-50 bg-white shadow-2xl rounded-lg overflow-hidden">
          <CardHeader className="bg-gray-50 border-b">
            <div className="flex items-start justify-between">
              <div>
                <div className="text-3xl font-bold text-blue-600 mb-2">{selectedTerm.greek}</div>
                <div className="text-lg text-gray-700 mb-2">{selectedTerm.transliteration}</div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline">
                    <Hash className="h-3 w-3 mr-1" />
                    {selectedTerm.strongsNumber}
                  </Badge>
                  <Badge variant="secondary">
                    {categories[selectedTerm.category as keyof typeof categories]}
                  </Badge>
                </div>
              </div>
              <Button variant="ghost" size="sm" onClick={() => setSelectedTerm(null)}>
                ✕
              </Button>
            </div>
          </CardHeader>
          <ScrollArea className="h-[60vh]">
            <CardContent className="p-6 space-y-6">
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Definition</h3>
                <p className="text-gray-700">{selectedTerm.definition}</p>
              </div>
              
              <Separator />
              
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Etymology</h3>
                <p className="text-gray-700">{selectedTerm.etymology}</p>
              </div>
              
              <Separator />
              
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Usage in Romans</h3>
                <p className="text-gray-700">{selectedTerm.usage}</p>
              </div>
              
              <Separator />
              
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Romans References ({selectedTerm.romansVerses.length})</h3>
                <div className="flex flex-wrap gap-1">
                  {selectedTerm.romansVerses.map((verse) => (
                    <Badge key={verse} variant="outline" className="text-xs">
                      Romans {verse}
                    </Badge>
                  ))}
                </div>
              </div>
              
              <Separator />
              
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Related Terms</h3>
                <div className="flex flex-wrap gap-1">
                  {selectedTerm.relatedTerms.map((term) => (
                    <Badge key={term} variant="secondary" className="text-xs">
                      {term}
                    </Badge>
                  ))}
                </div>
              </div>
              
              <Separator />
              
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Contemporary Scholarship</h3>
                <p className="text-gray-700 italic">{selectedTerm.scholar}</p>
              </div>
            </CardContent>
          </ScrollArea>
        </Card>
      )}

      {/* Overlay */}
      {selectedTerm && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40"
          onClick={() => setSelectedTerm(null)}
        />
      )}
    </div>
  );
}