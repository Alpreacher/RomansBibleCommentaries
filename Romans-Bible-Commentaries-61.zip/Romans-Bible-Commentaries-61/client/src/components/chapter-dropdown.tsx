import { useState } from "react";
import { ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";

interface ChapterDropdownProps {
  selectedChapter: number;
  onChapterSelect: (chapter: number) => void;
}

export function ChapterDropdown({ selectedChapter, onChapterSelect }: ChapterDropdownProps) {
  const [isOpen, setIsOpen] = useState(false);
  const chapters = Array.from({ length: 16 }, (_, i) => i + 1);

  return (
    <div className="relative">
      <Button
        variant="outline"
        onClick={() => setIsOpen(!isOpen)}
        style={{ backgroundColor: 'white' }}
        className="flex items-center gap-2 min-w-[120px] justify-between border-gray-300"
      >
        <span>Chapter {selectedChapter}</span>
        <ChevronDown className={`h-4 w-4 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </Button>
      
      {isOpen && (
        <>
          {/* Backdrop */}
          <div 
            className="fixed inset-0 z-40"
            onClick={() => setIsOpen(false)}
          />
          
          {/* Dropdown */}
          <div className="absolute top-full left-0 mt-1 w-full bg-white border border-gray-200 rounded-md shadow-lg z-50 max-h-64 overflow-y-auto">
            <div className="p-2 grid grid-cols-4 gap-1">
              {chapters.map((chapter) => (
                <button
                  key={chapter}
                  className={`p-2 text-sm rounded hover:bg-gray-100 transition-colors ${
                    selectedChapter === chapter 
                      ? 'bg-blue-50 text-blue-700 font-medium' 
                      : 'text-gray-700'
                  }`}
                  onClick={() => {
                    onChapterSelect(chapter);
                    setIsOpen(false);
                  }}
                >
                  {chapter}
                </button>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}