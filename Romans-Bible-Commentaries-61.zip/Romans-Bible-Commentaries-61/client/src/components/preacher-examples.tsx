import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { BookOpen, Clock, Users, Lightbulb, Quote, ArrowRight } from "lucide-react";

interface SermonExample {
  id: string;
  title: string;
  text: string;
  outline: string[];
  illustration: string;
  application: string;
  style: 'spurgeon' | 'skeleton' | 'sketch';
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  duration: '15min' | '30min' | '45min';
  audience: 'general' | 'youth' | 'adults';
}

// Sermon examples in C.H. Spurgeon style and classic sermon skeleton format
const sermonExamples: Record<number, SermonExample[]> = {
  1: [
    {
      id: "rom1_1",
      title: "The Gospel - God's Dynamite for Salvation",
      text: "Romans 1:16-17",
      outline: [
        "I. THE GOSPEL'S POWER - 'I am not ashamed'",
        "   A. Not human philosophy, but divine dynamite",
        "   B. Not earthly wisdom, but heavenly power",
        "   C. Not man's invention, but God's intervention",
        "II. THE GOSPEL'S SCOPE - 'to everyone who believes'",
        "   A. To the Jew first - priority in privilege",
        "   B. To the Greek also - universality in grace",
        "   C. To all nations - catholicity in reach",
        "III. THE GOSPEL'S RIGHTEOUSNESS - 'from faith to faith'",
        "   A. Not works righteousness - by merit",
        "   B. Not ceremonial righteousness - by ritual", 
        "   C. But faith righteousness - by trust alone"
      ],
      illustration: "A man drowning cannot save himself by swimming harder; he needs a lifeguard's rope thrown to him. So the sinner cannot save himself by moral effort - he needs the Gospel's divine rescue.",
      application: "Are you trusting in your own goodness, or have you grasped the rope of God's grace? The Gospel is not a life preserver for the good swimmer, but a rescue line for the drowning soul.",
      style: 'spurgeon',
      difficulty: 'intermediate',
      duration: '30min',
      audience: 'general'
    },
    {
      id: "rom1_2", 
      title: "The Wrath of God Against Ungodliness",
      text: "Romans 1:18-23",
      outline: [
        "I. THE REVELATION OF WRATH (v.18)",
        "   A. From heaven - its source",
        "   B. Against ungodliness - its target", 
        "   C. Who suppress truth - its cause",
        "II. THE EVIDENCE OF GOD (v.19-20)",
        "   A. Made plain within them",
        "   B. Clearly seen in creation",
        "   C. Leaving men without excuse",
        "III. THE EXCHANGE OF GLORY (v.21-23)",
        "   A. They knew God but glorified Him not",
        "   B. Their foolish heart was darkened",
        "   C. They changed glory into images"
      ],
      illustration: "When a man deliberately closes his eyes to the sun, he cannot blame the sun for the darkness that follows. So when man turns from God's clear revelation, the darkness is his own doing.",
      application: "Have you suppressed the truth of God that He has shown you? The creation itself preaches - are you listening to its sermon?",
      style: 'skeleton',
      difficulty: 'advanced',
      duration: '45min',
      audience: 'adults'
    },
    {
      id: "rom1_3",
      title: "Paul - A Pattern for Christian Workers", 
      text: "Romans 1:1-7",
      outline: [
        "I. HIS CALLING - 'called to be an apostle' (v.1)",
        "II. HIS MESSAGE - 'the gospel of God' (v.1)",  
        "III. HIS MASTER - 'concerning his Son' (v.3)",
        "IV. HIS MISSION - 'to bring about obedience of faith' (v.5)",
        "V. HIS MANNER - 'grace and peace to you' (v.7)"
      ],
      illustration: "A true servant bears his master's seal. Paul bore the seal of divine calling - not self-appointed, but God-appointed to his sacred task.",
      application: "Every Christian is called to some service. What is your calling? Are you faithful to it as Paul was to his apostolic commission?",
      style: 'sketch',
      difficulty: 'beginner',
      duration: '15min',
      audience: 'general'
    }
  ],
  2: [
    {
      id: "rom2_1",
      title: "The Righteous Judgment of God",
      text: "Romans 2:1-11", 
      outline: [
        "I. THE UNIVERSALITY OF SIN (v.1-3)",
        "   A. The judger is also judged",
        "   B. Self-condemnation through judging others",
        "   C. No escape from God's judgment",
        "II. THE PATIENCE OF GOD (v.4-5)",
        "   A. His goodness leads to repentance",
        "   B. His forbearance is not indifference", 
        "   C. Hardness stores up wrath",
        "III. THE JUSTICE OF GOD (v.6-11)",
        "   A. According to deeds, not profession",
        "   B. No respect of persons with God",
        "   C. Jew and Gentile under same standard"
      ],
      illustration: "A judge who winks at crime in his own family while condemning it in others is unfit for the bench. How much more unfit are we to judge others when we practice the same sins!",
      application: "Before you point the finger of judgment at another, remember that three fingers point back at yourself. God's judgment begins with His own house.",
      style: 'spurgeon',
      difficulty: 'intermediate', 
      duration: '30min',
      audience: 'adults'
    },
    {
      id: "rom2_2",
      title: "The Law Written in the Heart",
      text: "Romans 2:12-16",
      outline: [
        "I. THE LAW'S UNIVERSALITY",
        "   A. Those without law judged without law", 
        "   B. Those under law judged by the law",
        "   C. All accountable to moral standard",
        "II. THE CONSCIENCE'S TESTIMONY", 
        "   A. The work of the law written in hearts",
        "   B. Conscience bearing witness",
        "   C. Thoughts accusing or defending",
        "III. THE JUDGMENT'S CERTAINTY",
        "   A. In that day when God judges",
        "   B. The secrets of men revealed", 
        "   C. Through Jesus Christ the standard"
      ],
      illustration: "Conscience is God's deputy in the soul, a magistrate appointed by Heaven to maintain order in the court of the heart.",
      application: "Your conscience is God's gift to guide you. Have you been heeding its voice, or have you seared it through repeated disobedience?",
      style: 'skeleton',
      difficulty: 'intermediate',
      duration: '30min', 
      audience: 'general'
    }
  ],
  3: [
    {
      id: "rom3_1",
      title: "The Law as an X-Ray Machine for Human Hearts",
      text: "Romans 3:9-20",
      outline: [
        "I. THE DIAGNOSIS - Universal Corruption (v.9-12)",
        "   A. 'All under sin' - the verdict",
        "   B. 'None righteous, no not one' - the scope", 
        "   C. 'All gone astray' - the direction",
        "II. THE DETAILS - Specific Symptoms (v.13-18)",
        "   A. The throat - 'an open sepulchre'",
        "   B. The tongue - 'used deceit'",
        "   C. The lips - 'poison of asps'",
        "   D. The mouth - 'full of cursing'",
        "   E. The feet - 'swift to shed blood'",
        "   F. The eyes - 'no fear of God'",
        "III. THE DECLARATION - Legal Condemnation (v.19-20)",
        "   A. Every mouth stopped before God",
        "   B. All the world guilty before God",
        "   C. No flesh justified by law-works"
      ],
      illustration: "An X-ray reveals what the eye cannot see - the hidden fractures, the concealed disease. So God's law penetrates the heart and reveals the spiritual sickness that lurks within the fairest exterior.",
      application: "Have you allowed God's law to X-ray your heart? What has it revealed? The law is not given to heal, but to reveal the need for the Great Physician.",
      style: 'spurgeon',
      difficulty: 'intermediate',
      duration: '30min',
      audience: 'adults'
    },
    {
      id: "rom3_2", 
      title: "But Now! - The Great Transition",
      text: "Romans 3:21-26",
      outline: [
        "I. THE CONTRAST - 'But now' (v.21a)",
        "   A. Apart from law works",
        "   B. A new way revealed",
        "   C. The great transition word",
        "II. THE CHARACTER - God's Righteousness (v.21b-22)",
        "   A. Witnessed by law and prophets", 
        "   B. Through faith in Jesus Christ",
        "   C. For all who believe",
        "III. THE CAUSE - Divine Propitiation (v.23-26)",
        "   A. All have sinned and lack glory",
        "   B. Justified freely by His grace",
        "   C. Through redemption in Christ Jesus"
      ],
      illustration: "When the night is darkest, men watch most eagerly for the dawn. 'But now' is the sunrise word that ends sin's long night and ushers in salvation's glorious day.",
      application: "In your spiritual life, have you moved from law to grace? From works to faith? From condemnation to justification? Christ is God's great 'But now!'",
      style: 'skeleton',
      difficulty: 'beginner',
      duration: '30min',
      audience: 'general'
    }
  ],
  4: [
    {
      id: "rom4_1",
      title: "Abraham - The Father of Faith",
      text: "Romans 4:16-25",
      outline: [
        "I. FAITH'S FOUNDATION - God's Promise (v.16-17)",
        "   A. By faith, not by works",
        "   B. By grace, not by merit", 
        "   C. Sure to all the seed",
        "II. FAITH'S CHARACTER - Against Hope Believing (v.18-19)",
        "   A. Believed in hope against hope",
        "   B. Considered not his own body",
        "   C. Staggered not at the promise",
        "III. FAITH'S REWARD - Righteousness Imputed (v.20-25)",
        "   A. Strong in faith, giving glory to God",
        "   B. Fully persuaded of God's power",
        "   C. Righteousness reckoned to him"
      ],
      illustration: "Faith is the empty hand that receives God's full gift. Abraham's hands were empty of merit but full of trust - and God filled them with righteousness.",
      application: "Are you trying to earn God's favor, or are you trusting His promise? Faith is not a work to be performed, but a gift to be received.",
      style: 'spurgeon', 
      difficulty: 'intermediate',
      duration: '30min',
      audience: 'general'
    }
  ],
  5: [
    {
      id: "rom5_1",
      title: "Peace with God - The Believer's Foundation",
      text: "Romans 5:1-5",
      outline: [
        "I. PEACE OBTAINED - 'We have peace' (v.1)",
        "   A. Through our Lord Jesus Christ",
        "   B. Not by works but by faith",
        "   C. A settled reconciliation",
        "II. ACCESS GAINED - 'We have access' (v.2a)",
        "   A. Into this grace wherein we stand", 
        "   B. By faith, not by merit",
        "   C. A permanent standing",
        "III. HOPE ASSURED - 'We rejoice in hope' (v.2b-5)",
        "   A. Hope of the glory of God",
        "   B. Glory even in tribulations",
        "   C. Hope maketh not ashamed"
      ],
      illustration: "A man at war with his king cannot sleep peacefully in his castle. But when peace is made, every benefit of citizenship becomes his. So with the soul at peace with God.",
      application: "Do you have peace with God, or are you still at war with Heaven? Christ has made peace by the blood of His cross - will you lay down your arms?",
      style: 'skeleton',
      difficulty: 'beginner', 
      duration: '30min',
      audience: 'general'
    }
  ],
  6: [
    {
      id: "rom6_1",
      title: "Dead to Sin, Alive to God",
      text: "Romans 6:1-11",
      outline: [
        "I. THE QUESTION - Shall we continue in sin? (v.1-2)",
        "   A. The antinomian error",
        "   B. The apostolic answer - 'God forbid!'",
        "   C. The logical impossibility",
        "II. THE UNION - Baptized into Christ's death (v.3-5)",
        "   A. Baptized into His death",
        "   B. Buried with Him in baptism", 
        "   C. Raised to newness of life",
        "III. THE RECKONING - Count yourselves dead (v.6-11)",
        "   A. Our old man crucified with Him",
        "   B. Dead indeed unto sin",
        "   C. Alive unto God through Christ"
      ],
      illustration: "A dead man does not respond to temptation's call, nor does he pursue sin's pleasures. If we are dead with Christ, we must live like dead men to sin.",
      application: "Have you reckoned yourself dead to sin? This is not just theological truth but practical reality for Christian living. Count it so!",
      style: 'spurgeon',
      difficulty: 'intermediate',
      duration: '30min', 
      audience: 'adults'
    }
  ],
  7: [
    {
      id: "rom7_1", 
      title: "The Wretched Man's Cry",
      text: "Romans 7:14-25",
      outline: [
        "I. THE CONFLICT DESCRIBED (v.14-20)",
        "   A. 'I am carnal, sold under sin'",
        "   B. 'That which I do I allow not'",
        "   C. 'It is no more I, but sin'",
        "II. THE LAW'S LIMITATION (v.21-23)",
        "   A. 'I find then a law'",
        "   B. 'The law of my mind'", 
        "   C. 'The law of sin in my members'",
        "III. THE DELIVERER'S NAME (v.24-25)",
        "   A. 'O wretched man that I am!'",
        "   B. 'Who shall deliver me?'",
        "   C. 'I thank God through Jesus Christ'"
      ],
      illustration: "A bird with a broken wing knows it should fly but cannot. So the awakened soul knows what it should do but finds itself powerless until Christ mends the wing.",
      application: "Have you cried the wretched man's cry? This is often the prelude to discovering Christ's delivering power. Despair of self leads to dependence on the Savior.",
      style: 'skeleton',
      difficulty: 'advanced',
      duration: '45min',
      audience: 'adults'
    }
  ],
  8: [
    {
      id: "rom8_1",
      title: "No Condemnation - The Believer's Magna Carta", 
      text: "Romans 8:1-4",
      outline: [
        "I. THE GREAT DECLARATION - 'No condemnation' (v.1)",
        "   A. None whatever - absolute acquittal",
        "   B. To them which are in Christ Jesus",
        "   C. The judge has pronounced 'Not guilty!'",
        "II. THE GREAT DELIVERANCE - 'Made me free' (v.2)",
        "   A. The law of the Spirit of life",
        "   B. In Christ Jesus hath made me free",
        "   C. From the law of sin and death",
        "III. THE GREAT ACCOMPLISHMENT - 'Fulfilled in us' (v.3-4)",
        "   A. What the law could not do",
        "   B. God sending His own Son",
        "   C. The righteousness of the law fulfilled"
      ],
      illustration: "When the king's pardon reaches the condemned prisoner, the jailer's key turns not to lock him in, but to let him out. 'No condemnation' is Heaven's key of liberty.",
      application: "Do you live in the freedom of 'no condemnation,' or are you still in the prison of self-accusation? Christ has set the captive free!",
      style: 'spurgeon',
      difficulty: 'beginner',
      duration: '30min',
      audience: 'general'
    }
  ]
};

interface PreacherExamplesProps {
  chapter: number;
}

export function PreacherExamples({ chapter }: PreacherExamplesProps) {
  const [selectedExample, setSelectedExample] = useState<SermonExample | null>(null);
  const [filterStyle, setFilterStyle] = useState<string>('all');

  const examples = sermonExamples[chapter] || [];
  
  const filteredExamples = examples.filter(example => 
    filterStyle === 'all' || example.style === filterStyle
  );

  const getStyleBadgeColor = (style: string) => {
    switch (style) {
      case 'spurgeon': return 'bg-purple-100 text-purple-800';
      case 'skeleton': return 'bg-blue-100 text-blue-800';
      case 'sketch': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'beginner': return 'text-green-600';
      case 'intermediate': return 'text-yellow-600'; 
      case 'advanced': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">
          Examples for Preachers - Romans Chapter {chapter}
        </h2>
        <p className="text-gray-600 mb-4">
          Sermon sketches and outlines in the classical tradition of C.H. Spurgeon and vintage homiletical guides
        </p>
      </div>

      {/* Filter Options */}
      <div className="flex flex-wrap gap-2 justify-center">
        <Button 
          variant={filterStyle === 'all' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setFilterStyle('all')}
        >
          All Styles
        </Button>
        <Button 
          variant={filterStyle === 'spurgeon' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setFilterStyle('spurgeon')}
        >
          Spurgeon Style
        </Button>
        <Button 
          variant={filterStyle === 'skeleton' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setFilterStyle('skeleton')}
        >
          Sermon Skeleton
        </Button>
        <Button 
          variant={filterStyle === 'sketch' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setFilterStyle('sketch')}
        >
          Sermon Sketch
        </Button>
      </div>

      {/* Examples Grid */}
      {filteredExamples.length === 0 ? (
        <Card className="text-center py-12">
          <CardContent>
            <BookOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              No Examples Available
            </h3>
            <p className="text-gray-600">
              Sermon examples for Romans chapter {chapter} are coming soon. 
              Check back later for preaching resources.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredExamples.map((example) => (
            <Card key={example.id} className="cursor-pointer hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between mb-2">
                  <Badge className={getStyleBadgeColor(example.style)}>
                    {example.style === 'spurgeon' ? 'Spurgeon Style' : 
                     example.style === 'skeleton' ? 'Skeleton' : 'Sketch'}
                  </Badge>
                  <div className="flex items-center gap-1 text-sm text-gray-500">
                    <Clock className="h-3 w-3" />
                    {example.duration}
                  </div>
                </div>
                <CardTitle className="text-lg leading-tight mb-2">
                  {example.title}
                </CardTitle>
                <Badge variant="outline" className="text-sm font-mono">
                  {example.text}
                </Badge>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="text-sm">
                    <span className={`font-medium ${getDifficultyColor(example.difficulty)}`}>
                      {example.difficulty.charAt(0).toUpperCase() + example.difficulty.slice(1)}
                    </span>
                    <span className="text-gray-400 mx-2">•</span>
                    <span className="text-gray-600">{example.audience}</span>
                  </div>
                  
                  <div className="text-sm text-gray-700">
                    <div className="font-medium mb-1">Main Points:</div>
                    <ul className="list-disc list-inside space-y-1">
                      {example.outline.slice(0, 3).map((point, index) => (
                        <li key={index} className="text-xs leading-relaxed">
                          {point.split(' - ')[0]}
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="w-full"
                    onClick={() => setSelectedExample(example)}
                  >
                    View Full Outline
                    <ArrowRight className="h-3 w-3 ml-1" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Detailed View Modal */}
      {selectedExample && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="fixed inset-0 bg-black bg-opacity-50" onClick={() => setSelectedExample(null)} />
          <Card className="relative max-w-4xl w-full max-h-[90vh] bg-white">
            <CardHeader className="border-b">
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-xl mb-2">{selectedExample.title}</CardTitle>
                  <div className="flex items-center gap-2 mb-2">
                    <Badge variant="outline" className="font-mono">{selectedExample.text}</Badge>
                    <Badge className={getStyleBadgeColor(selectedExample.style)}>
                      {selectedExample.style === 'spurgeon' ? 'Spurgeon Style' : 
                       selectedExample.style === 'skeleton' ? 'Skeleton' : 'Sketch'}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-4 text-sm text-gray-600">
                    <div className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {selectedExample.duration}
                    </div>
                    <div className="flex items-center gap-1">
                      <Users className="h-3 w-3" />
                      {selectedExample.audience}
                    </div>
                    <div className={`font-medium ${getDifficultyColor(selectedExample.difficulty)}`}>
                      {selectedExample.difficulty}
                    </div>
                  </div>
                </div>
                <Button variant="ghost" size="sm" onClick={() => setSelectedExample(null)}>
                  ✕
                </Button>
              </div>
            </CardHeader>
            <ScrollArea className="h-[60vh]">
              <CardContent className="p-6 space-y-6">
                <div>
                  <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                    <BookOpen className="h-4 w-4" />
                    Sermon Outline
                  </h3>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    {selectedExample.outline.map((point, index) => (
                      <div key={index} className="mb-2 font-mono text-sm leading-relaxed">
                        {point}
                      </div>
                    ))}
                  </div>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                    <Lightbulb className="h-4 w-4" />
                    Illustration
                  </h3>
                  <p className="text-gray-700 italic leading-relaxed">
                    {selectedExample.illustration}
                  </p>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                    <Quote className="h-4 w-4" />
                    Application
                  </h3>
                  <p className="text-gray-700 leading-relaxed">
                    {selectedExample.application}
                  </p>
                </div>
                
                <div className="bg-blue-50 p-4 rounded-lg">
                  <p className="text-sm text-blue-800">
                    <strong>Preacher's Note:</strong> These outlines are provided as starting points for your sermon preparation. 
                    Adapt them to your congregation's needs and your own preaching style. Always study the text thoroughly 
                    and allow the Holy Spirit to guide your preparation and delivery.
                  </p>
                </div>
              </CardContent>
            </ScrollArea>
          </Card>
        </div>
      )}
    </div>
  );
}