import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { User, Church, Clock, MapPin, Book, Users } from "lucide-react";

interface BiographicalEvent {
  date: string;
  event: string;
  significance: string;
  source?: string;
}

interface ChurchDetail {
  aspect: string;
  description: string;
  evidence: string;
}

const paulBiography: BiographicalEvent[] = [
  {
    date: "c. 5-10 AD",
    event: "Birth in Tarsus",
    significance: "Born as Saul in Tarsus of Cilicia, a Roman citizen by birth. Tarsus was a major intellectual center, influencing Paul's later theological and rhetorical skills.",
    source: "Acts 22:3; Philippians 3:5"
  },
  {
    date: "c. 20-30 AD",
    event: "Education in Jerusalem",
    significance: "Studied under Gamaliel, becoming a Pharisee. This rabbinic training shaped his understanding of Scripture and theological methodology evident in Romans.",
    source: "Acts 22:3; Philippians 3:5-6"
  },
  {
    date: "c. 33-34 AD",
    event: "Conversion on Damascus Road",
    significance: "Radical transformation from persecutor to apostle. This experience of grace by faith alone becomes central to Romans' theology.",
    source: "Acts 9:1-19; Galatians 1:13-17"
  },
  {
    date: "c. 46-48 AD",
    event: "First Missionary Journey",
    significance: "Experience with Gentile conversions shapes his understanding of justification apart from works of law, key theme in Romans.",
    source: "Acts 13-14"
  },
  {
    date: "c. 49 AD",
    event: "Jerusalem Council",
    significance: "Gentile inclusion without circumcision established. This decision underlies Romans' argument about righteousness apart from law.",
    source: "Acts 15; Galatians 2"
  },
  {
    date: "c. 49-52 AD",
    event: "Second Missionary Journey",
    significance: "Establishes churches in Macedonia and Achaia. Vision of European expansion connects to Romans 15:19-24.",
    source: "Acts 15:36-18:22"
  },
  {
    date: "c. 53-57 AD",
    event: "Third Missionary Journey",
    significance: "Ministry in Ephesus and collection for Jerusalem poor. Romans written during this period as preparation for Rome visit.",
    source: "Acts 18:23-21:17"
  },
  {
    date: "Winter 56-57 AD",
    event: "Writing Romans in Corinth",
    significance: "Culmination of Paul's theological reflection and missionary experience. Written as his theological 'last will and testament.'",
    source: "Romans 16:1-2 (Phoebe from Cenchreae)"
  }
];

const romeChurchDetails: ChurchDetail[] = [
  {
    aspect: "Origins and Founding",
    description: "The Roman church was not founded by an apostle but likely emerged from Jewish pilgrims who heard Peter's Pentecost sermon (Acts 2:10) and Roman Jews who encountered Christianity in their travels. By 57 AD, it was a well-established, mixed congregation.",
    evidence: "Acts 2:10 mentions 'visitors from Rome' at Pentecost; Paul's lack of founding role evident in Romans 1:8-15"
  },
  {
    aspect: "Composition and Demographics",
    description: "Initially predominantly Jewish-Christian but increasingly Gentile by 57 AD. The community likely met in multiple house churches across different social strata, including both slaves and freedmen, as well as Roman citizens.",
    evidence: "Romans 16 greetings suggest multiple house churches; mix of Jewish (Priscilla, Aquila) and Gentile names"
  },
  {
    aspect: "Claudius Edict and Return",
    description: "Emperor Claudius expelled Jews from Rome (c. 49 AD) due to conflicts 'at the instigation of Chrestus' (likely Christ). When Jews returned after Claudius's death (54 AD), they found Gentile-dominated churches, creating potential tensions Paul addresses.",
    evidence: "Suetonius, Life of Claudius 25.4; Acts 18:2; tension themes in Romans 9-11, 14-15"
  },
  {
    aspect: "Theological Challenges",
    description: "The church faced questions about law observance, Jewish-Gentile relationships, and Israel's role in God's plan. These issues are directly addressed in Romans, suggesting Paul had detailed knowledge of their situation.",
    evidence: "Romans 9-11 (Israel's fate); Romans 14-15 (strong/weak controversy); Romans 2-3 (Jewish privileges)"
  },
  {
    aspect: "Social and Economic Context",
    description: "Rome's Christian community included people from various social levels, from slaves to potential members of the imperial household. This diversity created unique challenges for church unity that Paul addresses.",
    evidence: "Romans 16:10-11 (household references); Philippians 4:22 (Caesar's household); variety of names in Romans 16"
  },
  {
    aspect: "Relationship to Synagogues",
    description: "Jewish Christians likely maintained some synagogue connections while forming distinctly Christian assemblies. This dual identity created theological and practical tensions about law observance and identity.",
    evidence: "Romans 9:1-5 (Paul's anguish for Israel); Romans 3:1-2 (Jewish advantages); synagogue conflicts implied"
  }
];

const theologicalThemes = [
  {
    theme: "Justification by Faith",
    paulBackground: "Paul's Damascus road experience and subsequent ministry to Gentiles convinced him that righteousness comes through faith, not law observance.",
    romeContext: "Mixed congregation needed clear teaching on how Jews and Gentiles are equally justified before God.",
    keyPassages: "Romans 1:16-17; 3:21-31; 4:1-25"
  },
  {
    theme: "Universal Sin and Grace",
    paulBackground: "Paul's former life as a persecutor and his observation of both Jewish and Gentile moral failure informed his understanding of universal need for grace.",
    romeContext: "Tensions between Jewish and Gentile Christians required demonstration that all equally need salvation.",
    keyPassages: "Romans 1:18-3:20; 5:12-21"
  },
  {
    theme: "Israel and the Gentiles",
    paulBackground: "Paul's calling as apostle to the Gentiles and his love for his Jewish kinsmen created tension he resolves through understanding God's sovereign plan.",
    romeContext: "Post-Claudian church needed to understand the relationship between Israel's temporary rejection and Gentile inclusion.",
    keyPassages: "Romans 9-11"
  },
  {
    theme: "Christian Living and Unity",
    paulBackground: "Paul's pastoral experience with diverse congregations taught him how theological truth must translate into practical community life.",
    romeContext: "Practical divisions over food laws, Sabbath observance, and cultural practices needed apostolic guidance.",
    keyPassages: "Romans 12-15"
  }
];

export function BackgroundRomansPaul() {
  const [selectedTab, setSelectedTab] = useState<'paul' | 'rome' | 'themes'>('paul');

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 p-6">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-2">
            Background of Romans and Paul
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mb-6">
            Historical and theological context of Paul's letter to the Romans
          </p>
        </div>

        <Tabs value={selectedTab} onValueChange={(value) => setSelectedTab(value as 'paul' | 'rome' | 'themes')}>
          <TabsList className="grid w-full grid-cols-1 md:grid-cols-3 mb-6 h-auto">
            <TabsTrigger value="paul" className="flex items-center gap-2 py-3 px-4 text-sm">
              <User className="h-4 w-4 flex-shrink-0" />
              <span className="truncate">Apostle Paul</span>
            </TabsTrigger>
            <TabsTrigger value="rome" className="flex items-center gap-2 py-3 px-4 text-sm">
              <Church className="h-4 w-4 flex-shrink-0" />
              <span className="truncate">Church in Rome</span>
            </TabsTrigger>
            <TabsTrigger value="themes" className="flex items-center gap-2 py-3 px-4 text-sm">
              <Book className="h-4 w-4 flex-shrink-0" />
              <span className="truncate">Theological Context</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="paul" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  Paul's Life Leading to Romans
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 dark:text-gray-400 mb-6">
                  Understanding Paul's biography helps explain the theological depth and pastoral concern evident in Romans.
                </p>
                <div className="space-y-6">
                  {paulBiography.map((event, index) => (
                    <div key={index} className="border-l-2 border-blue-200 dark:border-blue-800 pl-4">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge variant="outline">{event.date}</Badge>
                        <h4 className="font-semibold text-gray-900 dark:text-gray-100">
                          {event.event}
                        </h4>
                      </div>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                        {event.significance}
                      </p>
                      {event.source && (
                        <p className="text-xs text-blue-600 dark:text-blue-400 italic">
                          Biblical reference: {event.source}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Paul's Theological Development</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-3">
                      Pre-Christian Formation
                    </h4>
                    <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-2">
                      <li>• Hellenistic education in Tarsus</li>
                      <li>• Pharisaic training under Gamaliel</li>
                      <li>• Zealous law observance and persecution</li>
                      <li>• Bilingual (Greek/Aramaic) and bicultural</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-3">
                      Post-Conversion Development
                    </h4>
                    <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-2">
                      <li>• Arabia retreat for theological reflection</li>
                      <li>• Gentile mission experience</li>
                      <li>• Church planting and pastoral care</li>
                      <li>• Theological controversies and resolutions</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="rome" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  The Christian Community in Rome
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 dark:text-gray-400 mb-6">
                  By 57 AD, Rome had a well-established Christian community with unique characteristics and challenges.
                </p>
                <div className="space-y-6">
                  {romeChurchDetails.map((detail, index) => (
                    <div key={index}>
                      <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">
                        {detail.aspect}
                      </h4>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                        {detail.description}
                      </p>
                      <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded">
                        <p className="text-xs text-blue-700 dark:text-blue-300">
                          <strong>Evidence:</strong> {detail.evidence}
                        </p>
                      </div>
                      {index < romeChurchDetails.length - 1 && <Separator className="mt-6" />}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Social and Religious Environment</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-3">
                      Roman Religious Context
                    </h4>
                    <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-2">
                      <li>• Imperial cult and traditional Roman religion</li>
                      <li>• Popular mystery religions (Mithraism, Isis)</li>
                      <li>• Philosophical schools (Stoicism, Epicureanism)</li>
                      <li>• Jewish synagogues and proselytes</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-3">
                      Social Challenges for Christians
                    </h4>
                    <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-2">
                      <li>• Participation in guild and civic activities</li>
                      <li>• Food offered to idols (marketplace issues)</li>
                      <li>• Sabbath observance vs. Roman work patterns</li>
                      <li>• Mixed marriages and family tensions</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="themes" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>How Paul's Background Shaped Romans' Theology</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 dark:text-gray-400 mb-6">
                  Romans reflects the intersection of Paul's personal experience, theological development, and the specific needs of the Roman church.
                </p>
                <div className="space-y-6">
                  {theologicalThemes.map((theme, index) => (
                    <div key={index}>
                      <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-3">
                        {theme.theme}
                      </h4>
                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <h5 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            Paul's Background
                          </h5>
                          <p className="text-xs text-gray-600 dark:text-gray-400">
                            {theme.paulBackground}
                          </p>
                        </div>
                        <div>
                          <h5 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                            Rome's Situation
                          </h5>
                          <p className="text-xs text-gray-600 dark:text-gray-400">
                            {theme.romeContext}
                          </p>
                        </div>
                      </div>
                      <div className="mt-3">
                        <Badge variant="outline" className="text-xs">
                          Key passages: {theme.keyPassages}
                        </Badge>
                      </div>
                      {index < theologicalThemes.length - 1 && <Separator className="mt-6" />}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Purpose and Occasion of Romans</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">
                      Immediate Occasions
                    </h4>
                    <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                      <li>• Paul's planned visit to Rome en route to Spain (Romans 15:23-24)</li>
                      <li>• Need for Roman support for Spanish mission</li>
                      <li>• Desire to strengthen and unify the Roman churches</li>
                      <li>• Address tensions between Jewish and Gentile Christians</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">
                      Deeper Purposes
                    </h4>
                    <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-1">
                      <li>• Present comprehensive statement of gospel theology</li>
                      <li>• Demonstrate unity of God's plan for Jews and Gentiles</li>
                      <li>• Establish apostolic authority through theological exposition</li>
                      <li>• Provide foundation for practical Christian living</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}