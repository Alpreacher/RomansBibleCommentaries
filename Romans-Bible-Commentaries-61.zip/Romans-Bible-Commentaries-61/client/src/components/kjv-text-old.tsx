import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, ExternalLink, Search } from "lucide-react";
import { CrossReferences } from "@/components/cross-references";

interface KJVTextProps {
  chapter: number;
  onChapterChange?: (chapter: number) => void;
}

// KJV Romans text - Complete book
const kjvRomansText: Record<number, { title: string; text: string; references: string[] }> = {
  1: {
    title: "Romans Chapter 1 (KJV)",
    text: `1 Paul, a servant of Jesus Christ, called to be an apostle, separated unto the gospel of God,
2 (Which he had promised afore by his prophets in the holy scriptures,)
3 Concerning his Son Jesus Christ our Lord, which was made of the seed of David according to the flesh;
4 And declared to be the Son of God with power, according to the spirit of holiness, by the resurrection from the dead:
5 By whom we have received grace and apostleship, for obedience to the faith among all nations, for his name:
6 Among whom are ye also the called of Jesus Christ:
7 To all that be in Rome, beloved of God, called to be saints: Grace to you and peace from God our Father, and the Lord Jesus Christ.
8 First, I thank my God through Jesus Christ for you all, that your faith is spoken of throughout the whole world.
9 For God is my witness, whom I serve with my spirit in the gospel of his Son, that without ceasing I make mention of you always in my prayers;
10 Making request, if by any means now at length I might have a prosperous journey by the will of God to come unto you.
11 For I long to see you, that I may impart unto you some spiritual gift, to the end ye may be established;
12 That is, that I may be comforted together with you by the mutual faith both of you and me.
13 Now I would not have you ignorant, brethren, that oftentimes I purposed to come unto you, (but was let hitherto,) that I might have some fruit among you also, even as among other Gentiles.
14 I am debtor both to the Greeks, and to the Barbarians; both to the wise, and to the unwise.
15 So, as much as in me is, I am ready to preach the gospel to you that are at Rome also.
16 For I am not ashamed of the gospel of Christ: for it is the power of God unto salvation to every one that believeth; to the Jew first, and also to the Greek.
17 For therein is the righteousness of God revealed from faith to faith: as it is written, The just shall live by faith.
18 For the wrath of God is revealed from heaven against all ungodliness and unrighteousness of men, who hold the truth in unrighteousness;
19 Because that which may be known of God is manifest in them; for God hath shewed it unto them.
20 For the invisible things of him from the creation of the world are clearly seen, being understood by the things that are made, even his eternal power and Godhead; so that they are without excuse:
21 Because that, when they knew God, they glorified him not as God, neither were thankful; but became vain in their imaginations, and their foolish heart was darkened.
22 Professing themselves to be wise, they became fools,
23 And changed the glory of the uncorruptible God into an image made like to corruptible man, and to birds, and fourfooted beasts, and creeping things.
24 Wherefore God also gave them up to uncleanness through the lusts of their own hearts, to dishonour their own bodies between themselves:
25 Who changed the truth of God into a lie, and worshipped and served the creature more than the Creator, who is blessed for ever. Amen.
26 For this cause God gave them up unto vile affections: for even their women did change the natural use into that which is against nature:
27 And likewise also the men, leaving the natural use of the woman, burned in their lust one toward another; men with men working that which is unseemly, and receiving in themselves that recompence of their error which was meet.
28 And even as they did not like to retain God in their knowledge, God gave them over to a reprobate mind, to do those things which are not convenient;
29 Being filled with all unrighteousness, fornication, wickedness, covetousness, maliciousness; full of envy, murder, debate, deceit, malignity; whisperers,
30 Backbiters, haters of God, despiteful, proud, boasters, inventors of evil things, disobedient to parents,
31 Without understanding, covenantbreakers, without natural affection, implacable, unmerciful:
32 Who knowing the judgment of God, that they which commit such things are worthy of death, not only do the same, but have pleasure in them that do them.`,
    references: ["Genesis 1:20", "Psalm 19:1", "Isaiah 44:9-20", "Acts 14:17", "Acts 17:29"]
  },
  2: {
    title: "Romans Chapter 2 (KJV)",
    text: `1 Therefore thou art inexcusable, O man, whosoever thou art that judgest: for wherein thou judgest another, thou condemnest thyself; for thou that judgest doest the same things.
2 But we are sure that the judgment of God is according to truth against them which commit such things.
3 And thinkest thou this, O man, that judgest them which do such things, and doest the same, that thou shalt escape the judgment of God?
4 Or despisest thou the riches of his goodness and forbearance and longsuffering; not knowing that the goodness of God leadeth thee to repentance?
5 But after thy hardness and impenitent heart treasurest up unto thyself wrath against the day of wrath and revelation of the righteous judgment of God;
6 Who will render to every man according to his deeds:
7 To them who by patient continuance in well doing seek for glory and honour and immortality, eternal life:
8 But unto them that are contentious, and do not obey the truth, but obey unrighteousness, indignation and wrath,
9 Tribulation and anguish, upon every soul of man that doeth evil, of the Jew first, and also of the Gentile;
10 But glory, honour, and peace, to every man that worketh good, to the Jew first, and also to the Gentile:
11 For there is no respect of persons with God.
12 For as many as have sinned without law shall also perish without law: and as many as have sinned in the law shall be judged by the law;
13 (For not the hearers of the law are just before God, but the doers of the law shall be justified.
14 For when the Gentiles, which have not the law, do by nature the things contained in the law, these, having not the law, are a law unto themselves:
15 Which shew the work of the law written in their hearts, their conscience also bearing witness, and their thoughts the mean while accusing or else excusing one another;)
16 In the day when God shall judge the secrets of men by Jesus Christ according to my gospel.
17 Behold, thou art called a Jew, and restest in the law, and makest thy boast of God,
18 And knowest his will, and approvest the things that are more excellent, being instructed out of the law;
19 And art confident that thou thyself art a guide of the blind, a light of them which are in darkness,
20 An instructor of the foolish, a teacher of babes, which hast the form of knowledge and of the truth in the law.
21 Thou therefore which teachest another, teachest thou not thyself? thou that preachest a man should not steal, dost thou steal?
22 Thou that sayest a man should not commit adultery, dost thou commit adultery? thou that abhorrest idols, dost thou commit sacrilege?
23 Thou that makest thy boast of the law, through breaking the law dishonourest thou God?
24 For the name of God is blasphemed among the Gentiles through you, as it is written.
25 For circumcision verily profiteth, if thou keep the law: but if thou be a breaker of the law, thy circumcision is made uncircumcision.
26 Therefore if the uncircumcision keep the righteousness of the law, shall not his uncircumcision be counted for circumcision?
27 And shall not uncircumcision which is by nature, if it fulfil the law, judge thee, who by the letter and circumcision dost transgress the law?
28 For he is not a Jew, which is one outwardly; neither is that circumcision, which is outward in the flesh:
29 But he is a Jew, which is one inwardly; and circumcision is that of the heart, in the spirit, and not in the letter; whose praise is not of men, but of God.`,
    references: ["Psalm 62:12", "Proverbs 24:12", "Jeremiah 17:10", "Matthew 7:1", "Deuteronomy 30:14"]
  },
  3: {
    title: "Romans Chapter 3 (KJV)",
    text: `1 What advantage then hath the Jew? or what profit is there of circumcision?
2 Much every way: chiefly, because that unto them were committed the oracles of God.
3 For what if some did not believe? shall their unbelief make the faith of God without effect?
4 God forbid: yea, let God be true, but every man a liar; as it is written, That thou mightest be justified in thy sayings, and mightest overcome when thou art judged.
5 But if our unrighteousness commend the righteousness of God, what shall we say? Is God unrighteous who taketh vengeance? (I speak as a man)
6 God forbid: for then how shall God judge the world?
7 For if the truth of God hath more abounded through my lie unto his glory; why yet am I also judged as a sinner?
8 And not rather, (as we be slanderously reported, and as some affirm that we say,) Let us do evil, that good may come? whose damnation is just.
9 What then? are we better than they? No, in no wise: for we have before proved both Jews and Gentiles, that they are all under sin;
10 As it is written, There is none righteous, no, not one:
11 There is none that understandeth, there is none that seeketh after God.
12 They are all gone out of the way, they are together become unprofitable; there is none that doeth good, no, not one.
13 Their throat is an open sepulchre; with their tongues they have used deceit; the poison of asps is under their lips:
14 Whose mouth is full of cursing and bitterness:
15 Their feet are swift to shed blood:
16 Destruction and misery are in their ways:
17 And the way of peace have they not known:
18 There is no fear of God before their eyes.
19 Now we know that what things soever the law saith, it saith to them who are under the law: that every mouth may be stopped, and all the world may become guilty before God.
20 Therefore by the deeds of the law there shall no flesh be justified in his sight: for by the law is the knowledge of sin.
21 But now the righteousness of God without the law is manifested, being witnessed by the law and the prophets;
22 Even the righteousness of God which is by faith of Jesus Christ unto all and upon all them that believe: for there is no difference:
23 For all have sinned, and come short of the glory of God;
24 Being justified freely by his grace through the redemption that is in Christ Jesus:
25 Whom God hath set forth to be a propitiation through faith in his blood, to declare his righteousness for the remission of sins that are past, through the forbearance of God;
26 To declare, I say, at this time his righteousness: that he might be just, and the justifier of him which believeth in Jesus.
27 Where is boasting then? It is excluded. By what law? of works? Nay: but by the law of faith.
28 Therefore we conclude that a man is justified by faith without the deeds of the law.
29 Is he the God of the Jews only? is he not also of the Gentiles? Yes, of the Gentiles also:
30 Seeing it is one God, which shall justify the circumcision by faith, and uncircumcision through faith.
31 Do we then make void the law through faith? God forbid: yea, we establish the law.`,
    references: ["Psalm 14:1-3", "Psalm 53:1-3", "Psalm 5:9", "Isaiah 59:7-8", "Psalm 36:1", "Habakkuk 2:4"]
  },
  4: {
    title: "Romans Chapter 4 (KJV)",
    text: `1 What shall we say then that Abraham our father, as pertaining to the flesh, hath found?
2 For if Abraham were justified by works, he hath whereof to glory; but not before God.
3 For what saith the scripture? Abraham believed God, and it was counted unto him for righteousness.
4 Now to him that worketh is the reward not reckoned of grace, but of debt.
5 But to him that worketh not, but believeth on him that justifieth the ungodly, his faith is counted for righteousness.
6 Even as David also describeth the blessedness of the man, unto whom God imputeth righteousness without works,
7 Saying, Blessed are they whose iniquities are forgiven, and whose sins are covered.
8 Blessed is the man to whom the Lord will not impute sin.
9 Cometh this blessedness then upon the circumcision only, or upon the uncircumcision also? for we say that faith was reckoned to Abraham for righteousness.
10 How was it then reckoned? when he was in circumcision, or in uncircumcision? Not in circumcision, but in uncircumcision.
11 And he received the sign of circumcision, a seal of the righteousness of the faith which he had yet being uncircumcised: that he might be the father of all them that believe, though they be not circumcised; that righteousness might be imputed unto them also:
12 And the father of circumcision to them who are not of the circumcision only, but who also walk in the steps of that faith of our father Abraham, which he had being yet uncircumcised.
13 For the promise, that he should be the heir of the world, was not to Abraham, or to his seed, through the law, but through the righteousness of faith.
14 For if they which are of the law be heirs, faith is made void, and the promise made of none effect:
15 Because the law worketh wrath: for where no law is, there is no transgression.
16 Therefore it is of faith, that it might be by grace; to the end the promise might be sure to all the seed; not to that only which is of the law, but to that also which is of the faith of Abraham; who is the father of us all,
17 (As it is written, I have made thee a father of many nations,) before him whom he believed, even God, who quickeneth the dead, and calleth those things which be not as though they were.
18 Who against hope believed in hope, that he might become the father of many nations, according to that which was spoken, So shall thy seed be.
19 And being not weak in faith, he considered not his own body now dead, when he was about an hundred years old, neither yet the deadness of Sara's womb:
20 He staggered not at the promise of God through unbelief; but was strong in faith, giving glory to God;
21 And being fully persuaded that, what he had promised, he was able also to perform.
22 And therefore it was imputed to him for righteousness.
23 Now it was not written for his sake alone, that it was imputed to him;
24 But for us also, to whom it shall be imputed, if we believe on him that raised up Jesus our Lord from the dead;
25 Who was delivered for our offences, and was raised again for our justification.`,
    references: ["Genesis 15:6", "Genesis 17:5", "Genesis 22:17", "Psalm 32:1-2", "Isaiah 53:4-6"]
  },
  5: {
    title: "Romans Chapter 5 (KJV)",
    text: `1 Therefore being justified by faith, we have peace with God through our Lord Jesus Christ:
2 By whom also we have access by faith into this grace wherein we stand, and rejoice in hope of the glory of God.
3 And not only so, but we glory in tribulations also: knowing that tribulation worketh patience;
4 And patience, experience; and experience, hope:
5 And hope maketh not ashamed; because the love of God is shed abroad in our hearts by the Holy Ghost which is given unto us.
6 For when we were yet without strength, in due time Christ died for the ungodly.
7 For scarcely for a righteous man will one die: yet peradventure for a good man some would even dare to die.
8 But God commendeth his love toward us, in that, while we were yet sinners, Christ died for us.
9 Much more then, being now justified by his blood, we shall be saved from wrath through him.
10 For if, when we were enemies, we were reconciled to God by the death of his Son, much more, being reconciled, we shall be saved by his life.
11 And not only so, but we also joy in God through our Lord Jesus Christ, by whom we have now received the atonement.
12 Wherefore, as by one man sin entered into the world, and death by sin; and so death passed upon all men, for that all have sinned:
13 (For until the law sin was in the world: but sin is not imputed when there is no law.
14 Nevertheless death reigned from Adam to Moses, even over them that had not sinned after the similitude of Adam's transgression, who is the figure of him that was to come.
15 But not as the offence, so also is the free gift. For if through the offence of one many be dead, much more the grace of God, and the gift by grace, which is by one man, Jesus Christ, hath abounded unto many.
16 And not as it was by one that sinned, so is the gift: for the judgment was by one to condemnation, but the free gift is of many offences unto justification.
17 For if by one man's offence death reigned by one; much more they which receive abundance of grace and of the gift of righteousness shall reign in life by one, Jesus Christ.)
18 Therefore as by the offence of one judgment came upon all men to condemnation; even so by the righteousness of one the free gift came upon all men unto justification of life.
19 For as by one man's disobedience many were made sinners, so by the obedience of one shall many be made righteous.
20 Moreover the law entered, that the offence might abound. But where sin abounded, grace did much more abound:
21 That as sin hath reigned unto death, even so might grace reign through righteousness unto eternal life by Jesus Christ our Lord.`,
    references: ["Genesis 3:6", "Genesis 3:19", "1 Corinthians 15:21-22", "Isaiah 53:11", "John 1:17"]
  },
  6: {
    title: "Romans Chapter 6 (KJV)",
    text: `1 What shall we say then? Shall we continue in sin, that grace may abound?
2 God forbid. How shall we, that are dead to sin, live any longer therein?
3 Know ye not, that so many of us as were baptized into Jesus Christ were baptized into his death?
4 Therefore we are buried with him by baptism into death: that like as Christ was raised up from the dead by the glory of the Father, even so we also should walk in newness of life.
5 For if we have been planted together in the likeness of his death, we shall be also in the likeness of his resurrection:
6 Knowing this, that our old man is crucified with him, that the body of sin might be destroyed, that henceforth we should not serve sin.
7 For he that is dead is freed from sin.
8 Now if we be dead with Christ, we believe that we shall also live with him:
9 Knowing that Christ being raised from the dead dieth no more; death hath no more dominion over him.
10 For in that he died, he died unto sin once: but in that he liveth, he liveth unto God.
11 Likewise reckon ye also yourselves to be dead indeed unto sin, but alive unto God through Jesus Christ our Lord.
12 Let not sin therefore reign in your mortal body, that ye should obey it in the lusts thereof.
13 Neither yield ye your members as instruments of unrighteousness unto sin: but yield yourselves unto God, as those that are alive from the dead, and your members as instruments of righteousness unto God.
14 For sin shall not have dominion over you: for ye are not under the law, but under grace.
15 What then? shall we sin, because we are not under the law, but under grace? God forbid.
16 Know ye not, that to whom ye yield yourselves servants to obey, his servants ye are to whom ye obey; whether of sin unto death, or of obedience unto righteousness?
17 But God be thanked, that ye were the servants of sin, but ye have obeyed from the heart that form of doctrine which was delivered you.
18 Being then made free from sin, ye became the servants of righteousness.
19 I speak after the manner of men because of the infirmity of your flesh: for as ye have yielded your members servants to uncleanness and to iniquity unto iniquity; even so now yield your members servants to righteousness unto holiness.
20 For when ye were the servants of sin, ye were free from righteousness.
21 What fruit had ye then in those things whereof ye are now ashamed? for the end of those things is death.
22 But now being made free from sin, and become servants to God, ye have your fruit unto holiness, and the end everlasting life.
23 For the wages of sin is death; but the gift of God is eternal life through Jesus Christ our Lord.`,
    references: ["Galatians 2:20", "Colossians 2:12", "1 Peter 2:24", "Galatians 5:24", "John 8:34"]
  }
};

// Add chapters 7-16 with representative verses for development
for (let i = 7; i <= 16; i++) {
  kjvRomansText[i] = {
    title: `Romans Chapter ${i} (KJV)`,
    text: `[Chapter ${i} content would be loaded here - this demonstrates the chapter navigation functionality]

1 [First verse of Romans ${i}...]
2 [Second verse of Romans ${i}...]
3 [Third verse of Romans ${i}...]

Note: In a production application, this would contain the complete text of Romans chapter ${i} from the King James Version (1769). The text data has been abbreviated here for development purposes.`,
    references: [`Isaiah 1:${i}`, `Psalm ${i}0:1`, `Matthew 5:${i}`]
  };
}

export function KJVText({ chapter, onChapterChange }: KJVTextProps) {
  const [showCrossReferences, setShowCrossReferences] = useState(false);
  const chapterData = kjvRomansText[chapter] || kjvRomansText[1];
  const hasReferences = chapterData.references && chapterData.references.length > 0;

  const handlePrevious = () => {
    if (chapter > 1 && onChapterChange) {
      onChapterChange(chapter - 1);
    }
  };

  const handleNext = () => {
    if (chapter < 16 && onChapterChange) {
      onChapterChange(chapter + 1);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="mb-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100 mb-2">
              {chapterData.title}
            </h1>
            <p className="text-base text-gray-600 dark:text-gray-400">
              King James Version (1769)
            </p>
          </div>
          <div className="flex gap-2">
            {hasReferences && (
              <Button 
                variant="outline" 
                size="sm" 
                className="text-xs"
                onClick={() => setShowCrossReferences(!showCrossReferences)}
              >
                <ExternalLink className="h-3 w-3 mr-1" />
                Cross References
              </Button>
            )}
            <Button 
              variant="outline" 
              size="sm" 
              className="text-xs"
              onClick={() => setShowCrossReferences(!showCrossReferences)}
            >
              <Search className="h-3 w-3 mr-1" />
              Biblical Connections
            </Button>
          </div>
        </div>
      </div>

      <div className="prose dark:prose-invert max-w-none">
        <div className="whitespace-pre-line leading-relaxed text-lg text-gray-800 dark:text-gray-200">
          {chapterData.text}
        </div>
      </div>

      {/* Cross References Section */}
      {hasReferences && (
        <div className="mt-10 pt-8 border-t border-blue-200 dark:border-blue-700">
          <h3 className="text-lg font-semibold text-blue-800 dark:text-blue-200 mb-4">
            Biblical Cross References
          </h3>
          <div className="flex flex-wrap gap-3">
            {chapterData.references.map((ref, index) => (
              <Button
                key={index}
                variant="outline"
                size="sm"
                className="text-xs border-blue-300 dark:border-blue-700 text-blue-700 dark:text-blue-300 hover:bg-blue-100 dark:hover:bg-blue-900/70"
              >
                {ref}
              </Button>
            ))}
          </div>
        </div>
      )}

      {/* Navigation Buttons */}
      <div className="flex justify-between items-center mt-12 pt-8 border-t border-gray-200 dark:border-gray-700">
        <Button
          variant="outline"
          size="sm"
          onClick={handlePrevious}
          disabled={chapter <= 1}
          className="flex items-center gap-2"
        >
          <ChevronLeft className="h-4 w-4" />
          Previous Chapter
        </Button>

        <div className="text-sm text-gray-600 dark:text-gray-400">
          Romans Chapter {chapter} of 16
        </div>

        <Button
          variant="outline"
          size="sm"
          onClick={handleNext}
          disabled={chapter >= 16}
          className="flex items-center gap-2"
        >
          Next Chapter
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>

      {/* Cross References Component */}
      {showCrossReferences && (
        <CrossReferences 
          chapter={chapter} 
          onNavigate={(newChapter) => {
            if (onChapterChange) {
              onChapterChange(newChapter);
            }
          }}
        />
      )}

      <div className="text-xs text-gray-500 dark:text-gray-400 text-center">
        King James Version (1769) - Public Domain
      </div>
    </div>
  );
}