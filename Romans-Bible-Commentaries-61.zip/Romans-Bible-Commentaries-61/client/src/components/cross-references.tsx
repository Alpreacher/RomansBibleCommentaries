import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ExternalLink, BookOpen, Search, ArrowRight } from "lucide-react";

interface CrossReferencesProps {
  chapter: number;
  verse?: number;
  onNavigate?: (chapter: number, verse?: number) => void;
}

interface Reference {
  book: string;
  chapter: number;
  verse?: number;
  text?: string;
  type: 'quote' | 'allusion' | 'theme' | 'parallel';
  confidence: 'high' | 'medium' | 'low';
  category: 'OT_Echo' | 'NT_Parallel' | 'Theological_Theme' | 'Literary_Allusion';
}

interface GreekConnection {
  greekWord: string;
  strongs: string;
  englishGloss: string;
  relatedVerses: string[];
  theologicalSignificance: string;
}

// Comprehensive cross-reference data for Romans
const crossReferences: Record<number, Reference[]> = {
  1: [
    {
      book: "Habakkuk",
      chapter: 2,
      verse: 4,
      text: "The righteous shall live by faith",
      type: "quote",
      confidence: "high",
      category: "OT_Echo"
    },
    {
      book: "Psalm",
      chapter: 19,
      verse: 1,
      text: "The heavens declare the glory of God",
      type: "allusion",
      confidence: "high",
      category: "OT_Echo"
    },
    {
      book: "Genesis",
      chapter: 1,
      verse: 20,
      text: "Creation reveals God's invisible attributes",
      type: "theme",
      confidence: "medium",
      category: "OT_Echo"
    },
    {
      book: "Isaiah",
      chapter: 44,
      verse: 9,
      text: "Idolatry critique",
      type: "allusion",
      confidence: "medium",
      category: "OT_Echo"
    },
    {
      book: "Acts",
      chapter: 14,
      verse: 17,
      text: "God's self-revelation in creation",
      type: "parallel",
      confidence: "high",
      category: "NT_Parallel"
    }
  ],
  2: [
    {
      book: "Psalm",
      chapter: 62,
      verse: 12,
      text: "God rewards according to deeds",
      type: "quote",
      confidence: "high",
      category: "OT_Echo"
    },
    {
      book: "Proverbs",
      chapter: 24,
      verse: 12,
      text: "Divine judgment according to works",
      type: "allusion",
      confidence: "high",
      category: "OT_Echo"
    },
    {
      book: "Jeremiah",
      chapter: 17,
      verse: 10,
      text: "Heart examination by God",
      type: "theme",
      confidence: "medium",
      category: "OT_Echo"
    },
    {
      book: "Matthew",
      chapter: 7,
      verse: 1,
      text: "Judge not lest ye be judged",
      type: "parallel",
      confidence: "high",
      category: "NT_Parallel"
    }
  ],
  3: [
    {
      book: "Psalm",
      chapter: 14,
      verse: 1,
      text: "There is none righteous, no not one",
      type: "quote",
      confidence: "high",
      category: "OT_Echo"
    },
    {
      book: "Psalm",
      chapter: 53,
      verse: 1,
      text: "Universal sinfulness",
      type: "quote",
      confidence: "high",
      category: "OT_Echo"
    },
    {
      book: "Psalm",
      chapter: 5,
      verse: 9,
      text: "Throat as open sepulchre",
      type: "quote",
      confidence: "high",
      category: "OT_Echo"
    },
    {
      book: "Isaiah",
      chapter: 59,
      verse: 7,
      text: "Swift to shed blood",
      type: "quote",
      confidence: "high",
      category: "OT_Echo"
    }
  ],
  4: [
    {
      book: "Genesis",
      chapter: 15,
      verse: 6,
      text: "Abraham believed God and it was counted as righteousness",
      type: "quote",
      confidence: "high",
      category: "OT_Echo"
    },
    {
      book: "Genesis",
      chapter: 17,
      verse: 5,
      text: "Father of many nations",
      type: "quote",
      confidence: "high",
      category: "OT_Echo"
    },
    {
      book: "Psalm",
      chapter: 32,
      verse: 1,
      text: "Blessed are they whose iniquities are forgiven",
      type: "quote",
      confidence: "high",
      category: "OT_Echo"
    }
  ],
  5: [
    {
      book: "Genesis",
      chapter: 3,
      verse: 6,
      text: "Sin entered through one man",
      type: "allusion",
      confidence: "high",
      category: "OT_Echo"
    },
    {
      book: "1 Corinthians",
      chapter: 15,
      verse: 21,
      text: "Death through Adam, life through Christ",
      type: "parallel",
      confidence: "high",
      category: "NT_Parallel"
    },
    {
      book: "Isaiah",
      chapter: 53,
      verse: 11,
      text: "Many made righteous through the Servant",
      type: "theme",
      confidence: "medium",
      category: "OT_Echo"
    }
  ],
  6: [
    {
      book: "Galatians",
      chapter: 2,
      verse: 20,
      text: "Crucified with Christ",
      type: "parallel",
      confidence: "high",
      category: "NT_Parallel"
    },
    {
      book: "Colossians",
      chapter: 2,
      verse: 12,
      text: "Buried with him in baptism",
      type: "parallel",
      confidence: "high",
      category: "NT_Parallel"
    },
    {
      book: "John",
      chapter: 8,
      verse: 34,
      text: "Slave to sin",
      type: "theme",
      confidence: "high",
      category: "NT_Parallel"
    }
  ]
};

const greekConnections: Record<number, GreekConnection[]> = {
  1: [
    {
      greekWord: "δικαιοσύνη",
      strongs: "G1343",
      englishGloss: "righteousness, justice",
      relatedVerses: ["Romans 1:17", "Romans 3:21-22", "Romans 10:3"],
      theologicalSignificance: "Central theme of Romans - God's righteousness revealed in the gospel"
    },
    {
      greekWord: "πίστις",
      strongs: "G4102",
      englishGloss: "faith, trust, belief",
      relatedVerses: ["Romans 1:5", "Romans 1:8", "Romans 1:12", "Romans 1:17"],
      theologicalSignificance: "The means by which righteousness is received and lived"
    },
    {
      greekWord: "εὐαγγέλιον",
      strongs: "G2098",
      englishGloss: "gospel, good news",
      relatedVerses: ["Romans 1:1", "Romans 1:9", "Romans 1:15-16"],
      theologicalSignificance: "The power of God unto salvation"
    }
  ],
  2: [
    {
      greekWord: "κρίμα",
      strongs: "G2917",
      englishGloss: "judgment, verdict",
      relatedVerses: ["Romans 2:2-3", "Romans 3:8", "Romans 5:16"],
      theologicalSignificance: "God's righteous judgment according to truth"
    }
  ],
  3: [
    {
      greekWord: "ἁμαρτία",
      strongs: "G266",
      englishGloss: "sin, missing the mark",
      relatedVerses: ["Romans 3:9", "Romans 3:20", "Romans 3:23", "Romans 5:12"],
      theologicalSignificance: "Universal human condition requiring divine intervention"
    },
    {
      greekWord: "δικαιόω",
      strongs: "G1344",
      englishGloss: "to justify, declare righteous",
      relatedVerses: ["Romans 3:24", "Romans 3:26", "Romans 3:28", "Romans 4:2"],
      theologicalSignificance: "God's act of declaring sinners righteous through faith"
    }
  ]
};

export function CrossReferences({ chapter, verse, onNavigate }: CrossReferencesProps) {
  const [activeTab, setActiveTab] = useState("ot-echoes");
  
  const chapterRefs = crossReferences[chapter] || [];
  const chapterGreek = greekConnections[chapter] || [];
  
  const otEchoes = chapterRefs.filter(ref => ref.category === 'OT_Echo');
  const ntParallels = chapterRefs.filter(ref => ref.category === 'NT_Parallel');
  const themeConnections = chapterRefs.filter(ref => ref.category === 'Theological_Theme');
  
  const getConfidenceColor = (confidence: string) => {
    switch (confidence) {
      case 'high': return 'bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300';
      case 'medium': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300';
      case 'low': return 'bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300';
      default: return 'bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'quote': return '📜';
      case 'allusion': return '🔗';
      case 'theme': return '💭';
      case 'parallel': return '↔️';
      default: return '📖';
    }
  };

  const handleReferenceClick = (ref: Reference) => {
    if (onNavigate) {
      onNavigate(ref.chapter, ref.verse);
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Search className="h-5 w-5" />
          Cross References - Romans Chapter {chapter}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="ot-echoes">OT Echoes</TabsTrigger>
            <TabsTrigger value="nt-parallels">NT Parallels</TabsTrigger>
            <TabsTrigger value="greek-terms">Greek Terms</TabsTrigger>
            <TabsTrigger value="themes">Themes</TabsTrigger>
          </TabsList>
          
          <TabsContent value="ot-echoes" className="mt-4">
            <ScrollArea className="h-[400px]">
              <div className="space-y-3">
                {otEchoes.length > 0 ? otEchoes.map((ref, index) => (
                  <div 
                    key={index}
                    className="p-3 border border-purple-200 dark:border-purple-800 rounded-lg bg-purple-50/50 dark:bg-purple-950/20"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">{getTypeIcon(ref.type)}</span>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="font-semibold text-purple-700 dark:text-purple-300 hover:text-purple-900 dark:hover:text-purple-100"
                          onClick={() => handleReferenceClick(ref)}
                        >
                          {ref.book} {ref.chapter}{ref.verse ? `:${ref.verse}` : ''}
                          <ExternalLink className="h-3 w-3 ml-1" />
                        </Button>
                      </div>
                      <div className="flex gap-2">
                        <Badge variant="outline" className={getConfidenceColor(ref.confidence)}>
                          {ref.confidence}
                        </Badge>
                        <Badge variant="outline" className="text-xs">
                          {ref.type}
                        </Badge>
                      </div>
                    </div>
                    {ref.text && (
                      <p className="text-sm text-gray-600 dark:text-gray-300 italic">
                        "{ref.text}"
                      </p>
                    )}
                  </div>
                )) : (
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    No Old Testament echoes identified for this chapter yet.
                  </p>
                )}
              </div>
            </ScrollArea>
          </TabsContent>
          
          <TabsContent value="nt-parallels" className="mt-4">
            <ScrollArea className="h-[400px]">
              <div className="space-y-3">
                {ntParallels.length > 0 ? ntParallels.map((ref, index) => (
                  <div 
                    key={index}
                    className="p-3 border border-blue-200 dark:border-blue-800 rounded-lg bg-blue-50/50 dark:bg-blue-950/20"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">{getTypeIcon(ref.type)}</span>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="font-semibold text-blue-700 dark:text-blue-300 hover:text-blue-900 dark:hover:text-blue-100"
                          onClick={() => handleReferenceClick(ref)}
                        >
                          {ref.book} {ref.chapter}{ref.verse ? `:${ref.verse}` : ''}
                          <ArrowRight className="h-3 w-3 ml-1" />
                        </Button>
                      </div>
                      <Badge variant="outline" className={getConfidenceColor(ref.confidence)}>
                        {ref.confidence}
                      </Badge>
                    </div>
                    {ref.text && (
                      <p className="text-sm text-gray-600 dark:text-gray-300 italic">
                        "{ref.text}"
                      </p>
                    )}
                  </div>
                )) : (
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    No New Testament parallels identified for this chapter yet.
                  </p>
                )}
              </div>
            </ScrollArea>
          </TabsContent>
          
          <TabsContent value="greek-terms" className="mt-4">
            <ScrollArea className="h-[400px]">
              <div className="space-y-3">
                {chapterGreek.length > 0 ? chapterGreek.map((greek, index) => (
                  <div 
                    key={index}
                    className="p-3 border border-green-200 dark:border-green-800 rounded-lg bg-green-50/50 dark:bg-green-950/20"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <BookOpen className="h-4 w-4 text-green-600 dark:text-green-400" />
                        <span 
                          className="font-semibold text-green-800 dark:text-green-200 greek-font"
                          style={{ fontFamily: '"SBL Greek", "Times New Roman", serif' }}
                        >
                          {greek.greekWord}
                        </span>
                        <Badge variant="outline" className="text-xs">
                          {greek.strongs}
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                      {greek.englishGloss}
                    </p>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                      {greek.theologicalSignificance}
                    </p>
                    <div className="flex flex-wrap gap-1">
                      {greek.relatedVerses.map((verse, vIndex) => (
                        <Badge 
                          key={vIndex} 
                          variant="outline" 
                          className="text-xs bg-white dark:bg-green-900/20"
                        >
                          {verse}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )) : (
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    Greek term analysis not yet available for this chapter.
                  </p>
                )}
              </div>
            </ScrollArea>
          </TabsContent>
          
          <TabsContent value="themes" className="mt-4">
            <ScrollArea className="h-[400px]">
              <div className="space-y-3">
                {themeConnections.length > 0 ? themeConnections.map((ref, index) => (
                  <div 
                    key={index}
                    className="p-3 border border-orange-200 dark:border-orange-800 rounded-lg bg-orange-50/50 dark:bg-orange-950/20"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">💭</span>
                        <span className="font-semibold text-orange-800 dark:text-orange-200">
                          {ref.book} {ref.chapter}{ref.verse ? `:${ref.verse}` : ''}
                        </span>
                      </div>
                      <Badge variant="outline" className={getConfidenceColor(ref.confidence)}>
                        Thematic
                      </Badge>
                    </div>
                    {ref.text && (
                      <p className="text-sm text-gray-600 dark:text-gray-300">
                        {ref.text}
                      </p>
                    )}
                  </div>
                )) : (
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    Thematic connections will be developed as the system grows.
                  </p>
                )}
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}