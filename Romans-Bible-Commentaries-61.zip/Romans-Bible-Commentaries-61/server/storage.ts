import { commentaries, bookmarks, type Commentary, type InsertCommentary, type Bookmark, type InsertBookmark, type TheologicalTheme } from "@shared/schema";

export interface IStorage {
  // Commentary methods
  getCommentaries(): Promise<Commentary[]>;
  getCommentary(id: number): Promise<Commentary | undefined>;
  getCommentaryChapter(id: number, chapter: number): Promise<any>;
  searchCommentaries(query: string, commentaryId?: number): Promise<any[]>;
  
  // Bookmark methods
  getBookmarks(userId: string): Promise<Bookmark[]>;
  addBookmark(bookmark: InsertBookmark): Promise<Bookmark>;
  removeBookmark(userId: string, commentaryId: number, chapter: number): Promise<void>;
  isBookmarked(userId: string, commentaryId: number, chapter: number): Promise<boolean>;
  
  // Theological themes methods
  getTheologicalThemes(): Promise<TheologicalTheme[]>;
  searchThemes(query: string): Promise<TheologicalTheme[]>;
  getThemesByCategory(category: string): Promise<TheologicalTheme[]>;
}

export class MemStorage implements IStorage {
  private commentaries: Map<number, Commentary>;
  private bookmarks: Map<number, Bookmark>;
  private theologicalThemes: TheologicalTheme[];
  private currentCommentaryId: number;
  private currentBookmarkId: number;

  constructor() {
    this.commentaries = new Map();
    this.bookmarks = new Map();
    this.theologicalThemes = [];
    this.currentCommentaryId = 1;
    this.currentBookmarkId = 1;
    this.initializeCommentaries();
    this.initializeTheologicalThemes();
  }

  private initializeCommentaries() {
    const matthewHenry: InsertCommentary = {
      author: "Matthew Henry",
      title: "Complete Commentary on the Whole Bible",
      description: "A comprehensive verse-by-verse commentary on the entire Bible",
      year: "1706",
      chapters: this.generateMatthewHenryChapters()
    };

    const calvin: InsertCommentary = {
      author: "John Calvin",
      title: "Commentary on Romans",
      description: "Reformed perspective on Paul's letter to the Romans",
      year: "1540",
      chapters: this.generateCalvinChapters()
    };

    const barnes: InsertCommentary = {
      author: "Albert Barnes",
      title: "Notes on the New Testament",
      description: "Practical exposition of New Testament books",
      year: "1834",
      chapters: this.generateBarnesChapters()
    };

    const chrysostom: InsertCommentary = {
      author: "John Chrysostom",
      title: "Homilies on Romans",
      description: "Early church father's sermons on Romans",
      year: "~390 AD",
      chapters: this.generateChrysostomChapters()
    };

    const clarke: InsertCommentary = {
      author: "Adam Clarke",
      title: "Commentary on the Bible",
      description: "Methodist commentary with linguistic insights",
      year: "1810",
      chapters: this.generateClarkeChapters()
    };

    // Add commentaries
    [matthewHenry, calvin, barnes, chrysostom, clarke].forEach(commentary => {
      const id = this.currentCommentaryId++;
      this.commentaries.set(id, { ...commentary, id });
    });
  }

  private generateMatthewHenryChapters() {
    const chapters = [];
    const chapterSpecificThemes = {
      1: ["Gospel power", "Divine wrath", "Natural revelation", "Practical righteousness"],
      2: ["Divine judgment", "Conscience role", "Religious hypocrisy", "True circumcision"],
      3: ["Human sinfulness", "Divine faithfulness", "Justification", "Boasting excluded"],
      4: ["Abraham's faith", "Works vs. faith", "Promise inheritance", "Faith's certainty"],
      5: ["Peace through Christ", "Sin's entry", "Grace triumph", "Hope assurance"],
      6: ["Sin's death", "Grace abuse", "Baptismal union", "Sin's service"],
      7: ["Law's limits", "Sin's power", "Spiritual struggle", "Deliverance cry"],
      8: ["Spiritual life", "Adoption privilege", "Creation's hope", "Prayer help"],
      9: ["God's freedom", "Election mercy", "Hardening justice", "Remnant grace"],
      10: ["Righteousness nearness", "Faith confession", "Universal call", "Israel's refusal"],
      11: ["Remnant hope", "Gentile warning", "Restoration promise", "Divine wisdom"],
      12: ["Body presentation", "Mind transformation", "Gift exercise", "Love practice"],
      13: ["Authority submission", "Love debt", "Light walking", "Christ clothing"],
      14: ["Conscience liberty", "Judgment avoidance", "Peace pursuit", "Edification goal"],
      15: ["Weak bearing", "Scripture hope", "Unity prayer", "Gentile service"],
      16: ["Faithful service", "Church fellowship", "False teacher warning", "Grace benediction"]
    };

    for (let i = 1; i <= 16; i++) {
      chapters.push({
        chapter: i,
        title: `Romans Chapter ${i} Commentary`,
        introduction: `Matthew Henry's exposition of Romans chapter ${i}, providing practical insights into Paul's theological arguments.`,
        sections: [
          {
            verses: `${i}:1-7`,
            title: "Opening Section",
            content: `Henry's detailed analysis of the opening verses of Romans ${i}, emphasizing the practical application of Paul's teachings for daily Christian living. He provides historical context and draws connections to contemporary faith practices.`
          },
          {
            verses: `${i}:8-15`,
            title: "Central Themes",
            content: `This section explores the central theological themes presented in Romans ${i}, with Henry's characteristic focus on the moral and spiritual implications for believers. He addresses common misconceptions and provides clear explanations.`
          },
          {
            verses: `${i}:16-end`,
            title: "Concluding Thoughts",
            content: `Henry concludes his commentary on Romans ${i} with practical applications and devotional insights, connecting the ancient text to modern Christian experience and discipleship.`
          }
        ],
        keyThemes: chapterSpecificThemes[i as keyof typeof chapterSpecificThemes] || ["Practical faith", "Christian living", "Gospel application", "Moral instruction"]
      });
    }
    return chapters;
  }

  private generateCalvinChapters() {
    const chapters = [];
    const chapterSpecificThemes = {
      1: ["Divine revelation", "Gospel power", "Human depravity", "God's wrath"],
      2: ["Divine judgment", "Law's function", "Circumcision's meaning", "God's impartiality"],
      3: ["Universal sinfulness", "God's righteousness", "Justification by faith", "Law's purpose"],
      4: ["Abraham's faith", "Promise vs. works", "Faith credited", "Circumcision sign"],
      5: ["Peace with God", "Adam's sin", "Christ's obedience", "Grace abundance"],
      6: ["Union with Christ", "Death to sin", "Baptism meaning", "Sin's bondage"],
      7: ["Law's bondage", "Flesh vs. spirit", "Sin's deceit", "Inner conflict"],
      8: ["No condemnation", "Spirit's indwelling", "Adoption", "Future glory"],
      9: ["Divine sovereignty", "Election doctrine", "Potter's rights", "Vessels of mercy"],
      10: ["Israel's zeal", "Christ as end", "Faith confession", "Gospel preaching"],
      11: ["Israel's remnant", "Gentile ingrafting", "Divine mystery", "God's mercy"],
      12: ["Living sacrifice", "Mind renewal", "Body unity", "Spiritual gifts"],
      13: ["Civil authority", "Love fulfillment", "Eschatological urgency", "Christian conduct"],
      14: ["Weak conscience", "Liberty limits", "Judgment restraint", "Building up"],
      15: ["Strong's duty", "Christ's example", "Unity purpose", "Missionary calling"],
      16: ["Ministry partnership", "Church greetings", "False teachers", "Divine wisdom"]
    };

    for (let i = 1; i <= 16; i++) {
      chapters.push({
        chapter: i,
        title: `Calvin's Commentary on Romans ${i}`,
        introduction: `John Calvin's systematic theological exposition of Romans chapter ${i}, emphasizing God's sovereignty and the doctrines of grace.`,
        sections: [
          {
            verses: `${i}:1-8`,
            title: "Doctrinal Foundation",
            content: `Calvin's rigorous theological analysis of Romans ${i}, focusing on the sovereignty of God and the total depravity of humanity. He provides detailed exegesis with attention to the original Greek text and patristic sources.`
          },
          {
            verses: `${i}:9-16`,
            title: "Systematic Exposition",
            content: `This section presents Calvin's systematic approach to understanding Paul's argument in Romans ${i}, with careful attention to logical progression and doctrinal implications for Reformed theology.`
          }
        ],
        keyThemes: chapterSpecificThemes[i as keyof typeof chapterSpecificThemes] || ["Reformed theology", "Biblical exegesis", "Divine grace", "Systematic doctrine"]
      });
    }
    return chapters;
  }

  private generateBarnesChapters() {
    const chapters = [];
    const chapterSpecificThemes = {
      1: ["Gospel necessity", "Natural knowledge", "Sin's progression", "Divine justice"],
      2: ["Impartial judgment", "Law's universality", "Heart circumcision", "Religious privilege"],
      3: ["Universal guilt", "Divine justice", "Faith righteousness", "Law's honor"],
      4: ["Faith's nature", "Abraham's example", "Promise fulfillment", "Grace certainty"],
      5: ["Justified peace", "Sin's origin", "Death's reign", "Grace abundance"],
      6: ["Sin's dominion", "Grace boundaries", "Newness of life", "Righteous service"],
      7: ["Law's release", "Sin's occasion", "Conscience conflict", "Law's spirituality"],
      8: ["Condemnation removal", "Spirit's law", "Sonship privileges", "Glory hope"],
      9: ["Sovereign choice", "Mercy vessels", "Calling purpose", "Remnant doctrine"],
      10: ["Heart righteousness", "Universal access", "Preaching necessity", "Hearing importance"],
      11: ["Partial blindness", "Gentile grafting", "Future restoration", "Inscrutable ways"],
      12: ["Reasonable service", "Humble assessment", "Diverse gifts", "Genuine love"],
      13: ["Civil obedience", "Love's fulfillment", "Moral urgency", "Christ's armor"],
      14: ["Conscience respect", "Liberty limits", "Peace priority", "Edification focus"],
      15: ["Strong's obligation", "Scriptural encouragement", "Unity blessing", "Gentile inclusion"],
      16: ["Ministry appreciation", "Church unity", "False teacher identification", "Triumphant grace"]
    };

    for (let i = 1; i <= 16; i++) {
      chapters.push({
        chapter: i,
        title: `Barnes' Notes on Romans ${i}`,
        introduction: `Albert Barnes provides practical, pastoral commentary on Romans chapter ${i} with emphasis on application for Christian living.`,
        sections: [
          {
            verses: `${i}:1-10`,
            title: "Pastoral Application",
            content: `Barnes offers practical insights into Romans ${i} with a focus on how these truths should shape Christian character and conduct in daily life.`
          }
        ],
        keyThemes: chapterSpecificThemes[i as keyof typeof chapterSpecificThemes] || ["Practical holiness", "Christian character", "Gospel transformation", "Faithful living"]
      });
    }
    return chapters;
  }

  private generateChrysostomChapters() {
    const chapters = [];
    const chapterSpecificThemes = {
      1: ["Divine calling", "Gospel shame", "Thankful service", "Mutual comfort"],
      2: ["Universal judgment", "Law transgression", "Outward ceremony", "Heart reality"],
      3: ["Faithful advantage", "Sin's universality", "Redemption cost", "Faith's nature"],
      4: ["Abraham's glory", "Faith's reward", "Promise certainty", "Circumcision purpose"],
      5: ["Access to grace", "Tribulation joy", "Death's entrance", "Life's gift"],
      6: ["Death to sin", "Grace increase", "Baptismal teaching", "Slavery choice"],
      7: ["Marriage analogy", "Sin's revival", "Law's goodness", "Flesh weakness"],
      8: ["Spirit's power", "Suffering's purpose", "Creation's groaning", "Intercession help"],
      9: ["Sovereign mercy", "Vessel honor", "Calling righteousness", "Stone of stumbling"],
      10: ["Zealous ignorance", "Christ's fulfillment", "Word's nearness", "Beautiful feet"],
      11: ["Remnant preservation", "Branch grafting", "Root support", "All Israel"],
      12: ["Spiritual sacrifice", "Gift diversity", "Love sincerity", "Enemy kindness"],
      13: ["Authority honor", "Love's debt", "Time's urgency", "Light's armor"],
      14: ["Faith receiving", "Conscience honoring", "Peace making", "Building up"],
      15: ["Burden bearing", "Scripture learning", "Unity maintaining", "Gentile blessing"],
      16: ["Worker greeting", "Church service", "False teacher warning", "Grace closing"]
    };

    for (let i = 1; i <= 16; i++) {
      chapters.push({
        chapter: i,
        title: `Chrysostom's Homily on Romans ${i}`,
        introduction: `John Chrysostom's eloquent homiletical treatment of Romans chapter ${i}, known for his golden-tongued preaching style.`,
        sections: [
          {
            verses: `${i}:1-12`,
            title: "Homiletical Exposition",
            content: `Chrysostom's masterful oratorical treatment of Romans ${i}, combining theological depth with rhetorical excellence to illuminate Paul's teachings.`
          }
        ],
        keyThemes: chapterSpecificThemes[i as keyof typeof chapterSpecificThemes] || ["Eloquent preaching", "Moral instruction", "Patristic wisdom", "Spiritual formation"]
      });
    }
    return chapters;
  }

  private generateClarkeChapters() {
    const chapters = [];
    const chapterSpecificThemes = {
      1: ["Apostolic authority", "Gospel definition", "Natural theology", "Condemnation process"],
      2: ["Moral judgment", "Law advantages", "Circumcision value", "Divine consistency"],
      3: ["Jewish advantage", "God's truthfulness", "Propitiation meaning", "Faith alone"],
      4: ["Imputed righteousness", "Faith's object", "Promise mode", "Seal significance"],
      5: ["Justified benefits", "Reconciliation", "Original sin", "Second Adam"],
      6: ["Antinomianism refuted", "Spiritual death", "Baptismal symbolism", "Master choice"],
      7: ["Law's dominion", "Sin's operation", "Conscience war", "Law's character"],
      8: ["Liberation", "Flesh definition", "Sonship evidence", "Glorification process"],
      9: ["Israel's privileges", "Absolute sovereignty", "Mercy vessels", "Stumbling stone"],
      10: ["Righteousness types", "Law's end", "Confession importance", "Missionary necessity"],
      11: ["Rejection purpose", "Grafting process", "Restoration timing", "Wisdom depth"],
      12: ["Body metaphor", "Gift enumeration", "Christian duties", "Persecution response"],
      13: ["Government origin", "Conscience obligation", "Love summary", "Eschaton nearness"],
      14: ["Liberty exercise", "Judgment abstinence", "Peace pursuit", "Edification priority"],
      15: ["Strong obligations", "Christ's example", "Missionary spirit", "Church unity"],
      16: ["Personal commendations", "Ministry roles", "Heresy warning", "Final blessing"]
    };

    for (let i = 1; i <= 16; i++) {
      chapters.push({
        chapter: i,
        title: `Clarke's Commentary on Romans ${i}`,
        introduction: `Adam Clarke's scholarly commentary on Romans chapter ${i}, featuring linguistic analysis and historical context.`,
        sections: [
          {
            verses: `${i}:1-15`,
            title: "Linguistic Analysis",
            content: `Clarke provides detailed analysis of the Greek text of Romans ${i}, offering insights into word meanings and grammatical structures that illuminate Paul's intended meaning.`
          }
        ],
        keyThemes: chapterSpecificThemes[i as keyof typeof chapterSpecificThemes] || ["Textual analysis", "Historical context", "Linguistic insights", "Scholarly exposition"]
      });
    }
    return chapters;
  }

  async getCommentaries(): Promise<Commentary[]> {
    return Array.from(this.commentaries.values());
  }

  async getCommentary(id: number): Promise<Commentary | undefined> {
    return this.commentaries.get(id);
  }

  async getCommentaryChapter(id: number, chapter: number): Promise<any> {
    const commentary = this.commentaries.get(id);
    if (!commentary) return undefined;
    
    const chapters = commentary.chapters as any[];
    return chapters.find(ch => ch.chapter === chapter);
  }

  async searchCommentaries(query: string, commentaryId?: number): Promise<any[]> {
    const results = [];
    const searchTerm = query.toLowerCase();

    for (const commentary of Array.from(this.commentaries.values())) {
      if (commentaryId && commentary.id !== commentaryId) continue;

      const chapters = commentary.chapters as any[];
      for (const chapter of chapters) {
        const titleMatch = chapter.title.toLowerCase().includes(searchTerm);
        const introMatch = chapter.introduction.toLowerCase().includes(searchTerm);
        const contentMatch = chapter.sections.some((section: any) => 
          section.content.toLowerCase().includes(searchTerm)
        );
        const themeMatch = chapter.keyThemes.some((theme: string) =>
          theme.toLowerCase().includes(searchTerm)
        );

        if (titleMatch || introMatch || contentMatch || themeMatch) {
          results.push({
            commentaryId: commentary.id,
            commentaryAuthor: commentary.author,
            commentaryTitle: commentary.title,
            chapter: chapter.chapter,
            chapterTitle: chapter.title,
            matchType: titleMatch ? 'title' : introMatch ? 'introduction' : contentMatch ? 'content' : 'theme'
          });
        }
      }
    }

    return results;
  }

  async getBookmarks(userId: string): Promise<Bookmark[]> {
    return Array.from(this.bookmarks.values()).filter(b => b.userId === userId);
  }

  async addBookmark(bookmark: InsertBookmark): Promise<Bookmark> {
    const id = this.currentBookmarkId++;
    const newBookmark: Bookmark = { ...bookmark, id };
    this.bookmarks.set(id, newBookmark);
    return newBookmark;
  }

  async removeBookmark(userId: string, commentaryId: number, chapter: number): Promise<void> {
    for (const [id, bookmark] of Array.from(this.bookmarks.entries())) {
      if (bookmark.userId === userId && bookmark.commentaryId === commentaryId && bookmark.chapter === chapter) {
        this.bookmarks.delete(id);
        break;
      }
    }
  }

  async isBookmarked(userId: string, commentaryId: number, chapter: number): Promise<boolean> {
    return Array.from(this.bookmarks.values()).some(
      b => b.userId === userId && b.commentaryId === commentaryId && b.chapter === chapter
    );
  }

  private initializeTheologicalThemes() {
    this.theologicalThemes = [
      {
        id: "justification-by-faith",
        title: "Justification by Faith Alone",
        description: "The doctrine that humans are justified before God through faith alone, not by works of the law.",
        keyVerses: ["Romans 3:28", "Romans 4:5", "Romans 5:1"],
        relatedChapters: [3, 4, 5],
        category: "soteriology"
      },
      {
        id: "righteousness-of-god",
        title: "Righteousness of God",
        description: "God's perfect moral character and His gift of righteousness to believers through Christ.",
        keyVerses: ["Romans 1:17", "Romans 3:21-22", "Romans 10:3"],
        relatedChapters: [1, 3, 9, 10],
        category: "theology"
      },
      {
        id: "atonement-understanding",
        title: "Understanding of Atonement",
        description: "Christ's sacrificial death as propitiation for sin and reconciliation between God and humanity.",
        keyVerses: ["Romans 3:25", "Romans 5:10-11", "Romans 8:32"],
        relatedChapters: [3, 5, 8],
        category: "soteriology"
      },
      {
        id: "old-testament-echoes",
        title: "Echoes of Old Testament in Romans",
        description: "Paul's extensive use of Old Testament scriptures to support his theological arguments.",
        keyVerses: ["Romans 4:3", "Romans 9:25-26", "Romans 15:9-12"],
        relatedChapters: [4, 9, 10, 11, 15],
        category: "theology"
      },
      {
        id: "romans-7-self",
        title: "Romans 7 and the Understanding of 'Self'",
        description: "The complex relationship between the believer, sin, and the law as described in Romans 7.",
        keyVerses: ["Romans 7:15", "Romans 7:24-25"],
        relatedChapters: [7],
        category: "anthropology"
      },
      {
        id: "origins-of-sin",
        title: "Origins of Sin",
        description: "The entrance of sin into the world through Adam and its universal effects on humanity.",
        keyVerses: ["Romans 5:12", "Romans 1:18-32", "Romans 3:23"],
        relatedChapters: [1, 3, 5],
        category: "anthropology"
      },
      {
        id: "law-of-moses",
        title: "The Law of Moses",
        description: "The role and purpose of the Mosaic Law in relation to sin, righteousness, and salvation.",
        keyVerses: ["Romans 3:20", "Romans 7:7", "Romans 10:4"],
        relatedChapters: [2, 3, 7, 10],
        category: "theology"
      },
      {
        id: "gospel-of-god",
        title: "The Gospel of God",
        description: "The good news of salvation through Jesus Christ as the power of God for salvation.",
        keyVerses: ["Romans 1:1", "Romans 1:16", "Romans 15:16"],
        relatedChapters: [1, 15, 16],
        category: "soteriology"
      },
      {
        id: "mortification-of-sins",
        title: "Mortification of Sins by the Spirit",
        description: "The Holy Spirit's role in putting to death the deeds of the body and sanctification.",
        keyVerses: ["Romans 8:13", "Romans 6:11", "Romans 12:1"],
        relatedChapters: [6, 8, 12],
        category: "pneumatology"
      },
      {
        id: "righteous-vs-wicked",
        title: "Righteous vs. Wicked",
        description: "The distinction between the righteous and the wicked in God's judgment and mercy.",
        keyVerses: ["Romans 1:17", "Romans 2:5-8", "Romans 3:10"],
        relatedChapters: [1, 2, 3],
        category: "anthropology"
      },
      {
        id: "place-of-israel",
        title: "Place of Israel in Salvation",
        description: "God's covenant faithfulness to Israel and their role in salvation history.",
        keyVerses: ["Romans 9:4-5", "Romans 11:1", "Romans 11:26"],
        relatedChapters: [9, 10, 11],
        category: "ecclesiology"
      },
      {
        id: "election-predestination",
        title: "Election and Predestination",
        description: "God's sovereign choice in salvation and His eternal purposes for His people.",
        keyVerses: ["Romans 8:29-30", "Romans 9:11", "Romans 11:5"],
        relatedChapters: [8, 9, 11],
        category: "theology"
      },
      {
        id: "union-with-christ",
        title: "Union with Christ",
        description: "The believer's identification with Christ in His death, burial, and resurrection.",
        keyVerses: ["Romans 6:3-4", "Romans 6:11", "Romans 8:1"],
        relatedChapters: [6, 8],
        category: "soteriology"
      },
      {
        id: "sanctification",
        title: "Progressive Sanctification",
        description: "The ongoing process of being conformed to the image of Christ through the Spirit.",
        keyVerses: ["Romans 8:29", "Romans 12:2", "Romans 6:22"],
        relatedChapters: [6, 8, 12],
        category: "pneumatology"
      },
      {
        id: "spiritual-gifts",
        title: "Spiritual Gifts and Service",
        description: "The diversity of gifts given by God for the building up of the body of Christ.",
        keyVerses: ["Romans 12:3-8", "Romans 1:11"],
        relatedChapters: [12, 1],
        category: "ecclesiology"
      },
      {
        id: "christian-liberty",
        title: "Christian Liberty and Conscience",
        description: "Freedom in Christ and the importance of not causing others to stumble.",
        keyVerses: ["Romans 14:1-4", "Romans 14:13", "Romans 14:22"],
        relatedChapters: [14],
        category: "ecclesiology"
      },
      {
        id: "wrath-of-god",
        title: "Wrath of God",
        description: "God's righteous anger against sin and His judgment upon unrighteousness.",
        keyVerses: ["Romans 1:18", "Romans 2:5", "Romans 9:22"],
        relatedChapters: [1, 2, 9],
        category: "theology"
      },
      {
        id: "grace-mercy",
        title: "Grace and Mercy",
        description: "God's unmerited favor and compassion shown to undeserving sinners.",
        keyVerses: ["Romans 3:24", "Romans 5:2", "Romans 9:15"],
        relatedChapters: [3, 5, 9, 11],
        category: "theology"
      },
      {
        id: "adoption-sonship",
        title: "Adoption and Sonship",
        description: "Believers being adopted as children of God through the Spirit of adoption.",
        keyVerses: ["Romans 8:15", "Romans 8:23", "Romans 9:4"],
        relatedChapters: [8, 9],
        category: "soteriology"
      },
      {
        id: "glorification",
        title: "Future Glorification",
        description: "The ultimate transformation and glorification of believers in the resurrection.",
        keyVerses: ["Romans 8:17", "Romans 8:30", "Romans 8:18"],
        relatedChapters: [8],
        category: "eschatology"
      },
      {
        id: "creation-renewal",
        title: "Creation's Renewal",
        description: "The cosmic scope of redemption including the liberation of creation itself.",
        keyVerses: ["Romans 8:19-22"],
        relatedChapters: [8],
        category: "eschatology"
      },
      {
        id: "gentile-inclusion",
        title: "Gentile Inclusion in Salvation",
        description: "The inclusion of non-Jewish peoples in God's covenant through faith in Christ.",
        keyVerses: ["Romans 1:16", "Romans 3:29", "Romans 15:9-12"],
        relatedChapters: [1, 3, 9, 10, 11, 15],
        category: "ecclesiology"
      },
      {
        id: "faith-works",
        title: "Faith vs. Works",
        description: "The contrast between righteousness by faith and attempts at righteousness through works.",
        keyVerses: ["Romans 3:28", "Romans 4:4-5", "Romans 9:32"],
        relatedChapters: [3, 4, 9, 10],
        category: "soteriology"
      },
      {
        id: "christian-ethics",
        title: "Christian Ethics and Living",
        description: "Practical guidelines for Christian conduct and relationship with others.",
        keyVerses: ["Romans 12:9-21", "Romans 13:8-10"],
        relatedChapters: [12, 13, 14, 15],
        category: "anthropology"
      },
      {
        id: "government-authority",
        title: "Government and Civil Authority",
        description: "The Christian's relationship to governing authorities as established by God.",
        keyVerses: ["Romans 13:1-7"],
        relatedChapters: [13],
        category: "anthropology"
      },
      {
        id: "suffering-hope",
        title: "Suffering and Christian Hope",
        description: "The role of suffering in the Christian life and the hope of future glory.",
        keyVerses: ["Romans 5:3-5", "Romans 8:17-18", "Romans 8:28"],
        relatedChapters: [5, 8],
        category: "eschatology"
      },
      {
        id: "perseverance-saints",
        title: "Perseverance of the Saints",
        description: "The security of believers and God's preservation of those whom He has called.",
        keyVerses: ["Romans 8:35-39", "Romans 11:29"],
        relatedChapters: [8, 11],
        category: "soteriology"
      },
      {
        id: "trinity-godhead",
        title: "Trinity and the Godhead",
        description: "References to the Father, Son, and Holy Spirit working in salvation and sanctification.",
        keyVerses: ["Romans 8:9-11", "Romans 15:30"],
        relatedChapters: [1, 8, 15],
        category: "theology"
      },
      {
        id: "word-preaching",
        title: "The Word and Preaching",
        description: "The centrality of the proclaimed word in bringing about faith and salvation.",
        keyVerses: ["Romans 10:14-17", "Romans 1:16"],
        relatedChapters: [1, 10, 15],
        category: "ecclesiology"
      },
      {
        id: "love-christian-community",
        title: "Love in Christian Community",
        description: "Love as the fulfillment of the law and the bond of Christian fellowship.",
        keyVerses: ["Romans 13:8-10", "Romans 12:9-10", "Romans 14:15"],
        relatedChapters: [12, 13, 14, 15],
        category: "ecclesiology"
      },
      {
        id: "flesh-spirit-conflict",
        title: "Flesh vs. Spirit Conflict",
        description: "The ongoing tension between the flesh and the Spirit in the believer's life.",
        keyVerses: ["Romans 7:14-25", "Romans 8:5-8"],
        relatedChapters: [7, 8],
        category: "pneumatology"
      },
      {
        id: "cosmic-christ",
        title: "Cosmic Lordship of Christ",
        description: "Christ's universal authority and lordship over all creation and history.",
        keyVerses: ["Romans 14:9", "Romans 10:12", "Romans 15:12"],
        relatedChapters: [10, 14, 15],
        category: "theology"
      },
      {
        id: "dikaios-righteousness",
        title: "Δίκαιος (Dikaios) - The Righteous One",
        description: "From BDAG: 'Pertaining to being in accordance with high moral and legal standards, upright, just, fair.' In Romans, refers to God's perfect character and the believer's status through faith-righteousness.",
        keyVerses: ["Romans 1:17", "Romans 3:10", "Romans 5:19"],
        relatedChapters: [1, 3, 5],
        category: "theology"
      },
      {
        id: "dikaiosune-theou",
        title: "Δικαιοσύνη Θεοῦ (Dikaiosyne Theou) - Righteousness of God",
        description: "Contemporary scholarship (N.T. Wright, Michael Bird) interprets this as God's covenant faithfulness and saving action, not merely forensic imputation. Both God's character and His activity in making things right.",
        keyVerses: ["Romans 1:17", "Romans 3:21-22", "Romans 10:3"],
        relatedChapters: [1, 3, 10],
        category: "theology"
      },
      {
        id: "hamartia-sin",
        title: "Ἁμαρτία (Hamartia) - Sin as Power",
        description: "BDAG: 'A departure from either human or divine standards of uprightness.' Recent research emphasizes sin as a cosmic power/force in Romans, not just individual moral failure. Paul personifies sin as a ruling tyrant (Rom 6:12-14).",
        keyVerses: ["Romans 3:23", "Romans 5:12", "Romans 6:23", "Romans 7:17"],
        relatedChapters: [3, 5, 6, 7],
        category: "anthropology"
      },
      {
        id: "telos-fulfillment",
        title: "Τέλος (Telos) - Goal/Fulfillment",
        description: "BDAG: 'The point toward which a movement is directed, end, goal, outcome.' In Romans 10:4, scholars debate whether Christ is the 'end' (termination) or 'goal' (fulfillment) of the Law. Contemporary research favors 'goal.'",
        keyVerses: ["Romans 10:4", "Romans 6:21-22"],
        relatedChapters: [6, 10],
        category: "theology"
      },
      {
        id: "dikaioma-righteous-act",
        title: "Δικαίωμα (Dikaioma) - Righteous Act/Ordinance",
        description: "Sebastian Schmidt's distinction: 'a justifying righteousness which came to all men' (Rom 5:18). Contemporary lexicography defines it as 'regulation, requirement, commandment' or 'act of righteousness.' Context determines meaning.",
        keyVerses: ["Romans 5:16", "Romans 5:18", "Romans 8:4"],
        relatedChapters: [5, 8],
        category: "soteriology"
      },
      {
        id: "dikaiosis-justification",
        title: "Δικαίωσις (Dikaiosis) - Justification/Acquittal",
        description: "BDAG: 'the act of pronouncing righteous, justification, acquittal.' Distinguished from dikaioma as 'the very act of justification whereby God justifies us' (Schmidt). Appears only in Romans 4:25; 5:18.",
        keyVerses: ["Romans 4:25", "Romans 5:18"],
        relatedChapters: [4, 5],
        category: "soteriology"
      },
      {
        id: "pistis-faith",
        title: "Πίστις (Pistis) - Faith/Faithfulness",
        description: "The Greek word for faith, trust, or faithfulness - central to Paul's theology of justification.",
        keyVerses: ["Romans 1:17", "Romans 3:22", "Romans 4:5", "Romans 10:17"],
        relatedChapters: [1, 3, 4, 10],
        category: "soteriology"
      },
      {
        id: "charis-grace",
        title: "Χάρις (Charis) - Grace",
        description: "God's unmerited favor and kindness toward sinners, the foundation of salvation.",
        keyVerses: ["Romans 3:24", "Romans 5:2", "Romans 6:14", "Romans 11:6"],
        relatedChapters: [3, 5, 6, 11],
        category: "soteriology"
      },
      {
        id: "nomos-law",
        title: "Νόμος (Nomos) - Law",
        description: "The Greek term for law, including the Mosaic Law, natural law, and the principle of law.",
        keyVerses: ["Romans 2:14", "Romans 3:20", "Romans 7:7", "Romans 8:2"],
        relatedChapters: [2, 3, 7, 8],
        category: "theology"
      },
      {
        id: "sarx-flesh",
        title: "Σάρξ (Sarx) - Flesh",
        description: "The fallen human nature opposed to God's Spirit, the seat of sinful desires and weakness.",
        keyVerses: ["Romans 7:18", "Romans 8:3-8", "Romans 13:14"],
        relatedChapters: [7, 8, 13],
        category: "anthropology"
      },
      {
        id: "pneuma-spirit",
        title: "Πνεῦμα (Pneuma) - Spirit",
        description: "The Holy Spirit of God and the renewed human spirit, contrasted with the flesh.",
        keyVerses: ["Romans 8:1-16", "Romans 1:4", "Romans 15:16"],
        relatedChapters: [1, 8, 15],
        category: "pneumatology"
      },
      {
        id: "katallage-reconciliation",
        title: "Καταλλαγή (Katallage) - Reconciliation",
        description: "The restoration of relationship between God and humanity through Christ's atoning work.",
        keyVerses: ["Romans 5:11", "Romans 11:15"],
        relatedChapters: [5, 11],
        category: "soteriology"
      },
      {
        id: "hilasterion-propitiation",
        title: "Ἱλαστήριον (Hilasterion) - Propitiation",
        description: "Christ as the mercy seat, the place where God's wrath is satisfied and mercy is shown.",
        keyVerses: ["Romans 3:25"],
        relatedChapters: [3],
        category: "soteriology"
      },
      {
        id: "koinonia-fellowship",
        title: "Κοινωνία (Koinonia) - Fellowship/Participation",
        description: "Spiritual fellowship and participation in Christ's sufferings and the community of faith.",
        keyVerses: ["Romans 15:26-27"],
        relatedChapters: [15],
        category: "ecclesiology"
      },
      {
        id: "doxa-glory",
        title: "Δόξα (Doxa) - Glory",
        description: "The divine glory, honor, and majesty of God that believers have fallen short of and hope to share.",
        keyVerses: ["Romans 3:23", "Romans 5:2", "Romans 8:18", "Romans 8:30"],
        relatedChapters: [3, 5, 8],
        category: "eschatology"
      },
      {
        id: "ekklesia-church",
        title: "Ἐκκλησία (Ekklesia) - Church/Assembly",
        description: "BDAG: 'A regularly summoned political body, assembly.' From ek (out) + kaleo (call). The called-out assembly of believers, emphasizing both local gatherings and universal church in Romans 16.",
        keyVerses: ["Romans 16:1", "Romans 16:5", "Romans 16:16"],
        relatedChapters: [16],
        category: "ecclesiology"
      },
      {
        id: "logikos-reasonable",
        title: "Λογικός (Logikos) - Reasonable/Rational",
        description: "BDAG: 'Pertaining to being in accordance with reason, reasonable, rational.' In Romans 12:1, describes worship as 'reasonable service.' Contemporary research links this to Stoic philosophy and rational devotion to God.",
        keyVerses: ["Romans 12:1"],
        relatedChapters: [12],
        category: "anthropology"
      },
      {
        id: "prothesis-purpose",
        title: "Πρόθεσις (Prothesis) - Divine Purpose",
        description: "BDAG: 'A plan that one has in mind, purpose, resolve, will.' In Romans 8:28; 9:11, refers to God's eternal purpose in election. N.T. Wright emphasizes its covenantal rather than merely individual significance.",
        keyVerses: ["Romans 8:28", "Romans 9:11"],
        relatedChapters: [8, 9],
        category: "theology"
      },
      {
        id: "apokalupsis-revelation",
        title: "Ἀποκάλυψις (Apokalupsis) - Revelation",
        description: "BDAG: 'Making fully known, revelation, disclosure.' Paul uses this for the revelation of God's righteousness (1:17), wrath (1:18), and future glory (8:18). Emphasizes the unveiling of divine mystery.",
        keyVerses: ["Romans 1:17", "Romans 1:18", "Romans 8:18"],
        relatedChapters: [1, 8],
        category: "theology"
      },
      {
        id: "katakrima-condemnation",
        title: "Κατάκριμα (Katakrima) - Condemnation",
        description: "BDAG: 'The punishment that follows condemnation, condemnation.' Contrasted with dikaiosis (justification) in Romans 5:16,18. Represents the judicial verdict of guilt and its consequences.",
        keyVerses: ["Romans 5:16", "Romans 5:18", "Romans 8:1"],
        relatedChapters: [5, 8],
        category: "anthropology"
      },
      {
        id: "soma-body",
        title: "Σῶμα (Soma) - Body",
        description: "BDAG: 'The physical body of persons or animals.' In Romans, both literal body and metaphorical (body of sin, body of Christ). Contemporary research emphasizes embodied theology rather than Greek dualism.",
        keyVerses: ["Romans 6:6", "Romans 7:24", "Romans 12:1", "Romans 12:5"],
        relatedChapters: [6, 7, 12],
        category: "anthropology"
      },
      {
        id: "paradosis-tradition",
        title: "Παράδοσις (Paradosis) - Tradition/Handing Down",
        description: "BDAG: 'The content of instruction that has been handed down, tradition.' While not frequently used in Romans, the concept underlies Paul's gospel transmission and ethical instruction patterns.",
        keyVerses: ["Romans 6:17"],
        relatedChapters: [6],
        category: "ecclesiology"
      },
      {
        id: "klesis-calling",
        title: "Κλῆσις (Klesis) - Calling/Vocation",
        description: "BDAG: 'A calling to a particular mode of life or conduct, calling, vocation.' Paul's emphasis on divine calling in Romans connects to both salvation and service. Recent scholarship emphasizes missional implications.",
        keyVerses: ["Romans 11:29"],
        relatedChapters: [11],
        category: "soteriology"
      },
      {
        id: "mysterion-mystery",
        title: "Μυστήριον (Mysterion) - Mystery",
        description: "BDAG: 'The unmanifest or private counsel of God, (divine) mystery, secret.' In Romans 11:25, refers to Israel's partial hardening. Contemporary research emphasizes apocalyptic revelation rather than Hellenistic mystery religions.",
        keyVerses: ["Romans 11:25", "Romans 16:25"],
        relatedChapters: [11, 16],
        category: "eschatology"
      },
      {
        id: "syneidos-conscience",
        title: "Συνείδησις (Syneidesis) - Conscience",
        description: "BDAG: 'The inward faculty of distinguishing right and wrong, moral consciousness, conscience.' Paul's usage in Romans 2:15 shows Gentiles have internal moral awareness. Links to natural law theory in contemporary ethics.",
        keyVerses: ["Romans 2:15"],
        relatedChapters: [2],
        category: "anthropology"
      }
    ];
  }

  async getTheologicalThemes(): Promise<TheologicalTheme[]> {
    return this.theologicalThemes;
  }

  async searchThemes(query: string): Promise<TheologicalTheme[]> {
    const searchTerm = query.toLowerCase();
    return this.theologicalThemes.filter(theme =>
      theme.title.toLowerCase().includes(searchTerm) ||
      theme.description.toLowerCase().includes(searchTerm) ||
      theme.keyVerses.some(verse => verse.toLowerCase().includes(searchTerm))
    );
  }

  async getThemesByCategory(category: string): Promise<TheologicalTheme[]> {
    return this.theologicalThemes.filter(theme => theme.category === category);
  }
}

export const storage = new MemStorage();
