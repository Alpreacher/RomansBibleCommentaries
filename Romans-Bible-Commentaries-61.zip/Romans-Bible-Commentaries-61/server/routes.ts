import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertBookmarkSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all commentaries
  app.get("/api/commentaries", async (req, res) => {
    try {
      const commentaries = await storage.getCommentaries();
      res.json(commentaries);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch commentaries" });
    }
  });

  // Get specific commentary
  app.get("/api/commentaries/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const commentary = await storage.getCommentary(id);
      
      if (!commentary) {
        return res.status(404).json({ message: "Commentary not found" });
      }
      
      res.json(commentary);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch commentary" });
    }
  });

  // Get commentary chapter
  app.get("/api/commentaries/:id/chapters/:chapter", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const chapter = parseInt(req.params.chapter);
      
      if (chapter < 1 || chapter > 16) {
        return res.status(400).json({ message: "Chapter must be between 1 and 16" });
      }
      
      const chapterContent = await storage.getCommentaryChapter(id, chapter);
      
      if (!chapterContent) {
        return res.status(404).json({ message: "Chapter not found" });
      }
      
      res.json(chapterContent);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch chapter" });
    }
  });

  // Search commentaries
  app.get("/api/search", async (req, res) => {
    try {
      const { q: query, commentary } = req.query;
      
      if (!query || typeof query !== 'string') {
        return res.status(400).json({ message: "Query parameter 'q' is required" });
      }
      
      const commentaryId = commentary ? parseInt(commentary as string) : undefined;
      const results = await storage.searchCommentaries(query, commentaryId);
      
      res.json(results);
    } catch (error) {
      res.status(500).json({ message: "Search failed" });
    }
  });

  // Get user bookmarks
  app.get("/api/bookmarks", async (req, res) => {
    try {
      const userId = req.query.userId as string || "anonymous";
      const bookmarks = await storage.getBookmarks(userId);
      res.json(bookmarks);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch bookmarks" });
    }
  });

  // Add bookmark
  app.post("/api/bookmarks", async (req, res) => {
    try {
      const validatedData = insertBookmarkSchema.parse(req.body);
      const bookmark = await storage.addBookmark(validatedData);
      res.status(201).json(bookmark);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid bookmark data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to add bookmark" });
    }
  });

  // Remove bookmark
  app.delete("/api/bookmarks", async (req, res) => {
    try {
      const { userId = "anonymous", commentaryId, chapter } = req.query;
      
      if (!commentaryId || !chapter) {
        return res.status(400).json({ message: "commentaryId and chapter are required" });
      }
      
      await storage.removeBookmark(
        userId as string,
        parseInt(commentaryId as string),
        parseInt(chapter as string)
      );
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to remove bookmark" });
    }
  });

  // Check if bookmarked
  app.get("/api/bookmarks/check", async (req, res) => {
    try {
      const { userId = "anonymous", commentaryId, chapter } = req.query;
      
      if (!commentaryId || !chapter) {
        return res.status(400).json({ message: "commentaryId and chapter are required" });
      }
      
      const isBookmarked = await storage.isBookmarked(
        userId as string,
        parseInt(commentaryId as string),
        parseInt(chapter as string)
      );
      
      res.json({ isBookmarked });
    } catch (error) {
      res.status(500).json({ message: "Failed to check bookmark status" });
    }
  });

  // Get all theological themes
  app.get("/api/themes", async (req, res) => {
    try {
      const themes = await storage.getTheologicalThemes();
      res.json(themes);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch theological themes" });
    }
  });

  // Search theological themes
  app.get("/api/themes/search", async (req, res) => {
    try {
      const { q: query } = req.query;
      
      if (!query || typeof query !== 'string') {
        return res.status(400).json({ message: "Query parameter 'q' is required" });
      }
      
      const themes = await storage.searchThemes(query);
      res.json(themes);
    } catch (error) {
      res.status(500).json({ message: "Theme search failed" });
    }
  });

  // Get themes by category
  app.get("/api/themes/category/:category", async (req, res) => {
    try {
      const { category } = req.params;
      const themes = await storage.getThemesByCategory(category);
      res.json(themes);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch themes by category" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
