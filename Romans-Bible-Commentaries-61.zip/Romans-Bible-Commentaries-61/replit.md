# Biblical Commentary Reader

## Overview

This is a full-stack web application for reading and interacting with biblical commentaries, specifically focused on the book of Romans. The application provides a clean, responsive interface for browsing different commentary sources, reading chapter-by-chapter content, and managing bookmarks.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a modern full-stack architecture with clear separation between frontend, backend, and data layers:

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **UI Library**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **State Management**: TanStack Query for server state and caching
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript with ES modules
- **API Style**: RESTful endpoints under `/api` prefix
- **Database ORM**: Drizzle ORM with PostgreSQL dialect
- **Database Provider**: Neon serverless PostgreSQL
- **Session Management**: PostgreSQL-based sessions with connect-pg-simple

### Data Storage
- **Primary Database**: PostgreSQL (configured for Neon serverless)
- **Schema Management**: Drizzle migrations in `./migrations` directory
- **Development Storage**: In-memory storage implementation for development/testing

## Key Components

### Database Schema
- **Commentaries Table**: Stores commentary metadata (author, title, description, year) and chapter content as JSONB
- **Bookmarks Table**: User bookmarks linking commentary ID, chapter number, and user ID
- **Theological Themes**: 47 comprehensive themes including 15 authentic Koine Greek terms with BDAG lexicon definitions

### Recent Enhancements (July 20, 2025)

#### Enhanced Color Scheme System
- **Multiple Theme Options**: Added 5 comprehensive color schemes including Replit-style navy theme
- **Light Theme**: Clean, bright interface optimized for daytime reading
- **Dark Theme**: Improved high-contrast dark mode with better text legibility
- **Navy Blue Theme**: Replit-inspired deep blue background with professional styling
- **Slate Theme**: Professional gray-blue theme for comfortable extended reading
- **Sepia Theme**: Warm, vintage book-like appearance for traditional feel
- **Theme Preview**: Visual previews of each color scheme before selection
- **Persistent Settings**: Theme preferences saved across browser sessions

#### Text-to-Speech Feature Implementation
- **YouVersion-Style Audio Player**: Implemented comprehensive text-to-speech functionality for all Bible translations
- **Multi-Language Voice Support**: Auto-detects and uses English voices for KJV, ESV, and Greek texts; supports Russian text pronunciation
- **Advanced Audio Controls**: Play/pause, stop, speed adjustment (0.5x-2.0x), pitch control, volume control
- **Voice Selection**: Choose from available system voices with gender identification and quality preferences
- **Progress Tracking**: Real-time progress bar with time display showing current position and estimated duration
- **Clean Text Processing**: Automatically removes verse numbers and formatting for natural speech flow
- **Accessible Interface**: Intuitive controls similar to modern audio players with settings panel
- **Graceful Fallback**: Shows helpful message when Speech Synthesis API is unavailable

#### Theme Integration and User Experience Improvements
- **Unified Themes System**: Merged 'Main Themes of Romans' and 'Key Themes Dictionary' into single comprehensive resource
- **Chapter-Specific Key Themes**: Fixed repetitive key themes bug - each commentary chapter now shows unique, contextually relevant themes
- **Interactive Theme Navigation**: Made key themes clickable with hover effects, linking directly to comprehensive themes dictionary
- **Abbreviated Chapter Navigation**: Shortened "Romans Chapters" to "Rom. Ch." for cleaner interface
- **Comprehensive Themes Database**: Created scholarly themes dictionary with 20+ key theological concepts including practical applications and source citations

#### Button Layout and Mobile Responsiveness Fixes
- **Fixed Button Overlap Issues**: Resolved button overlapping problems throughout the application
- **Responsive Tab Design**: Made tabs stack vertically on mobile devices with proper spacing
- **Improved Menu Layout**: Enhanced mobile sidebar with consistent button padding and text wrapping
- **Filter Button Spacing**: Added proper spacing between filter buttons in Romans Timeline component
- **Card Layout Optimization**: Enhanced Maps of Romans cards to prevent content overlap on smaller screens

### Recent Enhancements (July 19, 2025)

#### Multi-Language Bible Text Integration
- **Complete Chapter Coverage**: Fixed KJV and Greek text components to include all 16 chapters of Romans (previously only had 1:1-17)
- **Interactive Chapter Navigation**: Added Previous/Next chapter buttons with working navigation
- **Four Bible Translations**: KJV, Koine Greek, Russian Synodal, and ESV translations
- **Cross-Reference Integration**: Built comprehensive cross-referencing system with:
  - Old Testament echoes and quotes
  - New Testament parallels
  - Strong's concordance numbers for Greek terms
  - Theological theme connections
- **Enhanced Greek Text Display**: Proper Greek numerals, full Textus Receptus text, Strong's integration
- **Biblical Connections UI**: Toggle-able cross-reference panels with confidence levels and reference types

#### Educational Resources Integration
- **Sunday School Resources**: Comprehensive educational materials for each Romans chapter including:
  - Coloring pages with memory verses and biblical imagery
  - Teaching charts for visual learning
  - Drawing activities and sketches
  - Interactive learning activities
  - Complete lesson plans
- **Age-Appropriate Filtering**: Resources categorized by preschool, elementary, youth, and all ages
- **Resource Type Filtering**: Filter by coloring pages, charts, drawings, activities, and lessons
- **Free Educational Materials**: All resources provided at no cost for ministry and educational use

#### Comprehensive Cross-Reference System
- **Four-Category Classification**: OT Echoes, NT Parallels, Greek Terms, Thematic Connections
- **Confidence Levels**: High/Medium/Low scholarly confidence ratings
- **Reference Types**: Direct quotes, allusions, thematic parallels, literary connections
- **Interactive Navigation**: Click references to navigate between chapters
- **Strong's Integration**: Greek word analysis with theological significance

#### Previous Scholarly Enhancements
- **Enhanced Theological Themes System**: Added comprehensive Greek terminology from Romans based on contemporary scholarship (N.T. Wright, Michael Bird)
- **Authentic Greek Terms**: διkaiosyne theou, hamartia, dikaioma, dikaiosis, telos, pistis, charis, nomos, sarx, pneuma, etc.
- **Advanced Theme Filtering**: Categories include Soteriology, Theology, Anthropology, Ecclesiology, Eschatology, Pneumatology
- **Scholarly Integration**: BDAG lexicon definitions with contemporary research citations
- **Greek Terms Dictionary**: Comprehensive dictionary with 15 key Romans terms including Strong's numbers and BDAG-style definitions
- **Examples for Preachers**: Chapter-specific sermon sketches and outlines in C.H. Spurgeon style and classical homiletical tradition
- **Echoes of Scripture**: Comprehensive biblical references and Old Testament echoes based on Richard B. Hays' scholarship
- **Other Commentators**: Extensive catalog of Romans commentators from bibliographies of Schreiner, Boice, Cranfield, Moo, and Gaventa, plus top devotional and pastoral commentaries

### API Endpoints
- `GET /api/commentaries` - List all available commentaries
- `GET /api/commentaries/:id` - Get specific commentary details
- `GET /api/commentaries/:id/chapters/:chapter` - Get chapter content (1-16 for Romans)
- `GET /api/search` - Search functionality across commentaries
- `GET /api/themes` - List all theological themes with Greek terms
- `GET /api/themes/search` - Search theological themes
- `GET /api/themes/category/:category` - Filter themes by theological category
- Bookmark management endpoints (add, remove, check status)

### Frontend Components
- **CommentarySidebar**: Displays available commentary sources
- **ChapterGrid**: Romans chapter selection (1-16)
- **CommentaryContent**: Main content display with navigation
- **MobileSidebar**: Responsive mobile navigation
- **Search Interface**: Commentary search functionality
- **TextToSpeech**: Universal audio player component with voice selection, speed control, and progress tracking
- **KJVText**: Complete King James Version text with navigation, cross-references, and integrated text-to-speech
- **GreekText**: Full Koine Greek Textus Receptus with Strong's numbers, cross-references, and text-to-speech
- **RussianText**: Russian Synodal translation with navigation, cross-references, and text-to-speech
- **ESVText**: English Standard Version translation with navigation, cross-references, and text-to-speech
- **CrossReferences**: Comprehensive biblical cross-reference system with four categories
- **GreekDictionary**: Comprehensive Greek terms with Strong's numbers and scholarly definitions
- **PreacherExamples**: Chapter-specific sermon outlines in classical preaching tradition
- **BiblicalEchoes**: Actual biblical references and possible Old Testament echoes with scholarly confidence levels
- **OtherCommentators**: Searchable database of Romans commentaries with approach, difficulty, and availability filtering
- **SundaySchoolResources**: Educational resources including coloring pages, biblical charts, drawings, and activities for each Romans chapter
- **RomansTimeline**: Interactive historical timeline with filtering and scholarly events
- **MapsOfRomans**: Interactive Roman Empire maps and geographical context
- **BackgroundRomansPaul**: Historical and theological context with Paul's biography and Roman church details

### Authentication & User Management
- Simple user identification system using user IDs
- PostgreSQL session storage for persistence
- No complex authentication flow - designed for simplicity

## Data Flow

1. **Initial Load**: Client fetches commentary list and displays sidebar
2. **Commentary Selection**: User selects commentary, triggering content fetch
3. **Chapter Navigation**: Chapter selection loads specific content via API
4. **Search**: Real-time search queries commentary content
5. **Bookmarks**: User interactions sync with database via API calls
6. **Caching**: TanStack Query handles client-side caching and invalidation

## External Dependencies

### Core Framework Dependencies
- React ecosystem (React, React DOM, React Hook Form)
- Radix UI component primitives for accessible UI
- TanStack Query for server state management
- Wouter for routing

### Database & Backend
- Drizzle ORM with Neon serverless adapter
- Express.js with middleware for JSON parsing and sessions
- Zod for schema validation

### UI & Styling
- Tailwind CSS with PostCSS
- Lucide React for icons
- class-variance-authority for component variants
- shadcn/ui component system

### Development Tools
- Vite for development server and builds
- TypeScript for type safety
- ESBuild for production server bundling

## Deployment Strategy

### Development Environment
- Vite dev server serves React frontend
- Express server handles API routes
- Hot module replacement for fast development
- Replit-specific development tooling integration

### Production Build
1. **Frontend**: Vite builds optimized React bundle to `dist/public`
2. **Backend**: ESBuild bundles Express server to `dist/index.js`
3. **Database**: Drizzle migrations ensure schema is up-to-date
4. **Static Assets**: Frontend served from Express server

### Environment Configuration
- `DATABASE_URL` required for PostgreSQL connection
- `NODE_ENV` determines development vs production behavior
- Replit-specific environment variables for platform integration

### Scaling Considerations
- Stateless server design enables horizontal scaling
- PostgreSQL connection pooling via Neon serverless
- Client-side caching reduces server load
- JSONB storage allows flexible content structure without schema changes